package com.att.ubm.service;

import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@ComponentScan
@EnableTransactionManagement
@PropertySource(value = { "classpath:application.properties" })
public class AppConfig 
{
    @Autowired
    private Environment env;

    @Value("${init-db:false}")
    private String initDatabase;
    
    @Bean
    public static PropertySourcesPlaceholderConfigurer placeHolderConfigurer()
    {
        return new PropertySourcesPlaceholderConfigurer();
    }    

    @Bean(name = "ubmJdbcTemplate")
    public JdbcTemplate jdbcTemplate(@Qualifier("UBMDb")DataSource ubmDataSource)
    {
        return new JdbcTemplate(ubmDataSource);
    }
    
    @Bean(name = "namedParameterJdbcTemplate")
    public NamedParameterJdbcTemplate namedParameterJdbcTemplate(@Qualifier("UBMDb")DataSource ubmDataSource)
    {
        return new NamedParameterJdbcTemplate(ubmDataSource);
    }

    @Bean(name="ubmTransactionManager")
    public DataSourceTransactionManager transactionManager(@Qualifier("UBMDb") DataSource dataSource)
    {
        return new DataSourceTransactionManager(dataSource);
    }

    @Bean(name = "UBMDb")
    public DataSource dataSource()
    {
        BasicDataSource dataSource = new BasicDataSource();
        dataSource.setDriverClassName(env.getProperty("jdbc.driverClassName"));
        dataSource.setUrl(env.getProperty("jdbc.url"));
        dataSource.setUsername(env.getProperty("jdbc.username"));
        dataSource.setPassword(env.getProperty("jdbc.password"));
        return dataSource;
    }
    
    @Bean(name = "camundaJdbcTemplate")
    public JdbcTemplate ubmJdbcTemplate(@Qualifier("CamundaDb")DataSource dataSource)
    {
        return new JdbcTemplate(dataSource);
    }

   

    @Bean(name = "CamundaDb")
    public DataSource UBMDataSource()
    {
        BasicDataSource dataSource = new BasicDataSource();
        dataSource.setDriverClassName(env.getProperty("camunda.jdbc.driverClassName"));
        dataSource.setUrl(env.getProperty("camunda.jdbc.url"));
        dataSource.setUsername(env.getProperty("camunda.jdbc.username"));
        dataSource.setPassword(env.getProperty("camunda.jdbc.password"));
        return dataSource;
    }

   
}
