package com.att.ubm.service;



import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.ubm.model.UIActionModel;


@Component
public class GetSIDIDController implements IGetSIDIDController {
	
	@Autowired
	IGetSIDIDService getSididService;
	
	public GetSIDIDController()
	{
		
	}
	
	public String getNewSIDID()
	{
		System.out.println("Enter into GetSIDIDController::getNewSIDID");
		String sidid=getSididService.getNewSIDID();
		if (sidid!=null) {
				System.out.println("getNewSIDID():"+sidid);
				return sidid;
		}
		return null;
		
	}
	
	@Override
	public String getHyperlinksDetails() {
		return getSididService.getHyperlinks();
	}

	@Override
	public Map<String,UIActionModel> getActionButtonDetails(String sidType, String pageName,String activityName) {
		return getSididService.getActionButtonDetails(sidType, pageName,activityName);
	}

	
	
	
}
