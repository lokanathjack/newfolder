package com.att.ubm.util;

import java.util.Date;
import java.util.Locale;

public final class DecoratorSQLDate {

private DecoratorSQLDate() {
	super();
}

public static final java.sql.Date getCurrentSQLDate()
{
	Date date = DecoratorDate.getCurrentDateTimestamp();

	return DecoratorDate.dateToSQLDate(date);
}

public static final java.sql.Time getCurrentSQLTime()
{
	Date date = DecoratorDate.getCurrentDateTimestamp();

	return DecoratorDate.dateToSQLTime(date);
}

public static final java.sql.Timestamp getCurrentSQLTimestamp()
{
	Date date = DecoratorDate.getCurrentDateTimestamp();

	return DecoratorDate.dateToSQLTimestamp(date);
}

public static final boolean intToSQLDateYMD(int iYear, int iMonth, int iDate, java.sql.Date sqlDate)
{
	Date dtDate = new Date(0);
	if ( ! DecoratorDate.intToDateYMD(iYear, iMonth, iDate, dtDate) )
		return false;

	sqlDate.setTime( dtDate.getTime() );
	return true;
}

public static final String sqlDateToString(java.sql.Date sqlDate, int iDtFormat, Locale locale)
{
	Date date;


	// Check if Date is valid
	if ( sqlDate == null )
		return ""; // no need to do new data that gives wrong data.
		//date = new Date(0);
	else
		date = new Date( sqlDate.getTime() );


	return DecoratorDate.dateToString(date, iDtFormat, locale);
}

public static final String sqlDateToString(java.sql.Date sqlDate, String sDtFormat, Locale locale)
{
	Date date;


	// Check if Date is valid
	if ( sqlDate == null )
		return ""; // no need to do new data that gives wrong data.
		//date = new Date(0);
	else
		date = new Date( sqlDate.getTime() );


	return DecoratorDate.dateToStringInFormat(date, sDtFormat, locale);
}

public static final String sqlTimestampToString(java.sql.Timestamp sqlTs, String sDtFormat, Locale locale)
{
	Date date;


	// Check if Date is valid
	if ( sqlTs == null )
		return ""; 
	else
		date = new Date( sqlTs.getTime() );


	return DecoratorDate.dateToStringInFormat(date, sDtFormat, locale);
}

public static final boolean stringToSQLDate(String sDate, java.sql.Date sqlDate, Locale locale)
{
	Date dtDate = new Date(0);

	if ( ! DecoratorDate.stringToDate(sDate, dtDate, locale) )
		return false;

	sqlDate.setTime( dtDate.getTime() );
	return true;
}

public static final boolean stringToSQLDateInFormat(String sDate, java.sql.Date sqlDate, String sFormat, Locale locale)
{
	Date dtDate = new Date(0);

	if ( ! DecoratorDate.stringToDateInFormat(sDate, dtDate, sFormat, locale) )
		return false;

	sqlDate.setTime( dtDate.getTime() );
	return true;
}

public static final boolean stringToSQLDateYMD(String sYear, String sMonth, String sDate, java.sql.Date sqlDate)
{
	Date dtDate = new Date(0);

	if ( ! DecoratorDate.stringToDateYMD(sYear, sMonth, sDate, dtDate) )
		return false;

	sqlDate.setTime( dtDate.getTime() );
	return true;
}

}
