package com.att.ubm.dao;

import java.util.List;
import java.util.Map;

import com.att.ubm.model.ConfigKCPNVPModel;
import com.att.ubm.model.EmployeeDetailsModel;

public interface IGetGroupsDetailsDAO {
	
	public Map<String,List<EmployeeDetailsModel>> getAllGroups();
	public Map<String,String> getToolTips(String screenName);
	public List<ConfigKCPNVPModel> getConfigKCPNVPDetalls();
	

}
