package com.att.ubm.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;

import com.att.filenet.util.FileNetConfigBean;
import com.att.ubm.dao.IFileNetDAO;
import com.att.ubm.model.FileNetConfigModel;
import com.att.ubm.util.LabelCacheUtil;



@Repository
public class FileNetDAOImpl implements IFileNetDAO {
	
	@Autowired
	@Qualifier("ubmJdbcTemplate")
	private JdbcTemplate jdbcTemplate;
	
	
	private static FileNetConfigBean fileNetConfigBean = null;
	


	public JdbcTemplate getMyTaskJdbcTemplate() {
		return jdbcTemplate;
	}


	public void setMyTaskJdbcTemplate(JdbcTemplate myTaskJdbcTemplate) {
		this.jdbcTemplate = myTaskJdbcTemplate;
	}


	
	public FileNetConfigModel getFileNetConfiguration()
	{
		
		
		String sql = "select nvp.Value VALUE ,kcp.key KEY,NAME ,END_DISPLAY ,START_DISPLAY from CONFIG_NVP nvp , CONFIG_KCP kcp where NVP.CONFIG_KCP_ID = KCP.CONFIG_KCP_ID and " + 
				" KCP.CONFIG_KCP_ID IN (select config_kcp_id FROM config_kcp WHERE key ='FILENET P8' AND CODE = 'FILENT P8 CONFIGURATION' or key = 'Mechid Details' AND code = 'MARKETING CHECKLIST SOM') " + 
				" ORDER BY nvp.UI_SEQ,nvp.CONFIG_NVP_ID";
		try {
			SqlRowSet rs = jdbcTemplate.queryForRowSet(sql);
			FileNetConfigModel fileNetConfigBean = new FileNetConfigModel();
	    	while (rs.next()) {
	    		if(rs.getString("KEY")!=null && rs.getString("NAME").equals("USERID"))
	    			fileNetConfigBean.setMechId(rs.getString("VALUE"));
	    		fileNetConfigBean.setPassword("ETM3rdQtr#2018");
	    		if(rs.getString("KEY")!=null && rs.getString("NAME").equals("CE_URL"))
	    			fileNetConfigBean.setWebServiceURL(rs.getString("VALUE"));
	    		if(rs.getString("KEY")!=null && rs.getString("NAME").equals("FILENT_WEB_URL"))
	    			fileNetConfigBean.setWebURL(rs.getString("VALUE"));
	    		if(rs.getString("KEY")!=null && rs.getString("NAME").equals("CE_OS_NAME"))
	    			fileNetConfigBean.setObjectStore(rs.getString("VALUE"));
	    		if(rs.getString("KEY")!=null && rs.getString("NAME").equals("USER_PATH_FOLDER"))
	    			fileNetConfigBean.setPathFolder(rs.getString("VALUE"));
	    		if(rs.getString("KEY")!=null && rs.getString("NAME").equals("FILENET_REACHABLE"))
	    			fileNetConfigBean.setReachableFlag(rs.getString("VALUE"));

	    }
		return fileNetConfigBean;
			}
			
		catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
		
	
	


	@Override
	public void insertIntoFolderInfo(String sidId, String folderName, String objectStoreId, String appName)
			throws Exception {
		String sqlStmt="";
			if(appName!=null && appName.equals("uverse"))
				sqlStmt = "insert into UVERSE_SID_DOCUMENTUM (UVERSE_SID_ID, FOLDER_NAME,STATUS,FILENET_OBJECT_ID) values(?,?,?,?)";
			else
				sqlStmt = "insert into SID_DOCUMENTUM (SID_ID, FOLDER_NAME,STATUS,FILENET_OBJECT_ID) values(?,?,?,?)";
			
			Object[] params = new Object[] { sidId,folderName,"Used",objectStoreId };
			jdbcTemplate.update(sqlStmt, params);
			
	}
	
	public String getFolderInfo(String appName,String sidId, String folderName) throws Exception{
		if(appName!=null && appName.length()>0 && appName.equals("uverse"))
		return getUverseFolderIdInfo(sidId,folderName);
		else
			return getMobilityFolderIdInfo(sidId,folderName);
	}
	/**
	 * @param sidId
	 * @param folderName
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("all")
	public String getUverseFolderIdInfo(String sidId,String folderName)throws Exception {
			String objectId=null;
			
			String sqlStmt = "SELECT FILENET_OBJECT_ID from UVERSE_SID_DOCUMENTUM WHERE UVERSE_SID_ID = ? and FOLDER_NAME=?";
			
			SqlRowSet sqlRowSet = jdbcTemplate.queryForRowSet(sqlStmt);
			
			if (sqlRowSet.next()) {
				objectId = sqlRowSet.getString("FILENET_OBJECT_ID");
			}

		
		return objectId;
		
	}
	
	/**
	 * @param sidId
	 * @param folderName
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("all")
	public String getMobilityFolderIdInfo(String sidId,String folderName)throws Exception {
		String objectId=null;
		
		String sqlStmt = "SELECT FILENET_OBJECT_ID from SID_DOCUMENTUM WHERE SID_ID = ? and FOLDER_NAME=?";
		
		SqlRowSet rs = jdbcTemplate.queryForRowSet(sqlStmt);
		
		if (rs.next()) {
			objectId = rs.getString("FILENET_OBJECT_ID");
		}

	
	return objectId;
	
}
	public String checkFolderInDB(String appName,String sidId,String folderName)
	{
			String sqlStmt =null;
			try {
				if(appName!=null && appName.equals("uverse"))
				{
					sqlStmt = "SELECT FILENET_OBJECT_ID from UVERSE_SID_DOCUMENTUM WHERE UVERSE_SID_ID = ? and FOLDER_NAME=?";
				}
				else
				{
					sqlStmt = "SELECT FILENET_OBJECT_ID from SID_DOCUMENTUM WHERE SID_ID = ? and FOLDER_NAME=?";
				}
				SqlRowSet sqlRowSet = jdbcTemplate.queryForRowSet(sqlStmt,sidId,folderName);
				if (sqlRowSet.next()) 
					return LabelCacheUtil.isNull(sqlRowSet.getString("FILENET_OBJECT_ID"));
				

				
			} catch (Exception e) {
				e.printStackTrace();
			}
			return null;
	}
	
}
