package com.att.filenet.util;


import java.io.File;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.att.ubm.model.FileNetConfigModel;
import com.filenet.api.collection.FolderSet;
import com.filenet.api.core.Document;
import com.filenet.api.core.Folder;
import com.filenet.api.core.ObjectStore;
import com.filenet.api.util.Id;

public class FileNetManager{


    private static String objectStoreId;
    private static IFileNetConnector connector=null;
    private static ObjectStore objectStore =null;
    private static Folder baseUBMFolder=null;
    private String ceUrl;
    private String userId;
    private String pwd;
    private String osFolderName;
    private static String userFolderName;
    private boolean connectionFlag;
    private boolean objectStoreFlag;
    private static Logger logger = LoggerFactory.getLogger(FileNetManager.class);
    private FileNetConfigModel fileNetConfigBean=null;
    public FileNetManager(FileNetConfigModel configModel)
    {
    	/*try {
    		ceUrl=fileNetConfigBean.getWebServiceURL();
    		userId=fileNetConfigBean.getMechId();
    		pwd=fileNetConfigBean.getPassword();
    		osFolderName=fileNetConfigBean.getObjectStore();
    		userFolderName=fileNetConfigBean.getPathFolder();
    		commonSidId=sidId;
    		FileNetManager.appName=appName;
    		logger.info( "FileNetManager()", "Before FileNetManager");
    		connector = new FileNetConnectorImpl(ceUrl,userId,pwd,null);
    		connector.establish();
    		logger.log( "Connection established");
    		logger.info( "FileNetManager()", "After FileNetManager");
    		//System.out.println("Connection established");
    		
    		logger.info( "FileNetManager()", "Before fetchObjectStore");
    		objectStore = connector.fetchObjectStore(osFolderName);
    		logger.log( "ObjectStore fetched");
			//System.out.println("ObjectStore fetched");
    		logger.info( "FileNetManager()", "After fetchObjectStore");
			userFolderName=File.separator+userFolderName+File.separator;
			logger.log( "Path folder:\t"+userFolderName);
			//System.out.println("Path folder:\t"+userFolderName);
			logger.info( "FileNetManager()", "Before fetchFolder");
			baseUBMFolder = connector.fetchFolder(userFolderName, objectStore);
			logger.log( "Path folder baseUBMFolder:\t"+baseUBMFolder.get_PathName());
			//System.out.println("Path folder baseUBMFolder:\t"+baseUBMFolder.get_PathName());
			logger.info( "FileNetManager()", "After fetchFolder");
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}*/
    	try {
    		fileNetConfigBean=configModel;
    		if(fileNetConfigBean!=null)
    		{
    		ceUrl=fileNetConfigBean.getWebServiceURL();
    		userId=fileNetConfigBean.getMechId();
    		pwd=fileNetConfigBean.getPassword();
    		osFolderName=fileNetConfigBean.getObjectStore();
    		userFolderName=fileNetConfigBean.getPathFolder();
    		connectionFlag=getConnection();
    		logger.info("FileNetManager()", "Connection Flag:\t"+connectionFlag);
			//System.out.println("Connection Flag:\t"+connectionFlag);
    		if(connectionFlag)
    		objectStoreFlag=getObjectStore();
    		logger.info("FileNetManager()", "ObjectStoreFlag Flag:\t"+objectStoreFlag);
			//System.out.println("ObjectStoreFlag Flag:\t"+objectStoreFlag);
    		if(objectStoreFlag)
    		fetchFolder();
    		}
    		else
    		logger.info("FileNetManager()", "Filenet P8 Configuration not avilable in Config_NVP table");
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("FileNetManager()", "Exception caught while initializing FileNetManager "+e);
		}
    }
    
    public boolean getConnection()
    {
    	boolean flag=false;
    	try {
    		logger.info("FileNetManager()", "Before getConnection");
    		connector = new FileNetConnectorImpl(ceUrl,userId,pwd,null);
    		flag=connector.establish();
    		logger.info("FileNetManager()", "After getConnection");
    		return flag;
    		}
    	catch (Exception e){
    			e.printStackTrace();
    			logger.error("FileNetManager()", "Exception caught while getConnection "+e);
    			return flag;
    			}
    }
    
    public boolean getObjectStore()
    {
    	boolean flag=false;
    	try {
    		logger.info("FileNetManager()", "Before getObjectStore");
    		objectStore = connector.fetchObjectStore(osFolderName);
    		if(objectStore!=null)
    			flag= true;
    		logger.info("FileNetManager()", "ObjectStore fetched");
    		//System.out.println("ObjectStore fetched");
    		logger.info("FileNetManager()", "After getObjectStore");
    		}
    	catch (Exception e) {
    		e.printStackTrace();
    		logger.info("FileNetManager()", "Exception caught while getObjectStore "+e);
    		return flag;
    		}
    	return flag;
    }
    
    public void fetchFolder()
    {
    	try{
    		logger.info("FileNetManager()", "Path folder:\t"+userFolderName);
    		//System.out.println("Path folder:\t"+userFolderName);
    		logger.info( "FileNetManager()", "Before fetchFolder");
    		baseUBMFolder = connector.fetchFolder(userFolderName, objectStore);
    		logger.info( "FileNetManager()", "Path folder baseUBMFolder:\t"+baseUBMFolder.get_PathName());
    		//System.out.println("Path folder baseUBMFolder:\t"+baseUBMFolder.get_PathName());
    		logger.info( "FileNetManager()", "After fetchFolder");
    		}
    	catch (Exception e) {
    		e.printStackTrace();
    		logger.info( "FileNetManager()", "Exception caught while fetchFolder "+e);
    		}
    }
	public String createFolder(String appName,String sidId, String folderName,boolean isFirstTime) {
		String parentFolderName = null;
		String parentFolderPath=null;
		try {
			logger.info("sidid:\t"+sidId);
			if(isObjectStoreFlag() && sidId!=null && folderName!=null)
			{
			String year=String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
			String sidYear=getSIDIDYear(sidId);
			logger.info("sidYear:\t"+sidYear);
			//year="2018";
			Folder folder = null;
			if(Long.valueOf(sidYear) >= Long.valueOf(year) && isFirstTime)
			{
				if(checkYearFolderExists(sidYear)==false)
				{
					//System.out.println("Year Folder Not Found");
					logger.info("Year Folder Not Found");
					connector.createFolder(objectStore,year, baseUBMFolder);
				}
			}
			else{
				year=sidYear;
				isFirstTime=false;
			}
			System.out.println("before fetching baseubmfolder");
			Folder baseUBMFolder = connector.fetchFolder(userFolderName+year, objectStore);
			//CREATE FOLDER
			logger.info("Base Folder:\t"+baseUBMFolder.get_FolderName());
			//System.out.println("Base Folder:\t"+baseUBMFolder.get_FolderName());
			if(!checkFolderExists(baseUBMFolder,folderName,isFirstTime)){
				folder = connector.createFolder(objectStore,folderName, baseUBMFolder);
				logger.info("Created Folder Name:\t"+folder.get_FolderName());
				logger.info("Created Object StoreId:\t"+folder.get_Id());
				//System.out.println("Created Folder Name:\t"+folder.get_FolderName());
				//System.out.println("Created Object StoreId:\t"+folder.get_Id());
				parentFolderName = folder.get_FolderName();
				objectStoreId = folder.get_Id().toString();
				//insertIntoFolderInfo(sidId,folderName,objectStoreId,appName);
				logger.info("New Folder Created!!!"+parentFolderName);
				//System.out.println("New Folder Created!!!"+parentFolderName);
				parentFolderPath=folder.get_PathName();
				logger.info("Parent Path:\t"+folder.get_PathName());
				//System.out.println("Parent Path:\t"+folder.get_PathName());
			}else{
				logger.info("Testing:\t"+File.separator+baseUBMFolder.get_FolderName());
				//System.out.println("Testing:\t"+File.separator+baseUBMFolder.get_FolderName());
				folder = connector.fetchFolder(baseUBMFolder.get_PathName()+File.separator+folderName,objectStore);
				parentFolderName = folder.get_FolderName();
				parentFolderPath=folder.get_PathName();
				logger.info("Folder Already Exists!!!");
				//System.out.println("Folder Already Exists!!!");
			}
			}
			else
			{
				logger.info("Please check the FileNet P8 Connection ,Objectstore and Sidid");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Exception caught while createFolder "+e);
		}
		return objectStoreId;
	}
	public static String getSIDIDYear(String sidId){
		if(sidId!=null && sidId.length()>0){
			return sidId.substring(0, 4);
			}
		return null;
		}
		
	public String createSubFolder(String appName,String sidid, String subFolderName) {
		String sFolderName = null;
		String subFolderwholePath=null;
		String subFolderObjectId=null;
		try {
			if(isObjectStoreFlag() && sidid!=null && subFolderName!=null )
			{
			Folder folder = null;
			Folder subFolder = null;
			String parentFolderName=getParentPath(sidid);
			//System.out.println("parentFolderName:\t"+parentFolderName);
			if(parentFolderName!=null)
			{
			//CREATE FOLDER
			folder = connector.fetchFolder(parentFolderName,objectStore);
				if(subFolderName!=null && subFolderName.length()>0)
				{
						if(!checkSubFolderExists(folder,subFolderName))
						{
							subFolder = connector.createFolder(objectStore,subFolderName, folder);
							logger.info("Created Sub Folder Name ==>"+subFolder.get_FolderName());
							logger.info("Created Object StoreId ==>"+subFolder.get_Id());
							//System.out.println("Created Sub Folder Name ==>"+subFolder.get_FolderName());
							//System.out.println("Created Object StoreId ==>"+subFolder.get_Id());
							sFolderName = subFolder.get_FolderName();
							//insertIntoFolderInfo(sidid,sFolderName,subFolder.get_Id().toString(),appName);
							logger.info("New Sub Folder Created!!!\t"+sFolderName);
							//System.out.println("New Sub Folder Created!!!\t"+sFolderName);
							subFolderwholePath=subFolder.get_PathName();
							logger.info("subFolderwholePath:\t"+subFolderwholePath);
							subFolderObjectId=subFolder.get_Id().toString();
						}		
						else
						{
							subFolderwholePath=folder.get_PathName();
							logger.info("Sub Folder Already Exists!!!"+subFolderwholePath);
							//System.out.println("Sub Folder Already Exists!!!");
							subFolderObjectId=folder.get_Id().toString();
						}
				}
			}
			}
			else
			{
				logger.info("Please check the FileNet P8 Connection and Objectstore");
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception caught while createSubFolder "+e);
		}
		return subFolderObjectId;
	}	

	
	/**
	 * @param sidId
	 * @param folderName
	 * @param objectStoreId
	 * @param appName
	 * @throws Exception
	 */
	/*public static void insertIntoFolderInfo(String sidId,String folderName, String objectStoreId,String appName) throws Exception
	{
		Connection con = null;
		PreparedStatement prpStmt = null;
		String sqlStmt = "";
		
		try {
			con = DBUtil.getConnection();
			if(appName!=null && appName.equals("uverse"))
				sqlStmt = "insert into UVERSE_SID_DOCUMENTUM (UVERSE_SID_ID, FOLDER_NAME,STATUS,FILENET_OBJECT_ID) values(?,?,?,?)";
			else
				sqlStmt = "insert into SID_DOCUMENTUM (SID_ID, FOLDER_NAME,STATUS,FILENET_OBJECT_ID) values(?,?,?,?)";
			
			prpStmt = con.prepareStatement(sqlStmt);

			prpStmt.setString(1, sidId);
			prpStmt.setString(2, folderName);
			prpStmt.setString(3, "Used");
			prpStmt.setString(4, objectStoreId);
			prpStmt.executeUpdate();
			con.commit();
			logger.info("Inserted into DB!!");
			//System.out.println("Inserted into DB!!");

		} catch (Exception e) {
			DBUtil.rollbackTransaction(con);
			e.printStackTrace();
			logger.error("Exception caught while insertIntoFolderInfo "+e);
			throw e;
		}
		finally
		{
			DBUtil.close(null, prpStmt, con);
		}
	}
*/	
	
	
	public static boolean checkFolderExists(Folder folder,String newFolderName, boolean isFirstTime) {
		if(folder!=null && !isFirstTime)
		{
			FolderSet subfolders = folder.get_SubFolders();
			Iterator iterator = subfolders.iterator();
			logger.info(newFolderName+"\t");
			logger.info("SUBFOLDERS: ");
			//System.out.println(newFolderName+"\t");
			//System.out.println("SUBFOLDERS: ");
			if(iterator!=null)
			{
			while (iterator.hasNext()) {
				Folder next = (Folder) iterator.next();
				if(next.get_Name()!=null && newFolderName.equals(next.get_Name()))
				{
					logger.info(next.get_Name());
					//System.out.println(next.get_Name());
					return true;
				}
				
			}
			
		}
		}
		return false;
	}
	
	private static boolean checkSubFolderExists(Folder karFolder, String subFolderName) {
		logger.info(" SubFolder-->"+subFolderName);
		logger.info("SididFolder---->"+karFolder.get_FolderName()); 
		//System.out.println(" SubFolder-->"+subFolderName);
		//System.out.println("SididFolder---->"+karFolder.get_FolderName());
		FolderSet subfolders = karFolder.get_SubFolders();
		Iterator iterator = subfolders.iterator();

		logger.info("SUBFOLDERS==> "); 
		//System.out.println("SUBFOLDERS==> ");
		while (iterator.hasNext()) {
			Folder next = (Folder) iterator.next();
			
			if(next.get_Name()!=null && subFolderName.equals(next.get_Name()))
			{
				logger.info(next.get_Name()); 
				//System.out.println(next.get_Name());
				return true;
			}
			
		}
		return false;
	}
	public File downloadFilep8(String id,String destinationFolder)
	{
		logger.info("downloadFilep8::"+id+"::"+destinationFolder);
		try {
			//return connector.downloadFile(objectStore,ubmRootFolder,destinationFolder,sourceFolder);
			if(isObjectStoreFlag() && id!=null && destinationFolder!=null)
				return connector.downloadFile(objectStore,id,destinationFolder);
			else
				logger.info("Please check the FileNet P8 Connection Objectstore and Destination folder Ids");
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception caught while downloadFile "+e);
		}
		return null;
	}
	
	public File downloadFileForBillCodeImport(String id,String destinationFolder)
	{
		logger.info("downloadFileForBillCodeImport::"+id+"::"+destinationFolder);
		try {
			//return connector.downloadFile(objectStore,ubmRootFolder,destinationFolder,sourceFolder);
			if(isObjectStoreFlag() && id!=null && destinationFolder!=null)
			return connector.downloadFileFromFileNet(objectStore,id,destinationFolder);
			else
				logger.info("Please check the FileNet P8 Connection Objectstore and Destination folder Ids");
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception caught while downloadFileForBillCodeImport "+e);
		}
		return null;
	}
	
	public static int getFileCount(String folderName)
	{
		Folder folder;
		int count=0;
		try {
			folder = connector.fetchFolder(folderName, objectStore);
			if(folder!=null)
			{
				count=connector.getFileCount(folder);
				logger.info("File Count Path:\t"+folder.get_PathName()+ " Count:\t"+count);
				//System.out.println("File Count Path:\t"+folder.get_PathName()+ " Count:\t"+count);
			}
			return count;
		} catch (Exception e) {
			logger.error("Exception caught while getFileCount "+e);
			logger.error("Folder not found:\t"+folderName+" Error:\t"+e.getMessage());
		}
		return 0;
	}
	/**
	 * This method will return count of files from a P8 folder 
	 * input parameters string string 
	 * sid id and folder name for which count is required 
	 */
	@SuppressWarnings("all")
	public int getItemCountInFolder(String objectId,String sidId, String folderName) throws Exception
	  {
		int iReturnValue=0;
		if(isObjectStoreFlag())
		{
		if(sidId!=null && folderName!=null)
		{
		if(objectId!=null)
			iReturnValue= getFileCountByFolderObject(getFolderObjectById(objectId));
		}
		}
		else
		{
			logger.info("Please check the FileNet P8 Connection and Objectstore");
		}

	    return iReturnValue;
	  }

	
	
	
	public static String getPathByFolderID(String folderId)
	{
		try {
			Folder folder=connector.getPathByFolderID(folderId, objectStore);
			if(folder!=null)
			{
				logger.info("WholePath:\t"+folder.get_PathName());
				//System.out.println("WholePath:\t"+folder.get_PathName());
				return folder.get_PathName();
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception caught while getPathByFolderID "+e);
		}
		return null;
	}
	
	public static boolean checkYearFolderExists(String year)
	{
		try {
			if(checkFolderExists(baseUBMFolder,year,false)){
				
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception caught while checkYearFolderExists "+e);
		}
		return false;
	}
	
	/*public String checkFolderInDB(String appName,String sidId,String folderName)
	{
			Connection con = null;
			PreparedStatement prpStmt = null;
			ResultSet rs = null;
			String sqlStmt =null;
			try {
				con=DBUtil.getConnection();
				if(appName!=null && appName.equals("uverse"))
				{
					sqlStmt = "SELECT FILENET_OBJECT_ID from UVERSE_SID_DOCUMENTUM WHERE UVERSE_SID_ID = ? and FOLDER_NAME=?";
				}
				else
				{
					sqlStmt = "SELECT FILENET_OBJECT_ID from SID_DOCUMENTUM WHERE SID_ID = ? and FOLDER_NAME=?";
				}
				prpStmt = con.prepareStatement(sqlStmt);
				prpStmt.setString(1, sidId);
				prpStmt.setString(2, folderName);
				rs = prpStmt.executeQuery();
				
				if (rs.next()) 
						return LabelCacheUtil.isNull(rs.getString("FILENET_OBJECT_ID"));
				

				
			} catch (Exception e) {
				e.printStackTrace();
				logger.error("Exception caught while checkFolderInDB "+e);
			}
			finally{
				DBUtil.close(rs, prpStmt, con);
			}
			return null;
	}
	*/
	public  Folder getFolderObjectById(String objectId)
	{
		logger.info("Enter into getFolderObjectById");
		//System.out.println("Enter into getFolderObjectById");
		try {
			Folder folder=null;
			if(objectId!=null)
			{
				Id id=new Id(objectId);
				//Object obj=(Object)objectId;
				//Id tempId=(Id) obj;
				folder=connector.getFolderObject(id, objectStore);
				logger.info("Records:\t"+folder);
				//System.out.println("Records:\t"+folder);
				return folder;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception caught while getFolderObjectById "+e);
		}
		return null;
	}
	
	public int getFileCountByFolderObject(Folder folder)
	{
		logger.info("Enter into getFileCountByFolderObject()");
		//System.out.println("Enter into getFileCountByFolderObject()");
		int count=0;
		
		try {

			if(isObjectStoreFlag())
			{
			if(folder!=null)
			{
				count=connector.getFileCount(folder);
			}
			logger.info("Exit into getFileCountByFolderObject():"+count);
			//System.out.println("Exit into getFileCountByFolderObject():"+count);
			return count;
			}
			else
			{
				logger.info("Please check the FileNet P8 Connection and Objectstore");
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception caught while getFileCountByFolderObject "+e);
		}
		return count;
	}
	
	
	
	public void copyDocuments(String sourceFolerId,String destinationFolderId, String lastModifier)
	{
		try {
			if(isObjectStoreFlag())
			{
			//Object Stores path separatorTSS path separatorSavvion path separatorUEA SID path separator2017 path separator 20170830009 //
			//Dest: : {ADE01995-5310-4CF7-B8EC-9C553CDE7D32} Object Stores path separatorTSS path separatorSavvion path separatorUEA SID path separator2017 path separator 20170908420 //
			List<Id> sourceDocumentObjectId=connector.getAllFilesInFolder(objectStore,sourceFolerId);
			System.out.println("List size:\t"+sourceDocumentObjectId.size());
			/*Integer accessAllowed = objectStore.getAccessAllowed();
			 if ((AccessRight.PRIVILEGED_WRITE_AS_INT &  accessAllowed.intValue()) != 0)
				 	System.out.println("Access Allowed\t"+ accessAllowed);
			 System.out.println("get_SymbolicName:\t"+objectStore.get_SymbolicName());*/
			
			 Document document=null;
			if(sourceDocumentObjectId!=null){
				Folder targetFolder=connector.getFolderObject(new Id(destinationFolderId),objectStore);
				for(int ind=0;ind<sourceDocumentObjectId.size();ind++)
				{
					document=connector.fetchDocument(sourceDocumentObjectId.get(ind), objectStore);
					FileNetCopyDocument cp=new FileNetCopyDocument();
					cp.copyDocument(objectStore,document, targetFolder,lastModifier);
				}

			}
			}
			else
			{
				logger.info("Please check the FileNet P8 Connection and Objectstore");
			}
			
		} catch (Exception e) {
			logger.error("Exception caught while copyDocuments "+e);
		}
	}
	
	
	public Map<String, String> getFilenetFileList(String folderId)
	{
		Map<String,String> fileNames = new HashMap<String, String>();
		logger.info("Enter into getFilenetFileList()");
		try {
			fileNames=connector.getAllFileNamesAndId(objectStore, folderId);
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Exception caught while getFilenetFileList "+e);
		}
		
		logger.info("Exit into getFilenetFileList()");
		return fileNames;
	}
	
	public void createFileNetFolders(String appName,String commSidId,String folderName,boolean flag) {
		
			long lStartTime = System.currentTimeMillis();
			long lEndTime = System.currentTimeMillis();
	        long output = lEndTime - lStartTime;
	        logger.info( "InitSidControl", "Total Time Taken to get CE Connection\t: " + output);
	        //System.out.println("Total Time Taken to get CE Connection\t: " + output);
	        lStartTime = System.currentTimeMillis();
	        createFolder(appName,commSidId,folderName,flag);
	        lEndTime = System.currentTimeMillis();
	        output = lEndTime - lStartTime;
	        logger.info( "InitSidControl", "Total Time Taken to Create Folder\t: " + output);
	        //System.out.println("Total Time Taken to Create Folder\t: " + output);
	}
	
	private static String getParentPath(String commSidid)
	{
		logger.info("Enter into getParentPath()");
		try {
			@SuppressWarnings("all")
			StringBuffer sb=new StringBuffer();
			sb.append(userFolderName);
			sb.append(getSIDIDYear(commSidid));
			sb.append(File.separator);
			sb.append(commSidid);
			return sb.substring(0, sb.length());
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception caught while getParentPath "+e);
		}
		return null;
	}
	
	public  String createRDSubFolder(String appName,String sidid, String rdId,String subFolderName) {
		String sFolderName = null;
		String subFolderwholePath=null;
		try {
			if(isObjectStoreFlag())
			{
			Folder folder = null;
			Folder subFolder = null;
			System.out.println("Sidid:\t"+sidid);
			String parentFolderName=getParentPath(sidid);
			parentFolderName=parentFolderName+File.separator+rdId;
			System.out.println("parentFolderName:\t"+parentFolderName);
			if(parentFolderName!=null)
			{
			//CREATE FOLDER
			folder = connector.fetchFolder(parentFolderName,objectStore);
				if(subFolderName!=null && subFolderName.length()>0)
				{
						if(!checkSubFolderExists(folder,subFolderName))
						{
							subFolder = connector.createFolder(objectStore,subFolderName, folder);
							logger.info("Created Sub Folder Name ==>"+subFolder.get_FolderName());
							logger.info("Created Object StoreId ==>"+subFolder.get_Id());
							//System.out.println("Created Sub Folder Name ==>"+subFolder.get_FolderName());
							//System.out.println("Created Object StoreId ==>"+subFolder.get_Id());
							sFolderName = subFolder.get_FolderName();
							//insertIntoFolderInfo(sidid,sFolderName,subFolder.get_Id().toString(),appName);
							logger.info("New Sub Folder Created!!!\t"+sFolderName);
							//System.out.println("New Sub Folder Created!!!\t"+sFolderName);
							subFolderwholePath=subFolder.get_PathName();
							logger.info("subFolderwholePath:\t"+subFolderwholePath);
						}		
						else
						{
							subFolderwholePath=folder.get_PathName();
							logger.info("Sub Folder Already Exists!!!"+subFolderwholePath);
							//System.out.println("Sub Folder Already Exists!!!");
						}
				}
			}
			}
			else
			{
				logger.info("Please check the FileNet P8 Connection and Objectstore");
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception caught while createSubFolder "+e);
		}
		return subFolderwholePath;
	}	
	
	public boolean isConnectionFlag() {
		return connectionFlag;
	}
	public void setConnectionFlag(boolean connectionFlag) {
		this.connectionFlag = connectionFlag;
	}
	public boolean isObjectStoreFlag() {
		return objectStoreFlag;
	}
	public void setObjectStoreFlag(boolean objectStoreFlag) {
		this.objectStoreFlag = objectStoreFlag;
	}
	
	public static void main(String[] args) {
		FileNetConfigModel configModel=new FileNetConfigModel();
		configModel.setMechId("m93911");
		configModel.setPassword("ETM3rdQtr#2018");
		configModel.setObjectStore("MIGRATION");
		configModel.setWebServiceURL("http://p8ecmcesd.web.att.com/wsi/FNCEWS40MTOM");
		configModel.setPathFolder("/Savvion/UEA SID/");
		FileNetManager fileNetManager=new FileNetManager(configModel);
		String objectId=fileNetManager.createFolder("mobility", "20181008002", "20181008002", true);
		System.out.println("objectId:\t"+objectId);
		try {
			/*//fileNetDAO.insertIntoFolderInfo(sidId, folderName, objectId, "mobility");
			FileNetModel fileNetModel=new FileNetModel();
			fileNetModel.setFolderId(objectId);
			fileNetModel.setFolderName("test");*/
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	

}

