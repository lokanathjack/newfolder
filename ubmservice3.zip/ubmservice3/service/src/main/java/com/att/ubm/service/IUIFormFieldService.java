package com.att.ubm.service;

import java.util.Map;

import com.att.ubm.model.UIFormFieldsModel;

public interface IUIFormFieldService {

	public Map<String,UIFormFieldsModel> getUIFormFieldsDetalls(String sidType,String pageName,String activityName,String sidId);
}