package com.att.ubm.service;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.it.tdc.bpm.domain.TaskInfo;
import com.att.it.tdc.bpm.exception.BPMException;
import com.att.it.tdc.bpm.service.task.ITaskService;
import com.att.it.tdc.bpm.service.task.impl.TaskServiceCamundaImpl;
import com.att.ubm.camunda.CamundaUBMComponent;
import com.att.ubm.dao.IMyTaskDAO;
import com.att.ubm.model.Description;
import com.att.ubm.model.MyTaskInfo;
import com.att.ubm.model.MyTasksData;

/*import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;*/

import com.att.ubm.model.MyTasksModel;
import com.att.ubm.util.DecoratorSQLDate;
import com.att.ubm.util.DescriptionTokenUtil;
import com.att.ubm.util.MyTaskDueDateUtil;

@Service
public class MyTaskRestServiceImpl implements IMyTaskService {
	private static final Logger logger = LoggerFactory.getLogger(MyTaskRestServiceImpl.class);

	@Autowired
	IMyTaskDAO myTaskDao;
	
	SimpleDateFormat format = new SimpleDateFormat("MMM dd, yyyy HH:mm aaa");
	
	SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
	
	@Autowired
	private CamundaUBMComponent camundaUBMComponent;
	
	@Override
	public MyTasksModel getTaskInfo(String id) {
		System.out.println("Enter into MyTaskRestServiceImpl:getTaskInfo " + id);

		
		return myTaskDao.getTaskInfo(id);
	} 
	
	@Override
	public MyTasksData myTaskDetails(String loggedUserId) {

		MyTasksData myTasksData = new MyTasksData();
		List<MyTaskInfo> taskModelLst = null;
		MyTaskInfo myTaskInfo = null;
		ITaskService taskService = new TaskServiceCamundaImpl();
		Description description = null;
		try {
			taskService = camundaUBMComponent.getCamundaTaskService(loggedUserId);
			List<TaskInfo> taskList = taskService.getTaskList();

			taskModelLst = new ArrayList<MyTaskInfo>();
			for (TaskInfo taskInfo : taskList) {
				description = new Description();
				myTaskInfo = new MyTaskInfo();
				if (taskInfo.getDescription() != null && StringUtils.isNotBlank((String) taskInfo.getDescription())) {
					
					description = DescriptionTokenUtil.getDescriptionToken((String) taskInfo.getDescription());
					logger.info("description" + description.getSidDescription());
					if (description.getSidDescription() != null && !description.getSidDescription().isEmpty()) {
						myTaskInfo.setSidDescription(description.getSidDescription());
					}
					if (description.getSidId() != null && !description.getSidId().isEmpty()) {
						myTaskInfo.setSidId(description.getSidId());
					}

					if (description.getSidType() != null && !description.getSidType().isEmpty()) {
						myTaskInfo.setSidType(description.getSidType());
					}
					if (description.getCreator() != null && !description.getCreator().isEmpty()) {
						myTaskInfo.setCreator(description.getCreator());
					}
					if (description.getRequestType() != null && !description.getRequestType().isEmpty()) {
						myTaskInfo.setRequestType(description.getRequestType());
					}

				} else {
					myTaskInfo.setSidId(StringUtils.EMPTY);
					myTaskInfo.setSidDescription(StringUtils.EMPTY);
					myTaskInfo.setSidType(StringUtils.EMPTY);
					myTaskInfo.setCreator(StringUtils.EMPTY);
					myTaskInfo.setRequestType(StringUtils.EMPTY);
				}

				if (taskInfo.getDue() != null && StringUtils.isNotBlank((String) taskInfo.getDue())) {
					Date dueDate = formatter.parse((String)taskInfo.getDue());
					myTaskInfo.setDueDate(format.format(dueDate));
					myTaskInfo.setTempDueDate(dueDate.getTime());
					boolean dueFlag=MyTaskDueDateUtil.convertDateFormate(myTaskInfo.getDueDate());
					myTaskInfo.setDueFlag(dueFlag);
				} else {
					myTaskInfo.setDueDate(StringUtils.EMPTY);
				}
				if (StringUtils.isBlank(taskInfo.getCreated())) {
					myTaskInfo.setAssignmentDate(StringUtils.EMPTY);
				} else {
					Date assignmentDate = formatter.parse(taskInfo.getCreated());
					myTaskInfo.setAssignmentDate(format.format(assignmentDate));
					myTaskInfo.setTempAssignmentDate(assignmentDate.getTime());
				}
				if (StringUtils.isBlank(taskInfo.getName())) {
					myTaskInfo.setTaskName(StringUtils.EMPTY);
				} else {
					myTaskInfo.setTaskName(taskInfo.getName());
				}
				System.out.println(":::::::::::::::: Value of Id :::::::::::::: " + taskInfo.getId());
				if (StringUtils.isBlank(taskInfo.getId())) {
					myTaskInfo.setId(StringUtils.EMPTY);
				} else {
					myTaskInfo.setId(taskInfo.getId());
				}

				taskModelLst.add(myTaskInfo);
			}
			myTasksData.setData(taskModelLst);

		} catch (BPMException e) {
			e.printStackTrace();
		} catch (ParseException e) {
            e.printStackTrace();
        }


		return myTasksData;
	}

	@Override
	public MyTasksData getAvailableList(String loggedUserId) {
		List<MyTaskInfo> taskModelLst = new ArrayList<MyTaskInfo>();
		MyTaskInfo myTaskInfo = null;
		MyTasksData myTasksData = new MyTasksData();
		ITaskService taskService = new TaskServiceCamundaImpl();
		Description description = null;
		try {
			taskService = camundaUBMComponent.getCamundaTaskService(loggedUserId);
			List<TaskInfo> taskList = taskService.getAvailableTaskList();

			taskModelLst = new ArrayList<MyTaskInfo>();
			for (TaskInfo taskInfo : taskList) {
				description = new Description();
				myTaskInfo = new MyTaskInfo();
				if (taskInfo.getDescription() != null && StringUtils.isNotBlank((String) taskInfo.getDescription())) {
					
					description = DescriptionTokenUtil.getDescriptionToken((String) taskInfo.getDescription());
					logger.info("description" + description.getSidDescription());
					if (description.getSidDescription() != null && !description.getSidDescription().isEmpty()) {
						myTaskInfo.setSidDescription(description.getSidDescription());
					}
					if (description.getSidId() != null && !description.getSidId().isEmpty()) {
						myTaskInfo.setSidId(description.getSidId());
					}

					if (description.getSidType() != null && !description.getSidType().isEmpty()) {
						myTaskInfo.setSidType(description.getSidType());
					}
					if (description.getCreator() != null && !description.getCreator().isEmpty()) {
						myTaskInfo.setCreator(description.getCreator());
					}
					if (description.getRequestType() != null && !description.getRequestType().isEmpty()) {
						myTaskInfo.setRequestType(description.getRequestType());
					}

				} else {
					myTaskInfo.setSidId(StringUtils.EMPTY);
					myTaskInfo.setSidDescription(StringUtils.EMPTY);
					myTaskInfo.setSidType(StringUtils.EMPTY);
					myTaskInfo.setCreator(StringUtils.EMPTY);
					myTaskInfo.setRequestType(StringUtils.EMPTY);
				}

				if (taskInfo.getDue() != null && StringUtils.isNotBlank((String) taskInfo.getDue())) {
					Date dueDate = formatter.parse((String)taskInfo.getDue());
					myTaskInfo.setDueDate(format.format(dueDate));
					myTaskInfo.setTempDueDate(dueDate.getTime());
					boolean dueFlag=MyTaskDueDateUtil.convertDateFormate(myTaskInfo.getDueDate());
					myTaskInfo.setDueFlag(dueFlag);
				} else {
					myTaskInfo.setDueDate(StringUtils.EMPTY);
				}
				if (StringUtils.isBlank(taskInfo.getCreated())) {
					myTaskInfo.setAssignmentDate(StringUtils.EMPTY);
				} else {
					Date assignmentDate = formatter.parse(taskInfo.getCreated());
					myTaskInfo.setAssignmentDate(format.format(assignmentDate));
					myTaskInfo.setTempAssignmentDate(assignmentDate.getTime());
				}
				if (StringUtils.isBlank(taskInfo.getName())) {
					myTaskInfo.setTaskName(StringUtils.EMPTY);
				} else {
					myTaskInfo.setTaskName(taskInfo.getName());
				}
				if (StringUtils.isBlank(taskInfo.getId())) {
					myTaskInfo.setId(StringUtils.EMPTY);
				} else {
					myTaskInfo.setId(taskInfo.getId());
				}

				taskModelLst.add(myTaskInfo);
			}
			myTasksData.setData(taskModelLst);

		} catch (BPMException e) {
			e.printStackTrace();
		}
		 catch (ParseException e) {
	            e.printStackTrace();
	        }

		return myTasksData;
	}

	@Override
	public MyTasksData getAssignedList(String loggedUserId) {
		List<MyTaskInfo> taskModelLst = new ArrayList<MyTaskInfo>();
		MyTaskInfo myTaskInfo = null;
		Description description = null;
		MyTasksData myTasksData = new MyTasksData();
		ITaskService taskService = new TaskServiceCamundaImpl();
		try {
			taskService = camundaUBMComponent.getCamundaTaskService(loggedUserId);
			List<TaskInfo> taskList = taskService.getAssignedTaskList();

			taskModelLst = new ArrayList<MyTaskInfo>();
			for (TaskInfo taskInfo : taskList) {
				description = new Description();
				myTaskInfo = new MyTaskInfo();
				if (taskInfo.getDescription() != null && StringUtils.isNotBlank((String) taskInfo.getDescription())) {
					description = DescriptionTokenUtil.getDescriptionToken((String) taskInfo.getDescription());
					logger.info("description" + description.getSidDescription());
					if (description.getSidDescription() != null && !description.getSidDescription().isEmpty()) {
						myTaskInfo.setSidDescription(description.getSidDescription());
					}
					if (description.getSidId() != null && !description.getSidId().isEmpty()) {
						myTaskInfo.setSidId(description.getSidId());
					}

					if (description.getSidType() != null && !description.getSidType().isEmpty()) {
						myTaskInfo.setSidType(description.getSidType());
					}
					if (description.getCreator() != null && !description.getCreator().isEmpty()) {
						myTaskInfo.setCreator(description.getCreator());
					}
					if (description.getRequestType() != null && !description.getRequestType().isEmpty()) {
						myTaskInfo.setRequestType(description.getRequestType());
					}

				} else {
					myTaskInfo.setSidId(StringUtils.EMPTY);
					myTaskInfo.setSidDescription(StringUtils.EMPTY);
					myTaskInfo.setSidType(StringUtils.EMPTY);
					myTaskInfo.setCreator(StringUtils.EMPTY);
					myTaskInfo.setRequestType(StringUtils.EMPTY);
				}

				if (taskInfo.getDue() != null && StringUtils.isNotBlank((String) taskInfo.getDue())) {
					Date dueDate = formatter.parse((String)taskInfo.getDue());
					myTaskInfo.setDueDate(format.format(dueDate));
					myTaskInfo.setTempDueDate(dueDate.getTime());
					boolean dueFlag=MyTaskDueDateUtil.convertDateFormate(myTaskInfo.getDueDate());
					myTaskInfo.setDueFlag(dueFlag);
					
				} else {
					myTaskInfo.setDueDate(StringUtils.EMPTY);
				}
				if (StringUtils.isBlank(taskInfo.getCreated())) {
					myTaskInfo.setAssignmentDate(StringUtils.EMPTY);
				} else {
					Date assignmentDate = formatter.parse(taskInfo.getCreated());
					myTaskInfo.setAssignmentDate(format.format(assignmentDate));
					myTaskInfo.setTempAssignmentDate(assignmentDate.getTime());
				}
				if (StringUtils.isBlank(taskInfo.getName())) {
					myTaskInfo.setTaskName(StringUtils.EMPTY);
				} else {
					myTaskInfo.setTaskName(taskInfo.getName());
				}
				if (StringUtils.isBlank(taskInfo.getId())) {
					myTaskInfo.setId(StringUtils.EMPTY);
				} else {
					myTaskInfo.setId(taskInfo.getId());
				}
				
				taskModelLst.add(myTaskInfo);
			}
			myTasksData.setData(taskModelLst);

		} catch (BPMException e) {
			e.printStackTrace();
		} catch (ParseException e) {
            e.printStackTrace();
        }

		return myTasksData;
	}

	@Override
	public boolean claimTask(String sidId,String taskId, String loggedInUser) {
		ITaskService taskService = camundaUBMComponent.getCamundaTaskService(loggedInUser);
		boolean flag= taskService.claim(taskId);
		if(flag)
		{
			//To get the group name
			Map<String,Object> values=new HashMap<String,Object>();
			values.put("SID_ID",sidId);
			values.put("TASK_ID",taskId);
			values.put("FROM_ID",null); //Group mean we have multiple user in the same group
			values.put("TO_ID",loggedInUser);
			values.put("ACTION_TS",DecoratorSQLDate.getCurrentSQLTimestamp());
			values.put("ACTION_NAME","Claim"); 
			myTaskDao.insertAssignmentHistory(values);
		}
		return flag;
	}

	@Override
	public boolean releaseClaimedTask(String sidId,String taskId, String loggedInUser) {
		ITaskService taskService = camundaUBMComponent.getCamundaTaskService(loggedInUser);
		boolean flag=  taskService.release(taskId);
		if(flag)
		{
			//To get the group name
			Map<String,Object> values=new HashMap<String,Object>();
			values.put("SID_ID",sidId);
			values.put("TASK_ID",taskId);
			values.put("FROM_ID",null); //Group mean we have multiple user in the same group
			values.put("TO_ID",loggedInUser);
			values.put("ACTION_TS",DecoratorSQLDate.getCurrentSQLTimestamp());
			values.put("ACTION_NAME","UnClaim"); 
			myTaskDao.insertAssignmentHistory(values);
		}
		return flag;

	}
	
} 
