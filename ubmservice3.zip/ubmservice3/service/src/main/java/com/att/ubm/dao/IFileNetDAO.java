package com.att.ubm.dao;

import com.att.ubm.model.FileNetConfigModel;

public interface IFileNetDAO {
	
	public FileNetConfigModel getFileNetConfiguration();
	public void insertIntoFolderInfo(String sidId,String folderName, String objectStoreId,String appName) throws Exception;
	public String getFolderInfo(String appName,String sidId, String folderName) throws Exception;
	public String checkFolderInDB(String appName,String sidId,String folderName);

}
