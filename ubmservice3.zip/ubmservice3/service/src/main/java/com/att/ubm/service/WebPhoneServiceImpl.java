package com.att.ubm.service;


import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.ubm.dao.IGetGroupsDetailsDAO;
import com.att.ubm.model.ConfigKCPNVPModel;
import com.att.ubm.model.EmployeeDetailsModel;
import com.att.ubm.model.GroupsDetailsModel;

/*import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;*/

import com.att.ubm.model.RequestorModel;
import com.att.ubm.util.LabelCacheUtil;
import com.att.ubm.util.WebPhoneUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.att.aft.dme2.internal.gson.JsonObject;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.att.aft.dme2.internal.gson.Gson;
import org.json.simple.JSONObject;

@Service
public class WebPhoneServiceImpl implements IWebPhoneService {
	
	@Autowired
	IGetGroupsDetailsDAO getGroupDao;

	@Override
	public RequestorModel getRequstorDetails(String attuId) throws Exception {
		RequestorModel requestorModel=new RequestorModel();
		requestorModel.setRequstorPhone(LabelCacheUtil.isNull(WebPhoneUtil.getTelephoneNumber(attuId)));
		requestorModel.setRequestorEmailId(WebPhoneUtil.getMail(attuId));
		return requestorModel;
	}
	
	@Override
	public List<EmployeeDetailsModel> getAllGroupMembers(String groupName) throws Exception {
		Map<String,List<EmployeeDetailsModel>> details=getGroupDao.getAllGroups();
		
		if(details!=null)
		{
			/*for (Map.Entry<String, List<EmployeeDetailsModel>> entry : details.entrySet()) {
			    //System.out.println("Key = " + entry.getKey() + ", Value = " + entry.getValue());
				
				groupsDetailsModel=new GroupsDetailsModel();
				groupsDetailsModel.setGroupName(entry.getKey());
				groupsDetailsModel.setKeyValuePairsModel(entry.getValue());
				allGroups.add(groupsDetailsModel);
				
			}*/
			if(details!=null)
			{
				if(details.containsKey(groupName))
				{
					return details.get(groupName);
				}
			}
			//print(allGroups);
			//getJsonObject(details);
		}
		
		return null;
	
	}
	@Override
	public Map<String, String> getToolTips(String screenName) {
		return getGroupDao.getToolTips(screenName);
	}
	
	 @Override
		public String getConfigKCPNVPDetalls(String sidType,String pageName,String sidId) {
			
			try {
				 List<ConfigKCPNVPModel> listofValues=getGroupDao.getConfigKCPNVPDetalls();
				//Map<String, ConfigKCPNVPModel> queryValues = new HashMap<String, ConfigKCPNVPModel>() ;
				if(listofValues!=null)
				{
					/*for(ConfigKCPNVPModel obj:listofValues)
					{
						queryValues.put(obj.getKey()+"::"+obj.getName(), obj);
					}*/
					Map<String,List<ConfigKCPNVPModel>> sortedBySidid=getSortBySidid(listofValues,sidId);
					if(sortedBySidid!=null)
					{
					return getConfigNVPJsonString(sidType,pageName,sidId,sortedBySidid);
					}
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			return null;
		}
	    
	    private Map<String,List<ConfigKCPNVPModel>> getSortBySidid(List<ConfigKCPNVPModel> listofValues,String sidId)
	    {
	    	Map<String,List<ConfigKCPNVPModel>> valueNameObject=null;
	    	try {
	    		valueNameObject=new LinkedHashMap<String,List<ConfigKCPNVPModel>>();
				for(ConfigKCPNVPModel obj:listofValues)
				{
					
					if(Long.parseLong(sidId)>=obj.getStartDisplay() && Long.parseLong(sidId)<=obj.getEndDisplay())
					{
						String key=obj.getKey();
						if(valueNameObject.containsKey(key))
						{
							List<ConfigKCPNVPModel> tempList=valueNameObject.get(key);
							ConfigKCPNVPModel configKCPNVPModel=new ConfigKCPNVPModel();
							configKCPNVPModel.setName(obj.getName());
							configKCPNVPModel.setValue(obj.getValue());
							tempList.add(configKCPNVPModel);
							valueNameObject.put(key, tempList);
						}
						else
						{
							List<ConfigKCPNVPModel> lstValue=new ArrayList<ConfigKCPNVPModel>();
							ConfigKCPNVPModel configKCPNVPModel=new ConfigKCPNVPModel();
							configKCPNVPModel.setName(obj.getName());
							configKCPNVPModel.setValue(obj.getValue());
							lstValue.add(configKCPNVPModel);
							valueNameObject.put(key, lstValue);
						}
					}
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			}
	    	return valueNameObject;
	    }
	    
	    public String getConfigNVPJsonString(String sidType,String pageName,String sidId,Map<String,List<ConfigKCPNVPModel>> details) {
			System.out.println("Enter into here");
			
			
			ObjectMapper objectMapper = new ObjectMapper();
	    	//Set pretty printing of json
	    	//objectMapper.enable(SerializationFeature.FAIL_ON_EMPTY_BEANS);
			
			//JSONObject tempResponseDetailsJson = new JSONObject();
	    	 org.json.simple.JSONArray ja = new org.json.simple.JSONArray();
	    	 objectMapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
	    	//Define map which will be converted to JSON
	    	 
	    	 JSONObject responseDetailsJson = new JSONObject();
				responseDetailsJson.put("sidId", sidId);
				responseDetailsJson.put("sidType", sidType);
				responseDetailsJson.put("pageName", pageName);
				
				/* org.json.simple.JSONArray ja1 = new org.json.simple.JSONArray();
				 ja1.add(responseDetailsJson);*/
				
					/*array.add(responseDetailsJson);
					array.add(responseDetailsJson1);*/
				
				// array.add(new StringBuffer().append("sidType").append(sidType));
				// array.add(new StringBuffer().append("pageName").append(pageName));
	    	 
	    	 
	    	 String arrayToJson="";
	    	 //System.out.println("Sorted list size:\t"+details.size());
	    	 StringBuilder dbValues=null;
	    	 List<ConfigKCPNVPModel> keyConfigList=null;
	    	 String key="";
	    	 List<String> newList=null;
	    	 for (Map.Entry<String, List<ConfigKCPNVPModel>> entry : details.entrySet()) {
	    		 dbValues=new StringBuilder();
	    		 ja = new org.json.simple.JSONArray();
	    		 key=entry.getKey();
	    	    	keyConfigList =details.get(key);
	    	    	newList=new ArrayList<String>();
	    	try {
	    		if(keyConfigList!=null && keyConfigList.size()>0)
	    		{
	    			
	    			//dbValues.append(entry.getKey());
	    			for(ConfigKCPNVPModel model:keyConfigList)
	    			{
	    				
	    				arrayToJson = objectMapper.writeValueAsString(model);
	    				//System.out.println("Object Mapper:\t"+arrayToJson);
	    				ja.add(arrayToJson);
	    				newList.add(arrayToJson);
	    				//System.out.println("Array:"+ja);
	    				//System.out.println("List:\t"+newList);
	    				//dbValues.append(arrayToJson);
	    			}
	    			
	    			responseDetailsJson.put(key, newList.toString());
	    			System.out.println(responseDetailsJson);
	    			
	    		}
			} catch (JsonProcessingException e) {
				e.printStackTrace();
			}
	    	}
	    	
	    	//System.out.println("tempResponseDetailsJson:\t"+tempResponseDetailsJson);
	    	String tempStr=null;
					//responseDetailsJson.put(sb.toString(), ja.toString());
					/*JSONObject json=new JSONObject();
					json.put(responseDetailsJson, tempResponseDetailsJson);*/
					//System.out.println(json.toJSONString());
					tempStr=responseDetailsJson.toJSONString();
					tempStr = new Gson().toJson(responseDetailsJson);
					System.out.println("tempStr:\t"+responseDetailsJson);
				
	    	return tempStr;
	    	
	    
	    	
	    
		}
	    

	
	
}
