/**
 * 
 */
package com.att.ubm.dao;


import com.att.ubm.model.SIDApprovalModel;


public interface ISIDApprovalDetailsDAO {

	public SIDApprovalModel getNarrativeFormValues(String sidId);
	public int insertSIDApporvalDetails(String tableName,SIDApprovalModel approvalModel);
	public boolean rowExists(String tName,String sidId,String activityName);
	public int updateSIDApporvalDetails(SIDApprovalModel approvalModel);
}
