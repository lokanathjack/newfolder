package com.att.ubm.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.att.ubm.model.EmployeeDetailsModel;
import com.att.ubm.model.GroupsDetailsModel;
import com.att.ubm.model.RequestorModel;


public interface IWebPhoneService {

	public RequestorModel getRequstorDetails(String attuId) throws Exception;
	public List<EmployeeDetailsModel> getAllGroupMembers(String groupName) throws Exception;
	public Map<String, String> getToolTips(String screenName);
	public String getConfigKCPNVPDetalls(String sidType,String pageName,String sidId);
}