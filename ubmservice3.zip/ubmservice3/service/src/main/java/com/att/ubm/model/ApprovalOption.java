/**
 * 
 */
package com.att.ubm.model;

import java.io.Serializable;
import java.util.List;

import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * @author kb942m
 *
 */
public class ApprovalOption implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1769674732745912841L;

	private QuickUpdate quickUpdate;

	private Voice voice;

	public QuickUpdate getQuickUpdate() {
		return quickUpdate;
	}

	public void setQuickUpdate(QuickUpdate quickUpdate) {
		this.quickUpdate = quickUpdate;
	}

	public Voice getVoice() {
		return voice;
	}

	public void setVoice(Voice voice) {
		this.voice = voice;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

}
