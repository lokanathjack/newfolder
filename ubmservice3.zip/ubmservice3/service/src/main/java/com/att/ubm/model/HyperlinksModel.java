package com.att.ubm.model;

import java.io.Serializable;

public class HyperlinksModel implements Serializable {
	
	private String ubmHyperKey;
	private String ubmHyperDescription;
	private String ubmHyperURL;
	public String getUbmHyperKey() {
		return ubmHyperKey;
	}
	public void setUbmHyperKey(String ubmHyperKey) {
		this.ubmHyperKey = ubmHyperKey;
	}
	public String getUbmHyperDescription() {
		return ubmHyperDescription;
	}
	public void setUbmHyperDescription(String ubmHyperDescription) {
		this.ubmHyperDescription = ubmHyperDescription;
	}
	public String getUbmHyperURL() {
		return ubmHyperURL;
	}
	public void setUbmHyperURL(String ubmHyperURL) {
		this.ubmHyperURL = ubmHyperURL;
	}
	
	

}
