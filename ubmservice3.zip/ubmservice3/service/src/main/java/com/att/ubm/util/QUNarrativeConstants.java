package com.att.ubm.util;


/**
 * @author kb942m
 *
 */
public class QUNarrativeConstants {
	
	public static final String PRODUCT = "PRODUCT";
	
	public static final String CHANNEL = "CHANNEL";
	
	public static final String ALTERNATE = "ALTERNA";
	
	public static final String QUICKUPDATE = "Quick Update";
	
	public static final String VOICE = "Voice";
	
	public static final String QU_TABLE_NAME = "SID_NARR";
	public static final String QU_LIST_TABLE_NAME = "SID_NARR_LIST";
	
	public static final String UBM_REQ_TABLE_NAME = "UBM_REQUEST";
	public static final String UBM_REP_TABLE_NAME = "ubm_response";
	public static final String UBM_ERROR_RESPONSE_TEXT="There was an issue with creating your request. Please contact the support team. ERROR CODE :{<ErrorCode>}";
	public static final String UBM_SUCCESS_RESPONSE_TEXT="Task <ActivityName> has been successfully completed";
	
	public static final String SID_APPROVAL_TABLE="SID_APPROVAL";
	public static final String SID_ASSIGNMENT_HISTORY_TABLE="Sid_Assignment_History";
	
	
	

}
