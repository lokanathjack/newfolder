package com.att.ubm.dao;


import java.util.Map;

import com.att.ubm.model.MyTasksModel;

public interface IMyTaskDAO {
	
	public MyTasksModel getTaskInfo(String sidId);
	public int insertAssignmentHistory(Map<String,Object> values);

}
