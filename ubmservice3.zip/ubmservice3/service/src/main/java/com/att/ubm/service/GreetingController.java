package com.att.ubm.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class GreetingController {
	private static Logger log = LoggerFactory.getLogger(GreetingController.class);

	@GetMapping("/greeting")
	public String greeting(@RequestParam(value="username", required=false, defaultValue="World") String userName, Model model)
	{
		log.info("Greeting Testing userName = " + userName);
		model.addAttribute("userName", userName);
		return "greeting";
	}
}