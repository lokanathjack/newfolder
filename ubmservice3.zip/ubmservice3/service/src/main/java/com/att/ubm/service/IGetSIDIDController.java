package com.att.ubm.service;

import java.util.Map;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.att.ubm.model.UIActionModel;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Api
@Path("/service")
public interface IGetSIDIDController {
	
	@GET
	@Path("/getSIDID")
	@Produces({ MediaType.APPLICATION_JSON })
	@ApiOperation(
			value = "Respond SIDID",
			notes = "Returns a String object of Get SIDID Info. "
					,
			response = String.class
	)
	@ApiResponses(
			value = {
					@ApiResponse(code = 404, message = "Service not available"),
					@ApiResponse(code = 500, message = "Unexpected Runtime error")
					})
	public String getNewSIDID();
	
	@GET
	@Path("/getHyperlinksDetails")
	@Produces({ MediaType.APPLICATION_JSON })
	@ApiOperation(
			value = "Respond Hyperlinks Details",
			notes = "Returns a Map object of Tooltip Info. "
					,
			response = Object.class
	)
	@ApiResponses(
			value = {
					@ApiResponse(code = 404, message = "Service not available"),
					@ApiResponse(code = 500, message = "Unexpected Runtime error")
					})
	public String getHyperlinksDetails();
	
	@GET
	@Path("/getActionButtonDetails")
	@Produces({ MediaType.APPLICATION_JSON })
	@ApiOperation(
			value = "Respond Action Button Details",
			notes = "Returns a String object with Action Button Info. "
					,
			response = Object.class
	)
	@ApiResponses(
			value = {
					@ApiResponse(code = 404, message = "Service not available"),
					@ApiResponse(code = 500, message = "Unexpected Runtime error")
					})
	public Map<String,UIActionModel> getActionButtonDetails(@QueryParam("sidType") String sidType,@QueryParam("pageName") String pageName,@QueryParam("activityName") String activityName);


}
