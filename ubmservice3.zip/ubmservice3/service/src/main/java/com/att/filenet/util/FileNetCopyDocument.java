package com.att.filenet.util;

import java.util.Iterator;
import java.util.logging.Level;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.filenet.api.collection.AccessPermissionList;
import com.filenet.api.collection.ContentElementList;
import com.filenet.api.collection.PropertyDescriptionList;
import com.filenet.api.constants.AccessLevel;
import com.filenet.api.constants.AccessType;
import com.filenet.api.constants.AutoClassify;
import com.filenet.api.constants.AutoUniqueName;
import com.filenet.api.constants.Cardinality;
import com.filenet.api.constants.CheckinType;
import com.filenet.api.constants.DefineSecurityParentage;
import com.filenet.api.constants.PermissionSource;
import com.filenet.api.constants.RefreshMode;
import com.filenet.api.constants.TypeID;
import com.filenet.api.core.ContentTransfer;
import com.filenet.api.core.Document;
import com.filenet.api.core.Factory;
import com.filenet.api.core.Folder;
import com.filenet.api.core.ObjectStore;
import com.filenet.api.core.ReferentialContainmentRelationship;
import com.filenet.api.meta.PropertyDescription;
import com.filenet.api.security.AccessPermission;
import com.filenet.api.security.Permission;

/**
 * @author sm802k
 *
 */
public class FileNetCopyDocument {

	private static Logger logger = LoggerFactory.getLogger(FileNetCopyDocument.class);
	protected void copyDocument(ObjectStore objectStore, Document sourceDoc,
			Folder targetFolder, String userId) {

		logger.info("copyDocument()", "inside copyDocument");
		try {

			sourceDoc.refresh(); //to make sure we have all its properties

			// Set props for new document
			Document targetDoc = Factory.Document.createInstance(objectStore, sourceDoc.getClassName());
			setCustomProps(sourceDoc, targetDoc);
			targetDoc.getProperties().putValue("DocumentTitle", sourceDoc.get_Name());
			targetDoc.set_Creator(userId);
			targetDoc.set_DateCreated(sourceDoc.get_DateCreated());
			//targetDoc.set_Owner(userId);
			targetDoc.save(RefreshMode.REFRESH);
			
			//get the new doc's reservation object
			Document res = (Document) targetDoc.get_Reservation();

			//add content
			ContentElementList cel = sourceDoc.get_ContentElements();
			Iterator it = cel.iterator();
			if (it.hasNext()) { //just copy the first content element; there will normally be only one
				ContentElementList list = Factory.ContentElement.createList();
				while (it.hasNext()) {
					ContentTransfer ct = (ContentTransfer) it.next();
					ContentTransfer element = Factory.ContentTransfer.createInstance();
					element.set_RetrievalName(ct.get_RetrievalName());
					element.set_ContentType(ct.get_ContentType());
					element.setCaptureSource(ct.accessContentStream());
					list.add(element);
				}
				res.set_ContentElements(list);
			}
			
			//check in document
			res.checkin(AutoClassify.DO_NOT_AUTO_CLASSIFY,CheckinType.MAJOR_VERSION);
			res.save(RefreshMode.REFRESH);
			
			//file in folder
			ReferentialContainmentRelationship rcr = targetFolder.file(res,
					AutoUniqueName.AUTO_UNIQUE, sourceDoc.get_Name(),
					DefineSecurityParentage.DEFINE_SECURITY_PARENTAGE);
			rcr.save(RefreshMode.NO_REFRESH);
			
			//reset modifier and modification date to match original
			res.refresh();
			//res.set_DateLastModified(sourceDoc.get_DateLastModified());
			res.set_LastModifier(userId);
			res.set_Permissions(newPermList(sourceDoc,userId)); //do this if you really need to preserve original owner/creator rights
			res.save(RefreshMode.NO_REFRESH);
			logger.info("copyDocument()", "Exit copyDocument");
		} catch (Exception ere) {
			ere.printStackTrace();
    		logger.info("copyDocument()", "Exception caught while copyDocument "+ere);
			
		} 

	}
	
	private void setCustomProps(Document sd, Document td) {
		PropertyDescriptionList pdl = sd.get_ClassDescription().get_PropertyDescriptions();
		PropertyDescription pd = null;
		String symbName = null;
		Iterator it = pdl.iterator();
		while (it.hasNext()) {
			pd = (PropertyDescription) it.next();
			symbName = pd.get_SymbolicName();
			Cardinality card = pd.get_Cardinality();
			//System.out.println("Symbolic name:\t"+symbName);
			if (pd.get_IsReadOnly()) continue;
			if (pd.get_IsSystemGenerated()) continue;
			if (pd.get_IsSystemOwned()) continue;

			try {
				if (pd.get_DataType() == TypeID.BINARY) {
					if (card == Cardinality.SINGLE) {
						td.getProperties().putValue(symbName, sd.getProperties().getBinaryValue(symbName));
					}
					else {
						td.getProperties().putValue(symbName, sd.getProperties().getBinaryListValue(symbName));
					}
				}
				else if (pd.get_DataType() == TypeID.BOOLEAN) {
					if (card == Cardinality.SINGLE) {
						td.getProperties().putValue(symbName, sd.getProperties().getBooleanValue(symbName));
					}
					else {
						td.getProperties().putValue(symbName, sd.getProperties().getBooleanListValue(symbName));
					}
				}
				else if (pd.get_DataType() == TypeID.DATE) {
					if (card == Cardinality.SINGLE && !symbName.equals("DateLastModified")) {
						td.getProperties().putValue(symbName, sd.getProperties().getDateTimeValue(symbName));
					}
					else {
						td.getProperties().putValue(symbName, sd.getProperties().getDateTimeListValue(symbName));
					}
				}
				else if (pd.get_DataType() == TypeID.DOUBLE) {
					if (card == Cardinality.SINGLE) {
						td.getProperties().putValue(symbName, sd.getProperties().getFloat64Value(symbName));
					}
					else {
						td.getProperties().putValue(symbName, sd.getProperties().getFloat64ListValue(symbName));
					}
				}
				else if (pd.get_DataType() == TypeID.GUID) {
					if (card == Cardinality.SINGLE) {
						td.getProperties().putValue(symbName, sd.getProperties().getIdValue(symbName));
					}
					else {
						td.getProperties().putValue(symbName, sd.getProperties().getIdListValue(symbName));
					}
				}
				else if (pd.get_DataType() == TypeID.LONG) {
					if (card == Cardinality.SINGLE) {
						td.getProperties().putValue(symbName, sd.getProperties().getInteger32Value(symbName));
					}
					else {
						td.getProperties().putValue(symbName, sd.getProperties().getInteger32ListValue(symbName));
					}
				}
				else if (pd.get_DataType() == TypeID.STRING) {
					if (card == Cardinality.SINGLE) {
						td.getProperties().putValue(symbName, sd.getProperties().getStringValue(symbName));
					}
					else {
						td.getProperties().putValue(symbName, sd.getProperties().getStringListValue(symbName));
					}
				}
			}
			catch (Exception e) {logger.error("copyDocument()", "Exception caught while copyDocument "+e);} 
			//skip any properties that have value errors
		}
	}
	
	private AccessPermissionList newPermList(Document d, String userId) {
		
		//retain current perms
		AccessPermissionList psOld = d.get_Permissions();
		AccessPermissionList psNew = Factory.AccessPermission.createList();
		for (int i=0; i<psOld.size(); i++) {
			Permission foundPerm = (Permission) psOld.get(i);
			if (foundPerm.get_GranteeName().toUpperCase().startsWith("S-1-5")) continue; //skill defunct grantees
			if (foundPerm.get_PermissionSource().equals(PermissionSource.SOURCE_PARENT)) continue; //skip inherited
			//psNew.add(foundPerm);
		}

		String docCreator = userId; //d.get_Creator();
		String docOwner = d.get_Owner();
		if (docOwner.length() > 6) docOwner = docOwner.substring(0, 6);

		docOwner = userId;
		//add creator privileges
		if (! isMechID(docCreator)) {
			AccessPermission ac = Factory.AccessPermission.createInstance();
			ac.set_AccessMask(AccessLevel.FULL_CONTROL_AS_INT);
			ac.set_AccessType(AccessType.ALLOW);
			ac.set_GranteeName(docCreator + "@ITServices.sbc.com");
			ac.set_InheritableDepth(0);
			//System.out.println("\t\tAdded creator " + docCreator);
			psNew.add(ac);
		}

		//add owner privileges
		if (! docOwner.equalsIgnoreCase(docCreator)) {
			if (! isMechID(docOwner)) {
				AccessPermission ac = Factory.AccessPermission.createInstance();
				ac.set_AccessMask(AccessLevel.FULL_CONTROL_AS_INT);
				ac.set_AccessType(AccessType.ALLOW);
				ac.set_GranteeName(docOwner + "@ITServices.sbc.com");
				ac.set_InheritableDepth(0);
				//System.out.println("\t\tAdded owner " + docOwner);
				psNew.add(ac);
			}
		}
		
		return psNew;
	}
	
	private boolean isMechID(String testUser) {
		boolean answer = false;
		if (testUser.length() == 6) {
			if (testUser.toUpperCase().startsWith("M")) {
				if (testUser.substring(1).matches("\\d+")) {
					answer = true;
				}
			}
		}
		
		return answer;
	}

}
