package com.att.ubm.service;



import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.ubm.model.UIFormFieldsModel;



@Component
public class GetUIFormFieldsController implements IGetUIFormFileldsController {
	
	@Autowired
	IUIFormFieldService formFieldService;
	
	public GetUIFormFieldsController()
	{
		
	}
	
	@Override
	public Map<String,UIFormFieldsModel> getFieldUINames(String sidType, String pageName,String activityName) {
		return formFieldService.getUIFormFieldsDetalls(sidType, pageName, activityName, null);
	}




	
	
	
}
