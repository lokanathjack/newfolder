/**
 * 
 */
package com.att.ubm.model;

import java.io.Serializable;
import java.util.List;


/**
 * @author kb942m
 *
 */
public class QUNarrativeModel implements Serializable{	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7009990709850684041L;

	private String sidId;
	
	private String sidDescription;
	
	private String sidType;
	private String sidReqType;
	private int version;
	private String versionDate;
	private String activity;
	private String creator;
	private NarrativeModel narrative;
	private List<Plans> plans;
	private String actionTaken;
	private String userIdTakingAction;
	private String comments;
	private String reasonCode;
	private String taskId;
	
	public String getSidId() {
		return sidId;
	}

	public void setSidId(String sidId) {
		this.sidId = sidId;
	}

	public String getSidDescription() {
		return sidDescription;
	}

	public void setSidDescription(String sidDescription) {
		this.sidDescription = sidDescription;
	}

	public String getSidType() {
		return sidType;
	}

	public void setSidType(String sidType) {
		this.sidType = sidType;
	}

	
	

	

	

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public NarrativeModel getNarrative() {
		return narrative;
	}

	public void setNarrative(NarrativeModel narrative) {
		this.narrative = narrative;
	}

	
	public List<Plans> getPlans() {
		return plans;
	}

	public void setPlans(List<Plans> plans) {
		this.plans = plans;
	}

	public String getActionTaken() {
		return actionTaken;
	}

	public void setActionTaken(String actionTaken) {
		this.actionTaken = actionTaken;
	}

	public String getUserIdTakingAction() {
		return userIdTakingAction;
	}

	public void setUserIdTakingAction(String userIdTakingAction) {
		this.userIdTakingAction = userIdTakingAction;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getReasonCode() {
		return reasonCode;
	}

	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}

	public String getSidReqType() {
		return sidReqType;
	}

	public void setSidReqType(String sidReqType) {
		this.sidReqType = sidReqType;
	}

	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	public String getVersionDate() {
		return versionDate;
	}

	public void setVersionDate(String versionDate) {
		this.versionDate = versionDate;
	}

	public String getActivity() {
		return activity;
	}

	public void setActivity(String activity) {
		this.activity = activity;
	}

	public String getTaskId() {
		return taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	

	
	

	

}
