package com.att.ubm.service;

import java.io.IOException;
import java.io.StringReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.QueryParam;

import org.apache.commons.lang.StringUtils;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.aft.dme2.internal.jackson.JsonNode;
import com.att.aft.dme2.internal.jackson.JsonProcessingException;
import com.att.aft.dme2.internal.jackson.map.ObjectMapper;
import com.att.it.tdc.bpm.domain.TaskData;
import com.att.it.tdc.bpm.domain.TaskDataMap;
import com.att.it.tdc.bpm.domain.TaskInfo;
import com.att.it.tdc.bpm.exception.BPMException;
import com.att.it.tdc.bpm.service.task.ITaskService;
import com.att.it.tdc.bpm.service.task.impl.TaskServiceCamundaImpl;
import com.att.ubm.camunda.CamundaUBMComponent;
import com.att.ubm.model.Description;
import com.att.ubm.model.MyTaskInfo;
import com.att.ubm.model.MyTasksData;
import com.att.ubm.model.MyTasksModel;
import com.att.ubm.util.DescriptionTokenUtil;
import com.att.ubm.util.MyTaskDueDateUtil;

@Component
public class MyTaskController implements IMyTaskContoller {

	private static final Logger logger = LoggerFactory.getLogger(MyTaskController.class);

	SimpleDateFormat format = new SimpleDateFormat("MMM dd, yyyy HH:mm aaa");
	
	SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");

	@Autowired
	IMyTaskService myTasksService;

	@Autowired
	private CamundaUBMComponent camundaUBMComponent;

	public MyTaskController() {

	}

	public MyTasksModel getTaskInfo(String id) {
		System.out.println("Enter into MyTaskController:getTaskInfo:" + id);
		if (id == null)
			id = "1";
		MyTasksModel value = myTasksService.getTaskInfo(id);
		if (value != null) {
			System.out.println("TaskName()" + value.getTaskName());
			return value;
		}
		return null;

	}

	public IMyTaskService getMyTasksService() {
		return myTasksService;
	}

	public void setMyTasksService(IMyTaskService myTasksService) {
		this.myTasksService = myTasksService;
	}

	@Override
	public MyTasksData myTaskDetails(String loggedUserId) {
		logger.info("Entry={}", "myTaskDetails()");
		MyTasksData myTasksData = new MyTasksData();

		try {
			 myTasksData = myTasksService.myTaskDetails(loggedUserId);
		} catch (Exception e) {
			logger.error("Exception={}", e.getMessage(), e);
		}

		return myTasksData;
		
	}

	@Override
	public MyTasksData getAvailableList(String loggedUserId) {
		logger.info("Entry={}", "getAvailableList()");
		MyTasksData myTasksData = new MyTasksData();

		try {
			 myTasksData = myTasksService.getAvailableList(loggedUserId);
		} catch (Exception e) {
			logger.error("Exception={}", e.getMessage(), e);
		}

		return myTasksData;
	}

	@Override
	public MyTasksData getAssignedList(String loggedUserId) {
		logger.info("Entry={}", "getAssignedList()");
		MyTasksData myTasksData = new MyTasksData();

		try {
			 myTasksData = myTasksService.getAssignedList(loggedUserId);
		} catch (Exception e) {
			logger.error("Exception={}", e.getMessage(), e);
		}

		return myTasksData;
	}

	@Override
	public Boolean start(String processKey, String jsonRequest) {
		JsonNode rootNode;
		String uid =null;
		//jsonRequest = "{\"variables\":{\"actionTaken\":{\"value\":\"Save\",\"type\":\"String\"},\"requestor\":{\"value\":\"vs252n\",\"type\":\"String\"},\"creator\":{\"value\":\"vs252n\",\"type\":\"String\"},\"sidId\":{\"value\":\"20181110003\",\"type\":\"String\"},\"sidDesc\":{\"value\":\"Testing instance 6\",\"type\":\"String\"},\"sidType\":{\"value\":\"Quick Update\",\"type\":\"String\"},\"requestType\":{\"value\":\"Standard\",\"type\":\"String\"}},\"businessKey\":\"20181110003\"}"; 
		try {
			rootNode =  new ObjectMapper().readTree(new StringReader(jsonRequest));
			uid = rootNode.get("variables").get("creator").get("value").asText();
			System.out.println("Value of creator::::" + uid.replace('"', ' ').trim()+"Vikas"); 
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ITaskService taskService = camundaUBMComponent.getCamundaTaskService(uid);
		
		System.out.println("Vlaue of JSON request :::::::::::::: " + jsonRequest);
		// TODO Auto-generated method stub
		Boolean ret = taskService.start(processKey, jsonRequest);
		return ret;
	}
	
	
	public boolean completeTask(String taskId, String taskDataMap) {
			// TODO Auto-generated method stub
			ITaskService taskService = camundaUBMComponent.getCamundaTaskService("vs252n");
			ObjectMapper mapper = new ObjectMapper();  
			TaskDataMap obj = null;
			try{
				obj = mapper.readValue(taskDataMap, TaskDataMap.class);
			}catch (JsonParseException jexc  ){
				
			}catch (JsonMappingException jmex){} catch (IOException ioexc){}
			
			return taskService.complete(taskId, obj);
		}


	public boolean claimTask(String sidId,String taskId, String loggedInUser ) {
		//String taskId= "39983cca-ef3a-11e8-bbd9-0a580ae94867";
		//loggedInUser = "vs252n";
		//ITaskService taskService = camundaUBMComponent.getCamundaTaskService(loggedInUser);
		//return taskService.claim(taskId);
		return myTasksService.claimTask(sidId,taskId, loggedInUser);
	}

	public boolean releaseClaimedTask(String sidId,String taskId ,String loggedInUser) {
		//ITaskService taskService = camundaUBMComponent.getCamundaTaskService(loggedInUser);
		//return taskService.release(taskId);
		return myTasksService.releaseClaimedTask(sidId,taskId, loggedInUser);
	}

}
