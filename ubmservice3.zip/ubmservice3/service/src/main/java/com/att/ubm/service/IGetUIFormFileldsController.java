package com.att.ubm.service;

import java.util.Map;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.json.simple.JSONArray;

import com.att.ubm.model.UIFormFieldsModel;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;


@Api
@Path("/service")
public interface IGetUIFormFileldsController {
	
	@GET
	@Path("/getFieldUINames")
	@Produces({ MediaType.APPLICATION_JSON })
	@ApiOperation(
			value = "Respond SIDID",
			notes = "Returns a String object of Get SIDID Info. "
					,
			response = String.class
	)
	@ApiResponses(
			value = {
					@ApiResponse(code = 404, message = "Service not available"),
					@ApiResponse(code = 500, message = "Unexpected Runtime error")
					})
	public Map<String,UIFormFieldsModel> getFieldUINames(@QueryParam("sidType") String sidType,@QueryParam("pageName") String pageName, @QueryParam("activityName") String activityName);
	
	

}
