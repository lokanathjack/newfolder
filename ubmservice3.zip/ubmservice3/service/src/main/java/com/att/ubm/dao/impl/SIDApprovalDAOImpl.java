/**
 * 
 */
package com.att.ubm.dao.impl;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;

import com.att.ubm.dao.ISIDApprovalDetailsDAO;
import com.att.ubm.model.SIDApprovalModel;
import com.att.ubm.util.DecoratorDate;
import com.att.ubm.util.DecoratorSQLDate;
import com.att.ubm.util.LabelCacheUtil;
import com.att.ubm.util.QUNarrativeConstants;

import java.sql.ResultSet;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

/**
 * @author kb942m
 *
 */
@Repository(value = "approvalDAO")
public class SIDApprovalDAOImpl implements ISIDApprovalDetailsDAO {

	private static final Logger logger = LoggerFactory.getLogger(SIDApprovalDAOImpl.class);

	@Autowired
	@Qualifier("ubmJdbcTemplate")
	private JdbcTemplate jdbcTemplate;

	public JdbcTemplate getMyTaskJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setMyTaskJdbcTemplate(JdbcTemplate myTaskJdbcTemplate) {
		this.jdbcTemplate = myTaskJdbcTemplate;
	}
	
	@Autowired
	@Qualifier("namedParameterJdbcTemplate")
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	public NamedParameterJdbcTemplate getNamedParameterJdbcTemplate() {
		return namedParameterJdbcTemplate;
	}

	public void setNamedParameterJdbcTemplate(NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
		this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
	}

	

	@Override
	public int insertSIDApporvalDetails(String tabName,SIDApprovalModel approvalModel) {

		SimpleJdbcInsert simpleJdbcInsert = new SimpleJdbcInsert(jdbcTemplate).withTableName(tabName);
		
		try {
			 Map<String, Object> parameters = new HashMap<String, Object>();
			    parameters.put("SID_ID", approvalModel.getSidId());
			    parameters.put("ACTIVITY_NAME", approvalModel.getActivityName());
			    parameters.put("ACTIVITY_ACTION", approvalModel.getActivityAction());
			    parameters.put("USER_ID", approvalModel.getUserId());
			    parameters.put("TASK_ID", approvalModel.getTaskId());
			    parameters.put("START_TS", DecoratorSQLDate.getCurrentSQLTimestamp());
			    int retVal= simpleJdbcInsert.execute(parameters);
			    System.out.println("Executed Successfully.."+retVal);
			    return retVal;
		} catch (DataAccessException e) {
			e.printStackTrace();
			logger.error("Exception={}", e.getMessage(), e);
		}
		return 0;

	}

	@Override
	public SIDApprovalModel getNarrativeFormValues(String sidId) {
		String selectQuery = "select SID_ID,ACTIVITY_NAME,ACTIVITY_ACTION,USER_ID,START_TS,END_TS from sid_approval where sid_id=?";
		try {
			return jdbcTemplate.queryForObject(selectQuery, new Object[] {sidId}, new ApprovalRowMapper());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	class ApprovalRowMapper implements RowMapper<SIDApprovalModel>{

		@Override
		public SIDApprovalModel mapRow(ResultSet rs, int rowNum) throws SQLException {
			SIDApprovalModel approveModel = new SIDApprovalModel();
			approveModel.setSidId(LabelCacheUtil.isNull(rs.getString("SID_ID")));
			approveModel.setActivityName(LabelCacheUtil.isNull(rs.getString("ACTIVITY_NAME")));
			approveModel.setActivityAction(LabelCacheUtil.isNull(rs.getString("ACTIVITY_ACTION")));
			approveModel.setUserId(LabelCacheUtil.isNull(rs.getString("USER_ID")));
			
			java.sql.Timestamp tmsSave_ts = rs.getTimestamp("START_TS");
			 java.util.Date dtSave_ts = DecoratorDate.sqlTimestampToDate(tmsSave_ts);
		      String sSave_ts = DecoratorDate.dateToStringInFormat(dtSave_ts, "MM/dd/yyyy hh:mm:ss a", null);
			
			approveModel.setStartTS(sSave_ts);
			
			java.sql.Timestamp tmpEnd_ts = rs.getTimestamp("END_TS");
			 java.util.Date dtEnd_ts = DecoratorDate.sqlTimestampToDate(tmpEnd_ts);
		      String sEnd_ts = DecoratorDate.dateToStringInFormat(dtEnd_ts, "MM/dd/yyyy hh:mm:ss a", null);
			
			approveModel.setStartTS(sEnd_ts);
			return approveModel;
		}

		
	}

	

	@Override
	public boolean rowExists(String tName, String sidId, String activityName) {
		SqlRowSet sqlRowSet = jdbcTemplate.queryForRowSet("select sid_id from "+tName+" where sid_id=? and ACTIVITY_NAME=?",sidId,activityName);
		if (sqlRowSet.next()) 
			return true;
		return false;
	}

	@Override
	public int updateSIDApporvalDetails(SIDApprovalModel approvalModel) {
		 
		if(approvalModel!=null)
		{
			String sqlStmt = "update "+QUNarrativeConstants.SID_APPROVAL_TABLE+" set USER_ID=?,ACTIVITY_ACTION=?,END_TS=? where SID_ID=? and TASK_ID=?";
			
			Object[] params = new Object[] { approvalModel.getUserId(),approvalModel.getActivityAction(),DecoratorSQLDate.getCurrentSQLTimestamp(),approvalModel.getSidId(),approvalModel.getTaskId() };
			return jdbcTemplate.update(sqlStmt, params);
		}
		return 0;
	}
	
	
	
	

}
