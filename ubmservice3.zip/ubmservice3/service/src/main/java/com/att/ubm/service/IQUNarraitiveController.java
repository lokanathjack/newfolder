/**
 * 
 */
package com.att.ubm.service;

import java.util.List;
import java.util.Map;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.att.ubm.model.ApprovalOption;
import com.att.ubm.model.QUNarrativeModel;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * @author kb942m
 *
 */
@Api
@Path("/service")
public interface IQUNarraitiveController {

	@GET
	@Path("/getApproverOptions")
	@Produces({ MediaType.APPLICATION_JSON })
	@ApiOperation(value = "Respond ApproverOptions", notes = "Returns a String object of Get getApproverOptions Info. ", response = String.class)
	@ApiResponses(value = { @ApiResponse(code = 404, message = "Service not available"),
			@ApiResponse(code = 500, message = "Unexpected Runtime error") })
	public ApprovalOption getApproverOptions(@QueryParam("approverType") String approverType);
	
	@POST
	@Path("/saveQUNarrative")
	@Produces({ MediaType.APPLICATION_JSON })
	@ApiOperation(value = "Respond saveNarrativeForm", notes = "Inserting a Narrative object of QU Narrative Info. ", response = String.class)
	@ApiResponses(value = { @ApiResponse(code = 404, message = "Service not available"),
			@ApiResponse(code = 500, message = "Unexpected Runtime error") })
	
	public String saveNarrativeForm(String quNarrativeModel);
	
	@GET
	@Path("/getNarrativeDetails")
	@Produces({ MediaType.APPLICATION_JSON })
	@ApiOperation(value = "Respond NarrativeDetails", notes = "Returns a String object of Get NarrativeDetails Info. ", response = String.class)
	@ApiResponses(value = { @ApiResponse(code = 404, message = "Service not available"),
			@ApiResponse(code = 500, message = "Unexpected Runtime error") })
	public QUNarrativeModel getNarrativeDetails(@QueryParam("sidId") String sidId);

	
	@GET
	@Path("/getColumnValueFromSidNarr")
	@Produces({ MediaType.TEXT_PLAIN })
	@ApiOperation(value = "Respond column Value from DB", notes = "Returns a String value from DB. ", response = String.class)
	@ApiResponses(value = { @ApiResponse(code = 404, message = "Service not available"),
			@ApiResponse(code = 500, message = "Unexpected Runtime error") })
	public String getColumnValueFromSidNarr(@QueryParam("sidId") String sidId, @QueryParam("columnName") String columnName);
	
	@GET
	@Path("/getOptionalApproversForSid")
	@Produces({ MediaType.APPLICATION_JSON })
	@ApiOperation(value = "Respond column Value from DB", notes = "Returns a List value from DB. ", response = List.class)
	@ApiResponses(value = { @ApiResponse(code = 404, message = "Service not available"),
			@ApiResponse(code = 500, message = "Unexpected Runtime error") })
	public List getOptionalApproversForSid(@QueryParam("sidId") String sidId);
	
	@POST
	@Path("/createApprovalRecords")
	@Produces({ MediaType.APPLICATION_JSON })
	@ApiOperation(value = "Respond saveNarrativeForm", notes = "Inserting a Approval object of QU Narrative Info. ", response = String.class)
	@ApiResponses(value = { @ApiResponse(code = 404, message = "Service not available"),
			@ApiResponse(code = 500, message = "Unexpected Runtime error") })
	
	public void saveApprovalRecords(Map<String,Object> values);
}
