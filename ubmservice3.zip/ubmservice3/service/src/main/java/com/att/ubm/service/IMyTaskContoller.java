package com.att.ubm.service;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.att.ubm.model.MyTaskInfo;
import com.att.ubm.model.MyTasksData;
//import com.att.ubm.model.HelloWorld;
import com.att.ubm.model.MyTasksModel;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Api
@Path("/service")
@Produces({ MediaType.APPLICATION_JSON })
public interface IMyTaskContoller {

	@GET
	@Path("/myTask")
	@Produces({ MediaType.APPLICATION_JSON })
	@ApiOperation(value = "Respond My Taks Info <id>!", notes = "Returns a JSON object of My Taks Info. ", response = MyTasksModel.class)
	@ApiResponses(value = { @ApiResponse(code = 404, message = "Service not available"),
			@ApiResponse(code = 500, message = "Unexpected Runtime error") })
	public MyTasksModel getTaskInfo(@QueryParam("id") String id);

	@GET
	@Path("/myTaskDetails")
	@Produces({ MediaType.APPLICATION_JSON })
	@ApiOperation(value = "Respond My Taks Info <id>!", notes = "Returns a JSON object of My Taks Info. ", response = MyTaskInfo.class)
	@ApiResponses(value = { @ApiResponse(code = 404, message = "Service not available"),
			@ApiResponse(code = 500, message = "Unexpected Runtime error") })
	public MyTasksData myTaskDetails(@QueryParam("loggedUserId") String loggedUserId);

	@GET
	@Path("/myAvailableTaskDetails")
	@Produces({ MediaType.APPLICATION_JSON })
	@ApiOperation(value = "Respond My Taks Info <id>!", notes = "Returns a JSON object of My Taks Info. ", response = MyTasksData.class)
	@ApiResponses(value = { @ApiResponse(code = 404, message = "Service not available"),
			@ApiResponse(code = 500, message = "Unexpected Runtime error") })
	public MyTasksData getAvailableList(@QueryParam("loggedUserId") String loggedUserId);

	@GET
	@Path("/myAssignedTaskDetails")
	@Produces({ MediaType.APPLICATION_JSON })
	@ApiOperation(value = "Respond My Taks Info <id>!", notes = "Returns a JSON object of My Taks Info. ", response = MyTasksData.class)
	@ApiResponses(value = { @ApiResponse(code = 404, message = "Service not available"),
			@ApiResponse(code = 500, message = "Unexpected Runtime error") })
	public MyTasksData getAssignedList(@QueryParam("loggedUserId") String loggedUserId);
	
	
	@POST
	@Path("/start")
	@Produces({ MediaType.APPLICATION_JSON })
	@ApiOperation(value = "Respond Starting the Camunda process!", notes = "Returns a JSON object of My Taks Info. ", response = Boolean.class)
	@ApiResponses(value = { @ApiResponse(code = 404, message = "Service not available"),
			@ApiResponse(code = 500, message = "Unexpected Runtime error") })
	//public MyTasksData getAssignedList(@QueryParam("loggedUserId") String loggedUserId);
	public Boolean start(@QueryParam("processKey") final String processKey,@QueryParam("jsonRequest") final String jsonRequest);
	
	
	@POST
	@Path("/completeTask")
	@Produces({ MediaType.APPLICATION_JSON })
	@ApiOperation(value = "Respond to completing the task in Camunda!", notes = "Returns a boolean value. ", response = Boolean.class)
	@ApiResponses(value = { @ApiResponse(code = 404, message = "Service not available"),
			@ApiResponse(code = 500, message = "Unexpected Runtime error") })
	//public MyTasksData getAssignedList(@QueryParam("loggedUserId") String loggedUserId);
	public boolean completeTask(@QueryParam("taskId") final String taskId,@QueryParam("taskDataMap") final String taskDataMap);

	
	@POST
	@Path("/claimTask")
	@Produces({ MediaType.APPLICATION_JSON })
	@ApiOperation(value = "Respond to claiming the task in Camunda!", notes = "Returns a boolean value. ", response = Boolean.class)
	@ApiResponses(value = { @ApiResponse(code = 404, message = "Service not available"),
			@ApiResponse(code = 500, message = "Unexpected Runtime error") })
	//public MyTasksData getAssignedList(@QueryParam("loggedUserId") String loggedUserId);
	public boolean claimTask(@QueryParam("sidId") String sidId,@QueryParam("taskId") final String taskId, @QueryParam("loggedUserId") String loggedUserId);

	
	@POST
	@Path("/releaseTask")
	@Produces({ MediaType.APPLICATION_JSON })
	@ApiOperation(value = "Respond to releasing the claimed task in Camunda!", notes = "Returns a boolean value. ", response = Boolean.class)
	@ApiResponses(value = { @ApiResponse(code = 404, message = "Service not available"),
			@ApiResponse(code = 500, message = "Unexpected Runtime error") })
	//public MyTasksData getAssignedList(@QueryParam("loggedUserId") String loggedUserId);
	public boolean releaseClaimedTask(@QueryParam("sidId") String sidId,@QueryParam("taskId") final String taskId,@QueryParam("loggedUserId") String loggedUserId);
	
}