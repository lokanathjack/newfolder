/**
 * 
 */
package com.att.ubm.model;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * @author kb942m
 *
 */
public class AlternateName implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4982463631330606061L;

	private String firstName;

	private String lastName;

	private String userName;

	private String name;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}


}
