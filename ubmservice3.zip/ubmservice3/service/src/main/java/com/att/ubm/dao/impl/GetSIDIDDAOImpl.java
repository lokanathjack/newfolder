package com.att.ubm.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;

import com.att.ubm.dao.IGetSIDIDDAO;
import com.att.ubm.dao.IMyTaskDAO;
import com.att.ubm.model.HyperlinksModel;
import com.att.ubm.model.MyTasksModel;
import com.att.ubm.model.UIActionModel;
import com.att.ubm.util.DecoratorDate;
import com.att.ubm.util.LabelCacheUtil;

import org.springframework.beans.factory.annotation.Qualifier;


@Repository
public class GetSIDIDDAOImpl implements IGetSIDIDDAO {
	
	@Autowired
	@Qualifier("ubmJdbcTemplate")
	private JdbcTemplate jdbcTemplate;
	
	
	
	


	public JdbcTemplate getMyTaskJdbcTemplate() {
		return jdbcTemplate;
	}


	public void setMyTaskJdbcTemplate(JdbcTemplate myTaskJdbcTemplate) {
		this.jdbcTemplate = myTaskJdbcTemplate;
	}


	@Override
	public String getNewSIDID() {
		String sqlStmt = null;
		String sidId;
		try {
			sqlStmt = "select SID_ID_SEQ.nextval from dual";
			int seqVal = jdbcTemplate.queryForObject(
					sqlStmt, Integer.class);
			sidId=DecoratorDate.dateToStringInFormat(new java.util.Date(), "yyyyMMdd", null) + DecoratorDate.formatNumber(seqVal, "000");
			System.out.println("Sididid:\t"+sidId);
			return sidId;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}


	@Override
	public List<HyperlinksModel> getHyperlinksDetails() {
		String sql = "SELECT UBM_KEY, UBM_KEY_DESCRIPTION,LINK_URL FROM UBM_HYPERLINKS";
		List<HyperlinksModel> hyperlinksList = new ArrayList<HyperlinksModel>();
		try {
			System.out.println("Enter into getHyperlinksDetails");
			
			SqlRowSet sqlRowSet = jdbcTemplate.queryForRowSet(sql);
			HyperlinksModel hyperlinksModel=null;
			while (sqlRowSet.next()) {
				hyperlinksModel=new HyperlinksModel();
				hyperlinksModel.setUbmHyperKey(LabelCacheUtil.isNull(sqlRowSet.getString("UBM_KEY")));
				hyperlinksModel.setUbmHyperDescription(LabelCacheUtil.isNull(sqlRowSet.getString("UBM_KEY_DESCRIPTION")));
				hyperlinksModel.setUbmHyperURL(LabelCacheUtil.isNull(sqlRowSet.getString("LINK_URL")));
				hyperlinksList.add(hyperlinksModel);
			}
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return hyperlinksList;
	}

	@Override
	public List<UIActionModel> getActionButtonDetails(String sidType,String pageName,String activityName) {
		/*String sql = "select B.CONFIG_PAGE,B.SID_TYPE,D.ACTIVITY_NAME,C.ACTION_ID,C.ACTION_NAME,A.ACTION_ENABLED,A.ACTION_VISIBILITY From sid_actions_info a " + 
				"JOIN sid_fields_map B on a.SID_FIELDS_MAPID=b.SID_FIELDS_MAPID JOIN UBM_ACTIONS C on C.action_id = A.action_id JOIN UBM_ACTIVTY_INFO D on D.activity_id = B.activity_id " + 
				"WHERE  D.activity_name = ? AND B.CONFIG_PAGE =? AND B.SID_TYPE =?";*/
		String sql="select PAGES.SID_PAGE_NAME as CONFIG_PAGE,STYPES.SID_TYPE_NAME as SID_TYPE,D.ACTIVITY_DESC,C.ACTION_ID,C.ACTION_NAME,A.ACTION_ENABLED,A.ACTION_VISIBILITY From sid_actions_info a " + 
				" JOIN sid_fields_map B on a.SID_FIELDS_MAPID=b.SID_FIELDS_MAPID JOIN UBM_ACTIONS C on C.action_id = A.action_id JOIN UBM_ACTIVTY_INFO D on D.activity_id = B.activity_id  " + 
				" JOIN ubm_sid_types stypes ON B.SID_TYPE_ID=STYPES.SID_TYPE_ID JOIN ubm_sid_pages pages on PAGES.SID_PAGE_ID=B.CONFIG_PAGE_ID " + 
				" WHERE  D.ACTIVITY_DESC = ? AND PAGES.SID_PAGE_NAME = ? AND STYPES.SID_TYPE_NAME = ?";
		List<UIActionModel> actionList = new ArrayList<UIActionModel>();
		try {
			System.out.println("Enter into getHyperlinksDetails::"+sidType+"::"+pageName+"::"+activityName);
			
			SqlRowSet sqlRowSet = jdbcTemplate.queryForRowSet(sql,activityName,pageName,sidType);
			UIActionModel actionModel=null;
			while (sqlRowSet.next()) {
				actionModel=new UIActionModel();
				actionModel.setPageName(LabelCacheUtil.isNull(sqlRowSet.getString("CONFIG_PAGE")));
				actionModel.setSidType(LabelCacheUtil.isNull(sqlRowSet.getString("SID_TYPE")));
				actionModel.setActivityName(LabelCacheUtil.isNull(sqlRowSet.getString("ACTIVITY_DESC")));
				actionModel.setActionId(sqlRowSet.getInt("ACTION_ID"));
				actionModel.setActionName(LabelCacheUtil.isNull(sqlRowSet.getString("ACTION_NAME")));
				actionModel.setActionEnabled(sqlRowSet.getBoolean("ACTION_ENABLED"));
				actionModel.setActionVisibility(sqlRowSet.getBoolean("ACTION_VISIBILITY"));
				actionList.add(actionModel);
			}
			System.out.println("actionList:\t"+actionList.size());
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return actionList;
	}

}
