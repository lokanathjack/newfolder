/**
 * 
 */
package com.att.ubm.model;

import java.io.Serializable;
import java.util.List;

import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * @author kb942m
 *
 */
public class QuickUpdate implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1769674732745912841L;

	private List<ChannelName> channel;

	private List<ProductName> product;

	private List<AlternateName> alternate;

	//private List<ApprovalName> approvalNameList;

	public List<ProductName> getProduct() {
		return product;
	}

	public void setProduct(List<ProductName> product) {
		this.product = product;
	}

	public List<ChannelName> getChannel() {
		return channel;
	}

	public void setChannel(List<ChannelName> channel) {
		this.channel = channel;
	}

	public List<AlternateName> getAlternate() {
		return alternate;
	}

	public void setAlternate(List<AlternateName> alternate) {
		this.alternate = alternate;
	}

	/*public List<ApprovalName> getApprovalNameList() {
		return approvalNameList;
	}

	public void setApprovalNameList(List<ApprovalName> approvalNameList) {
		this.approvalNameList = approvalNameList;
	}*/

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

}
