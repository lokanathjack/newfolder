/**
 * 
 */
package com.att.ubm.camunda;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.att.it.tdc.bpm.service.task.ITaskService;
import com.att.it.tdc.bpm.service.task.impl.TaskServiceCamundaImpl;
import com.att.ubm.model.CamundaBean;
import com.att.ubm.util.CamundaUtil;

/**
 * @author kb942m
 *
 */
@Component
public class CamundaUBMComponent {

	private static final Logger logger = LoggerFactory.getLogger(CamundaUBMComponent.class);

	@Autowired
	@Qualifier("ubmJdbcTemplate")
	private JdbcTemplate jdbcTemplate;

	public JdbcTemplate getMyTaskJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setMyTaskJdbcTemplate(JdbcTemplate myTaskJdbcTemplate) {
		this.jdbcTemplate = myTaskJdbcTemplate;
	}

	private CamundaBean getCamundaDetails() {
		CamundaBean cBean = new CamundaBean();
		logger.info("Entry{}" ,"getCamundaDetails()");
		String sql = "select value from config_nvp where name = ?";
		String camundaURL = CamundaUtil.CamundaURL;

		String camundaServerUrl = jdbcTemplate.queryForObject(sql, new Object[] { camundaURL }, String.class);
		if (camundaServerUrl != null && !camundaServerUrl.isEmpty()) {
			cBean.setCamundaServerUrl(camundaServerUrl);
		}
		logger.info("CamundaServerUrl{}" ,cBean.getCamundaServerUrl());
		return cBean;
	}

	/**
	 * 
	 * @param userId
	 * @return
	 * @throws PLException
	 */
	public ITaskService getCamundaTaskService(String userId) {

		ITaskService taskService = new TaskServiceCamundaImpl();

		try {
			CamundaBean cbean = this.getCamundaDetails();
			logger.info("CamundaServerUrl={}", new Object[] { cbean.getCamundaServerUrl() });

			taskService.init(cbean.getCamundaServerUrl()+CamundaUtil.CamundaURLPath, "vs252n", "admin", userId);

		} catch (Exception e) {
			logger.error("Exception={}", e.getMessage(), e);
		}
		return taskService;
	}

}
