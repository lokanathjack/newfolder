/**
 * 
 */
package com.att.ubm.service;

import java.util.List;
import java.util.Map;

import com.att.ubm.model.ApprovalName;
import com.att.ubm.model.ApprovalOption;
import com.att.ubm.model.QUNarrativeModel;

/**
 * @author kb942m
 *
 */

public interface IQUNarraitiveService {

	public ApprovalOption getApproverOptionsInfo( List<ApprovalName> approvalNameMapList ,String appName,String sidId);
	public String saveNarrativeForm(String quNarrativeString);
	public QUNarrativeModel getNarrativeFormValues(String sidId);
	public String getColumnValueFromSidNarr(String sidId,String columnName);
	public List getOptionalApproversForSid(String sidId);
	public int createAppprovalRecords(Map<String,Object> values);
}
