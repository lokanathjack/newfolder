package com.att.ubm.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class ConfigKCPNVPModel {
	
	@JsonIgnore
	private String sidType;
	@JsonIgnore
	private String pageName;
	@JsonIgnore
	private String key;
	private String value;
	@JsonIgnore
	private long startDisplay;
	@JsonIgnore
	private long endDisplay;
	@JsonIgnore
	private boolean loadAuotmationFlag;
	private String name;
	public String getSidType() {
		return sidType;
	}
	public void setSidType(String sidType) {
		this.sidType = sidType;
	}
	public String getPageName() {
		return pageName;
	}
	public void setPageName(String pageName) {
		this.pageName = pageName;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public long getStartDisplay() {
		return startDisplay;
	}
	public void setStartDisplay(long startDisplay) {
		this.startDisplay = startDisplay;
	}
	public long getEndDisplay() {
		return endDisplay;
	}
	public void setEndDisplay(long endDisplay) {
		this.endDisplay = endDisplay;
	}
	public boolean isLoadAuotmationFlag() {
		return loadAuotmationFlag;
	}
	public void setLoadAuotmationFlag(boolean loadAuotmationFlag) {
		this.loadAuotmationFlag = loadAuotmationFlag;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	

}
