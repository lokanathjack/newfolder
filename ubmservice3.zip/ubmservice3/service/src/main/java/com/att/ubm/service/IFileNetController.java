package com.att.ubm.service;


import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;


@Api
@Path("/service")
@Produces({ MediaType.APPLICATION_JSON })
public interface IFileNetController {

	@GET
	@Path("/createFilenetFolder")
	@Produces({ MediaType.APPLICATION_JSON })
	@ApiOperation(
			value = "Respond Folder info",
			notes = "Returns a JSON object of Folder Info. "
					,
			response = String.class
	)
	@ApiResponses(
			value = {
					@ApiResponse(code = 404, message = "Service not available"),
					@ApiResponse(code = 500, message = "Unexpected Runtime error")
					})
	public String getFilenetNavigateURL(@QueryParam("appName") String appName,@QueryParam("sidId") String sidId,@QueryParam("folderName") String folderName);
	
	@GET
	@Path("/getFileCount")
	@Produces({ MediaType.APPLICATION_JSON })
	@ApiOperation(
			value = "Respond Folder info",
			notes = "Returns a JSON object of Folder Info. "
					,
			response = Integer.class
	)
	@ApiResponses(
			value = {
					@ApiResponse(code = 404, message = "Service not available"),
					@ApiResponse(code = 500, message = "Unexpected Runtime error")
					})
	public int getFileCount(@QueryParam("appName") String appName,@QueryParam("sidId") String sidId,@QueryParam("folderName") String folderName);
	
}