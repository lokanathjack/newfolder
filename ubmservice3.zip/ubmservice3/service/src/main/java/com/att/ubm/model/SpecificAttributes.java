package com.att.ubm.model;

import java.io.Serializable;

public class SpecificAttributes implements Serializable {
	
	private String applicationChannel;

	public String getApplicationChannel() {
		return applicationChannel;
	}

	public void setApplicationChannel(String applicationChannel) {
		this.applicationChannel = applicationChannel;
	}
	
	

}
