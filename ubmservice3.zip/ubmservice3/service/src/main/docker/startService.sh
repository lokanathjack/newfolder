#!/bin/sh

nodeName=UBMService3_1.0.0_$(cat /proc/self/cgroup | grep docker | sed s/\\//\\n/g | tail -1)

export AJSC_HOME=/opt/att/ajsc
export AJSC_CONFIG_HOME=${AJSC_HOME}/config

echo "K8S_SERVER=${K8S_SERVER}"
curl_out="/tmp/curl.out"
parse_out="/tmp/parse.out"
cluster_pattern="$.metadata.labels.cluster_name"
token=`cat /var/run/secrets/kubernetes.io/serviceaccount/token`
curl -sSk -H "Authorization: Bearer ${token}" ${K8S_SERVER}/api/v1/namespaces/com-att-ocnp-cluster-info 1>${curl_out} 2>/dev/null

java -classpath "/etc:${AJSC_HOME}/lib/*:/lib/*:${AJSC_CONFIG_HOME}:${AJSC_HOME}" \
com.att.api.framework.common.utils.ClusterInfo parse ${cluster_pattern} ${curl_out} ${parse_out}

cluster_name=`cat ${parse_out}`
export MS_CLUSTER_NAME=${cluster_name}

#source /etc/run2.source
source ${AJSC_CONFIG_HOME}/run.source
