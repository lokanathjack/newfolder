package com.att.ubm.ubmservice3.pact;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import com.att.ubm.ubmservice3.pact.ITConsumerServicePact;

@RunWith(Suite.class)
@Suite.SuiteClasses({
	ITConsumerServicePact.class
	//NewConsumerServicePact.class
	//UserAccountConsumerServicePact.class
	//UverseproviderPact.class
	//FailConsumerServicePact.class
	
})
public class PactTestSuit {
}