const commonNames = require('./commonNames.js');
var tssErrorTmplGenerator = {
     generateTSSErrorTmpl : (errorObj) => {
        let errorObject = null;
        if( errorObj.errorType === commonNames.SERVICE_EXCEPTION) {
            errorObject = {
                "requestError" : {
                    "serviceException":{
                        "messageId" : errorObj.messageId,
                        "text" : errorObj.text,
                        "variables" : errorObj.variables,
                        "url" : errorObj.url
                    }
                }
            }
        } else {
            errorObject = {
                "requestError" : {
                    "policyException":{
                        "messageId" : errorObj.messageId,
                        "text" : errorObj.text,
                        "variables" : errorObj.variables,
                        "url" : errorObj.url
                    }
                }
            }
        }
        return  JSON.stringify(errorObject,null, " ");
    },

    generateMessageId : (serviceType) => {
         return messageId;
    }
}

module.exports = tssErrorTmplGenerator;