/**
 * Created by rx226f on 6/25/2018.
 */
//------------
const path = require('path');
const fs = require('fs');
const rimraf = require('rimraf');
var configuration;
const dirExist = fs.existsSync(path.resolve(process.cwd(),'config-map'));
const configDirExist = fs.existsSync(path.resolve(process.cwd(),'config'));
const ilib = require('@com.att.ajsc/ilib-nodejs');

if (dirExist) {
    if (configDirExist) {
        rimraf(path.resolve(process.cwd(),'config'),function (err) {
            if (err) {
                console.log('config folder is not found, it may removed already');
            }else {
                console.log('config folder removed');
            }
        });
    }
    configuration = require(path.resolve(process.cwd(),'./config-map/override-configs.json'));
}else {
    (function (dir) {
        try {
            fs.statSync(dir);
            console.log('config-map dir is not exist, config dir exists');
            console.log('getting configurations from config folder...');
            configuration = require(path.resolve(process.cwd(),'./config/override-configs.json'));
        } catch (e) {
            console.log('could not get config from config folder');
        }
    })('config');
}
//---------
var maskIt = () => {
    return function(key, value) {
        let maskedValue = value;
        let listToMask = configuration.SPIData || [];
        listToMask.forEach(element => {
            if(key.toLowerCase() === element.toLowerCase()) {
            maskedValue = 'xxxxxxx';
        }
    })
        return maskedValue;
    }
}

// const requestMessage = {
//     username : 'rajattur',
//     password : 'blah',
//     person : {
//         name: 'raj',
//         dob: '04/04/1984',
//         address: {
//             home: 'blah 123 blah',
//             income: {
//                 gross : 123456789
//             }
//         }
//     }
// }
// const m1 = JSON.stringify(requestMessage,maskIt());
// console.log(m1);

module.exports = maskIt;

