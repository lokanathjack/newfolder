const mongoose = require('mongoose');
mongoose.Promise = global.Promise;

const mongodbConnection = function () {
    let connection;

    const init = (config) => {
        const uri = `mongodb://${config.host}:${config.port}/${config.database}`;
        console.log(`Trying to connect to ${config.host}:${config.port}/${config.database} MongoDB database...`);

        let options = {
            autoIndex: false,
            useMongoClient: true,
            reconnectTries: 5, // Never stop trying to reconnect
            reconnectInterval: 500, // Reconnect every 500ms
            poolSize: 10, // Maintain up to 10 socket connections
            // If not connected, return errors immediately rather than waiting for reconnect
            autoReconnect: true,
            bufferMaxEntries: 0

        };

        if (config.username && config.password) {
            options.user = config.username;
            options.pass = config.password;
        }


        // options.server.socketOptions = options.replset.socketOptions = { keepAlive: 120 };
        connection = mongoose.connect(uri, options);

        connection.then(() => {
            console.log(`Connected to ${config.host}/${config.database} MongoDB database...`)
        }).catch((e) => {
            console.log(`Error connecting to ${config.host}/${config.database} MongoDB database...`)
        })

    };

    return {init}

}();

module.exports = {mongodbConnection};