const permissionThatUserShouldHave = ['com.att.ajsc.routes']

module.exports = {permissionThatUserShouldHave};