/**
 * Created by rx226f on 2/3/2018.
 */

    const appRoot = require('app-root-path');
    const app = require(appRoot.path+'/src/server/app.js');
    const request = require('supertest');
    const Lab = require('lab');
    const expect = require('code').expect;
    const lab = exports.lab = Lab.script();

    lab.test('/rest/UBMWebUI9/v1/helloworld route', (done) => {
        request(app)
            .get('/rest/UBMWebUI9/v1/helloworld')
            .expect(302)
            .then((res) => {
                //console.log(res.statusCode);
                expect(res.statusCode,'status code from /helloworld').to.equal(302);
                done()
            })
    });
