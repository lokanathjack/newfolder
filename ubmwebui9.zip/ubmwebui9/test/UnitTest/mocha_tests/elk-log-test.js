/**
 * Created by rx226f on 12/8/2017.
 */
const assert = require('chai').assert;
const appRoot = require('app-root-path');
const path = require('path');
const fs = require('fs');
const logger= require('@com.att.ajsc/1t-logging').logger;
const logConstraints = require('@com.att.ajsc/1t-logging').logConstraints;
//------------
const rimraf = require('rimraf');
var configuration;
const dirExist = fs.existsSync(path.resolve(process.cwd(),'config-map'));
const configDirExist = fs.existsSync(path.resolve(process.cwd(),'config'));

if (dirExist) {
    if (configDirExist) {
        rimraf(path.resolve(process.cwd(),'config'),function (err) {
            if (err) {
                console.log('config folder is not found, it may removed already');
            }else {
                console.log('config folder removed');
            }
        });
    }
    configuration = require(path.resolve(process.cwd(),'./config-map/override-configs.json'));
}else {
    (function (dir) {
        try {
            fs.statSync(dir);
            console.log('config-map dir is not exist, config dir exists');
            console.log('getting configurations from config folder...');
            configuration = require(path.resolve(process.cwd(),'./config/override-configs.json'));
        } catch (e) {
            console.log('could not get config from config folder');
        }
    })('config');
}
//---------

if(configuration.logging == "1t-logging") {
    describe('Testing elk logger info function', function() {
        describe('when passing fullMessage only', function() {
            it('info function should update record object with message', function(){
                var logObject = logger.info("testing log message");
                assert.equal(logObject['logType'], logConstraints.LOG_TYPE.DEBUG);
            });
        });

        describe('when passing fullMessage and a tag', function() {
            it('info function should update record object with a tag', function(){
                var logObject = logger.info("testing log message tag", ['test123']);
                assert.equal(logObject['tags'][0], 'test123');
            });
        });
    });

    describe('Testing elk logger warn function', function() {
        describe('when passing warning msg only', function() {
            it('warn function should update record object with log level warning', function(){
                var logObject = logger.warning("testing warn log message");
                assert.equal(logObject['logLevel'], logConstraints.LOG_LEVEL.WARNING);
            });
        });

        describe('when passing warning msg  and a tag', function() {
            it('warning function should update record object with a tag', function(){
                var logObject = logger.warning("testing warning message with a tag", ['test124']);
                assert.equal(logObject['tags'][0], 'test124');
            });
        });
    });

    describe('Testing elk logger error function', function() {
        describe('when passing error msg only', function() {
            it('error function should update record object with log level error', function(){
                try {
                    eval('alert("Hello world)');
                }
                catch(error) {
                    var logObject = logger.error("testing error log message", error);
                }
                assert.equal(logObject['logLevel'], logConstraints.LOG_LEVEL.ERROR);
            });
        });

        describe('when passing error msg  and a tag', function() {
            it('error function should update record object with a tag', function(){
                try {
                    eval('alert("Hello world)');
                }
                catch(error) {
                    var logObject = logger.error("testing error message with a tag", error,  ['test125']);;
                }
                assert.equal(logObject['tags'][0], 'test125');
            });
        });
    });

    describe('Testing elk logger log function', function() {
        describe('when passing log msg only', function() {
            it('log function should update record object with log level Info', function(){
                var logObject = logger.log(logConstraints.LOG_TYPE.DEBUG, logConstraints.LOG_LEVEL.INFO, "testing log message", "testing log message", []);
                assert.equal(logObject['logLevel'], logConstraints.LOG_LEVEL.INFO);
            });
        });

        describe('when passing log msg  and a tag', function() {
            it('log function should update record object with a tag', function(){
                var logObject = logger.log(logConstraints.LOG_TYPE.DEBUG, logConstraints.LOG_LEVEL.INFO,"testing log message with a tag", "testing log message with a tag", ['test126']);
                assert.equal(logObject['tags'][0], 'test126');
            });
        });
    });
}
