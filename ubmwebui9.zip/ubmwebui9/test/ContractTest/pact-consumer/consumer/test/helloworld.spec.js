const expect = require('chai').expect
const path = require('path')
const Pact = require('pact')
const getClient = require('../index');
const appRoot = require('app-root-path');
const yorc = require(appRoot.path+'/.yo-rc.json');

describe('Hello world Test', () => {
    let url = 'http://localhost'
    const port = 1234

    const provider = Pact({
        port: port,
        log: path.resolve(process.cwd(), 'logs', 'mockserver-integration.log'),
        dir: path.resolve(appRoot.path+'/test/ContractTest/pact-consumer/consumer/validated'),
        spec: 2,
        consumer: yorc["@com.att.ajsc/generator-ansc"].servicenamespace+"."+yorc["@com.att.ajsc/generator-ansc"].servicename,
        provider: yorc["@com.att.ajsc/generator-ansc"].servicenamespace+"."+yorc["@com.att.ajsc/generator-ansc"].servicename
    })

    const HELLO_WORLD = { message: 'helloworld Route GET method'}

    before((done) => {
        provider.setup()

            .then(() => {
                const getHelloUserInteraction = {
                    state: 'Hello World',
                    uponReceiving: 'Will get hello world',
                    withRequest: {
                        method: 'GET',
                        path: `/rest/${yorc["@com.att.ajsc/generator-ansc"].servicename}/v1/helloworld`,
                        headers: { 'Accept': 'application/json' }
                    },
                    willRespondWith: {
                        status: 302,
                        // headers: { 'Content-Type': 'application/json; charset=utf-8' },
                        // body: HELLO_WORLD
                    }
                };
                provider.addInteraction(getHelloUserInteraction).then(() => {
                    done()
                })

            }).catch((err) => {
            throw new Error('Unable to start the Pact Server: ' + err);
        });
    })

    it('should return hello world', function(done) {
        const urlAndPort = { url: url, port: port }
        const getclient = new getClient(urlAndPort)
        getclient.getHelloUser()
            .then((response) => {
                expect(response).to.eql(302)
                done()
            })
            .catch(done)
    })

    // verify with Pact, and reset expectations
    it('should validate the interactions and create a contract', () => {
        provider.verify()
    });

    after(() => provider.finalize());
});
