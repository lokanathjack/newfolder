
// new pact
    const pact = require('@pact-foundation/pact-node');
    const path = require('path');
    const appRoot = require('app-root-path');
    const pblookup=require(appRoot.path+'/test/ContractTest/NgnixInvoker.js');
    const logger= require('@com.att.ajsc/1t-logging').logger;
    //console.log(process.cwd())
    
    let pburl;
    
    pblookup.pactBrokerLookup(function(pburl)
        {
            console.log('pact broker url is: '+pburl);
    
            const opts = {
       // pactUrls: [path.resolve(process.cwd(),'./test/pacts/aaf_consumer-aaf_provider.json'),path.resolve(process.cwd(),'./test/pacts/helloworld_consumer-helloworld_provider.json')],
        pactUrls: [path.resolve(appRoot.path+'/test/ContractTest/pact-consumer/consumer/validated/helloworldansc7_consumer-helloworldansc7_provider.json')],
        //pactBroker: 'http://130.6.133.180:30120/',
        pactBroker: 'http://'+ pburl+'/',//'http://zlp22234.vci.att.com:30120/',
        pactBrokerUsername: 'pactadmin',
        pactBrokerPassword: 'pactadmin',
        consumerVersion: '1.0.0'
        }
            logger.info('pact brokersetting are: '+opts);
        pact.publishPacts(opts)
        .then(() => {
            logger.info('Pact contract publishing complete!');
    //        console.log('');
    //        console.log('Head over to http://zlp22234.vci.att.com:30120');
    //        console.log('to see your published contracts.');
        })
        .catch((e) => {
            logger.error('Pact contract publishing failed: ', e);
           process.exit((e) ? 1 : 0)
        })
    
        });