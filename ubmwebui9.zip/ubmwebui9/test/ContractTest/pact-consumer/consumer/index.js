const request = require('request');
const logger= require('@com.att.ajsc/1t-logging').logger;
const appRoot = require('app-root-path');
const yorc = require(appRoot.path+'/.yo-rc.json');

class PostServiceClient {
    constructor(endpoint){
        this.endpoint = endpoint;
    }

    getClient() {
        return new Promise((resolve, reject)=>{
            const options = {
                url: `${this.endpoint.url}:${this.endpoint.port}/login`,
                headers: {'Accept': 'application/json'}
            };

            request(options,(error, response, body)=>{
                if (!error && response.statusCode === 200) {
                    const result = JSON.parse(body);
                    resolve(result);
                } else {
                    logger.info('error')
                    reject(error);
                }
            });
        });
    }

    getHelloUser() {
        return new Promise((resolve, reject) => {
            const options = {
                url: `${this.endpoint.url}:${this.endpoint.port}/rest/${yorc["@com.att.ajsc/generator-ansc"].servicename}/v1/helloworld`,
                headers: {'Accept': 'application/json'}
            };
            request(options, (error, response, body) => {
                if (!error && response.statusCode === 302) {
                    // const result = JSON.parse(body)
                    resolve(response.statusCode);
                } else {
                    logger.info('error from getHelloUser function.');
                    reject(error);
                }
            });
        });
    }
}

module.exports = PostServiceClient;