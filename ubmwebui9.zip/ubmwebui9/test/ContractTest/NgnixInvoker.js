/**
 * 
**/
var enpointIterator = require('./EndpointIteratorInvocation.js');
const logger= require('@com.att.ajsc/1t-logging').logger;

var endpoints=[];

const pactBrokerLookup = function (callback) {
var  lookup;

enpointIterator("pactbroker.tta.att.com","2.16.2","TEST","DEFAULT",function(value){
	value.forEach(function(item) {
    	lookup=item.endpoint.hostAddress+":"+item.endpoint.listenPort;
    	
    });
    logger.info("apptest:Endpoints addressreturned: "+lookup);
   callback(lookup);
});
};

module.exports= {pactBrokerLookup};

