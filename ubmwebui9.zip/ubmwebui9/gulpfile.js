'use strict';
const gulp = require('gulp');
const plugins = require('gulp-load-plugins')();
const config = require('./gulp.config')();
const wiredep = require('wiredep');
const livereload = require('gulp-livereload');
const nodemon = require('gulp-nodemon');
const shell = require('gulp-shell');
const exec = require('gulp-exec');
const prompt = require('gulp-prompt');
const sonar = require('gulp-sonar');
const gutil = require('gulp-util');
const argv = require('yargs').argv;
const fs = require('fs');
const pm2 = require('pm2');
//-------------
const rimraf = require('rimraf');
const path = require('path');
var configuration;
const dirExist = fs.existsSync(path.resolve(process.cwd(),'config-map'));
const configDirExist = fs.existsSync(path.resolve(process.cwd(),'config'));

if (dirExist) {
    if (configDirExist) {
        rimraf(path.resolve(process.cwd(),'config'),function (err) {
            if (err) {
                console.log('config folder is not found, it may removed already');
            }else {
                console.log('config folder removed');
            }
        });
    }
    configuration = require(path.resolve(process.cwd(),'./config-map/override-configs.json'));
}else {
    (function (dir) {
        try {
            fs.statSync(dir);
            console.log('config-map dir is not exist, config dir exists');
            console.log('getting configurations from config folder...');
            configuration = require(path.resolve(process.cwd(),'./config/override-configs.json'));
        } catch (e) {
            console.log('could not get config from config folder');
        }
    })('config');
}
//---------

const json = JSON.parse(fs.readFileSync('./.yo-rc.json'));

const paths = {
    appScripts: 'src/client/app/**/*.js'
};

gulp.task('scripts', function () {
    return gulp.src([paths.appScripts])
        .pipe(plugins.jshint())
        .pipe(plugins.jshint.reporter(require('jshint-stylish')))
        .pipe(plugins.size());
});

//gulp.task('watch', ['serve'], function () {
  //  livereload.listen();

    //gulp.watch([
      //  'src/client/**/*.html',
      // 'src/client/app/**/*.js',
     // 'src/client/styles/*.css'
    //]).on('change', function (file) {
      //  console.log('File changed: ' + file.path);
       // livereload.changed(file.path); //YES (by itself)
        //livereload.reload(); //YES (by itself)
    //});

    //gulp.watch(paths.appScripts, ['scripts']);
//});

gulp.task('injectjs', function(){
    var target = gulp.src('./src/client/index.html');
    var sources = gulp.src([paths.appScripts]);

    return target.pipe(plugins.inject(sources, {relative: true}))
        .pipe(gulp.dest('./src/client'));

});

gulp.task('watch', function () {
    // require('opn')('http://localhost:9000');
    nodemon({
        script: './src/server/bin/www',
        watch: 'src',
        ignore: ['tmp/data.json'],
        env: { 'NODE_ENV': 'development'}
    })
});

gulp.task('sonarscan', function () {
    let options;
    options = {
        sonar: {
            host: {
                url: ''
            },
            login: '',
            password: '',
            att: {
                motsid: '',
                view: {
                    type: ''
                },
                tattletale: {
                    enabled: true
                }
            },
            projectKey: argv.motsid + ":" + json["@com.att.ajsc/generator-ansc"].servicenamespace + ":" + json["@com.att.ajsc/generator-ansc"].servicename,
            projectName: argv.motsid + ":" + json["@com.att.ajsc/generator-ansc"].servicenamespace + ":" + json["@com.att.ajsc/generator-ansc"].servicename,
            // exclusions: 'src/server/test/**/*.*',
            projectVersion: '1.0.0',
            // comma-delimited string of source directories
            sources: 'src/server',
            // tests: '/test',
            language: 'js',
            sourceEncoding: 'UTF-8',
            javascript: {
                lcov: {
                    reportPath: 'report/lcov.info'
                }
            },
            exec: {
                // All these properties will be send to the child_process.exec method (see: https://nodejs.org/api/child_process.html#child_process_child_process_exec_command_options_callback )
                // Increase the amount of data allowed on stdout or stderr (if this value is exceeded then the child process is killed, and the gulp-sonar will fail).
                maxBuffer : 1024*1024
            }
        }
    };
    options.sonar.att.motsid = argv.motsid.toString();
    options.sonar.host.url = argv.url.toString();
    options.sonar.login = argv.login.toString();
    options.sonar.password = argv.password.toString();
    options.sonar.att.view.type = argv.viewtype.toString();
        
    console.log(options);

    // gulp source doesn't matter, all files are referenced in options object above
    return gulp.src('thisFileDoesNotExist.js', { read: false })
        .pipe(sonar(options))
        .on('error', gutil.log);
});

gulp.task('webpack-dev-server', shell.task([
    'npm run webpack-dev-server'
]));

gulp.task('clean-dist', shell.task([
    'npm run clean-dist && npm run build'
]));

gulp.task('webpack-build', shell.task([
    'echo Cleaning dist folder and building new files...',
    'npm run clean-dist && npm run build'
]));

 gulp.task('start', shell.task([
     'npm start'
 ]));

gulp.task('docker-build-image', shell.task([
    'docker build -f Dockerfile -t ubmwebui9 .'
]));

gulp.task('docker-run', shell.task([
    'docker run -d -p 8096:8096 ubmwebui9'
]));

gulp.task('docker-login', shell.task([
    'docker login dockercentral.it.att.com:5100'
]));

gulp.task('docker-deploy', shell.task([
    'docker tag ubmwebui9 dockercentral.it.att.com:5100/com.att.ajsc/ubmwebui9',
    'docker push dockercentral.it.att.com:5100/com.att.ajsc/ubmwebui9'
]));


// gulp.task('connect', function () {
//     // var connect = require('connect');
//     // var serveStatic = require('serve-static')
//     //
//     // var app = connect()
//     //     .use(serveStatic('src'));
//     //
//     // require('http').createServer(app)
//     //     .listen(9000)
//     //     .on('listening', function () {
//     //         console.log('Started connect web server on http://localhost:9000');
//     //     });
// });

gulp.task('wiredep', function () {
    var options = config.getWiredepDefaultOptions();
    var wiredep = require('wiredep').stream;

    return gulp
        .src(config.index)
        .pipe(wiredep(options))
        .pipe(plugins.inject(gulp.src(config.js), { relative: true }))
        .pipe(gulp.dest('src/client'));
});