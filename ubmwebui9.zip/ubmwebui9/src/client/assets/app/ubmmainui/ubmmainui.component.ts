import { Component, OnInit } from '@angular/core';
import {Router,RouterModule, NavigationExtras, Routes} from "@angular/router";
import { FormGroup, FormControl } from '@angular/forms';
import { SidDescMenu } from '../model/commonSidData.model';
import { Http } from '@angular/http';
import { environment } from 'environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthService } from '../messages/http.service';

@Component({
  selector: 'app-ubmmainui',
  templateUrl: './ubmmainui.component.html',
  styleUrls: ['./ubmmainui.component.css']
})
export class UbmmainuiComponent implements OnInit {
  cookieValue : string[] = [];
  public constructor(private http:Http,private router: Router,private sidDescMenu: SidDescMenu,private httpClient:HttpClient,private auth:AuthService) { }
apiRoot= environment.apiUrl;
  valueStr: string;
  valueStrSID: string;
  version:string
  versionDate:string;
  activity:string;
  cookieServiceGet: string[] = [];
 commSidType='';
 commRequestType='';
 commSidRestriction='';
  formdata;
  ngOnInit() {
    let taskelement:HTMLElement=document.getElementById('application') as HTMLElement;
    taskelement.className = 'nav-link title-head active ml20';
    this.formdata = new FormGroup({
      commSidType: new FormControl('Quick Update'),
      commRequestType: new FormControl('Standard'),
      commSidRestriction: new FormControl('None')
      });
      this.search('Moo');
    //   this.auth.callEnvService()
    //         .subscribe(
    //             (response:any) => {
    //                 const data = response;
    //                 console.log("env URL:" + data);
                  
    //             },
    //             (error) => {
    //                 if (error) {
    //                     console.log(error)
                      
    //                 }
    //             }
    //         )
      
  }

  search(term: string) {
    let promise = new Promise((resolve, reject) => {
      this.http.get(this.apiRoot+'/restservices/helloworld/v1/service/getSIDID')
        .toPromise()
        .then(
          res => { // Success
            this.sidDescMenu.originalJson=res.json();
            this.valueStrSID=res.json()["sidId"];
            this.version=res.json()["version"];
            this.versionDate=res.json()["versionDate"];
            this.activity=res.json()["activity"];
            console.log(this.valueStrSID);
            this.sidDescMenu.setSidId(this.valueStrSID);
            this.sidDescMenu.setVersion(this.version);
            this.sidDescMenu.setVersionDate(this.versionDate);
            this.sidDescMenu.setActivity(this.activity);
            console.log(this.sidDescMenu.getSidId()+":this.activity="+this.activity);
          },
          msg => { // Error
            reject(msg);
          }
        );
    });
    return promise;
  }
  
  public onSubmit(data) {
    this.sidDescMenu.setSidType(data.commSidType);
    this.sidDescMenu.setRequestType(data.commRequestType);
    this.sidDescMenu.setSidRestriction(data.commSidRestriction);    
    //this.router.navigate(["narrative"]);
         let navigationExtras: NavigationExtras = {
                 queryParams: {
                     "sidId": this.sidDescMenu.getSidId(),
                     "sidType": data.commSidType,
                     "sidReqType": data.commRequestType,
                     "sidRestriction": data.commSidRestriction,
                     "version" : this.version,
                     "versionDate" : this.versionDate,
                     "taskName" :  btoa(this.activity)
                    }
             };
         this.router.navigate(["/narrative"], navigationExtras);
       }


}
