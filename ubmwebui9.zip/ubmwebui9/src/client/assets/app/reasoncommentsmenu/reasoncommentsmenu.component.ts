import { Component, OnInit, Input } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { environment } from 'environments/environment';
import { SidDescMenu } from '../model/commonSidData.model';
import { multipledropdown } from '../model/multipledropdown.model';

@Component({
  selector: 'app-reasoncommentsmenu',
  templateUrl: './reasoncommentsmenu.component.html',
  styleUrls: ['./reasoncommentsmenu.component.css']
})
export class ReasoncommentsmenuComponent implements OnInit {
  public requesttype: string;
  public sidID : string;
  apiRoot= environment.apiUrl;
  activity :string;
  reasonForm: FormGroup;
  submitted = false;
  params:any;
  ubmFileds : any;
  dataNarReasonCode=[];
  reasonCode =[];
  reasonCodeList:multipledropdown[] = [];
  singledropdownSettings = {};

  constructor(private httpClient:HttpClient,private route: ActivatedRoute,public sidDescMenu: SidDescMenu,private formBuilder: FormBuilder) { 
  }

  ngOnInit() {
    

    this.reasonForm = this.formBuilder.group({
      reasonCode: ['',Validators.compose(this.setRequired(true))],
      NarrativeComments:['',Validators.compose(this.setRequired(true))],
      });

    this.route.queryParams.subscribe(params => {
      this.sidID = params["sidId"];
      let taskName = params["taskName"];
      this.requesttype=params["requestType"];
      let cmId=params["cmId"];
      
      if(taskName!=undefined){
        taskName=atob(taskName)
      }
     
      if(cmId ==undefined){
        this.dataNarReasonCode.push('N/A');
        this.dataNarReasonCode = JSON.parse(JSON.stringify(this.dataNarReasonCode));
        this.sidDescMenu.setreasonCode('N/A');
      }else{
        this.getNarrativeDatabySIDId(this.sidID);
      }
      this.getFormControlData(taskName)
      this.markets(this.requesttype,this.sidID,'Narrative');
    });

    this.singledropdownSettings = {
      singleSelection: true,
      idField: 'item_id',
      textField: 'item_text',
      itemsShowLimit: 3,
      allowSearchFilter: true
  };
  }
 
  public onSelectReason(items: any){
  }

  public getNarrativeDatabySIDId(sidId) {
    var url = this.apiRoot+'/restservices/helloworld/v1/service/getNarrativeDetails?sidId='+sidId;
    this.httpClient.get(url).subscribe( data => {
    if(data!=null){
      this.reasonForm.setControl('NarrativeComments',new FormControl(data['comments'],Validators.required));
        if(data['reasonCode']!='' && data['reasonCode']!=undefined){
          this.dataNarReasonCode.push(data['reasonCode']);
          this.dataNarReasonCode = JSON.parse(JSON.stringify(this.dataNarReasonCode));
     }else{
          this.dataNarReasonCode=[];
     }
       }
    });
}
get f() {
  return this.reasonForm.controls;
  }

  validateChildForm(): Boolean {
       return  this.reasonCommentsForm(this.reasonForm)
     }

     reasonCommentsForm(reasonForm){
        this.submitted=true;
        if(!reasonForm.valid ) {
            console.log("Invalid:::::reason comnets form");
              return false;
          } else {
              console.log("reason comments form:::::success");
              return true;
          }   
    }

    getReasonCommentsData(){
      if(this.reasonForm.get('reasonCode')!=null){
      if(this.reasonForm.get('reasonCode').value[0]!="" && this.reasonForm.get('reasonCode').value[0]!=undefined){
        this.sidDescMenu.setreasonCode(this.reasonForm.get('reasonCode').value[0]);
         }else{ this.sidDescMenu.setreasonCode(""); }}else{
          this.sidDescMenu.setreasonCode("");
         }
         if(this.reasonForm.get('NarrativeComments').value!=null){
         this.sidDescMenu.setcomments(this.reasonForm.get('NarrativeComments').value);
         }else{
          this.sidDescMenu.setcomments("");
         }
    }



  getFormControlData(activityName){ 
        var url = this.apiRoot+'/restservices/helloworld/v1/service/getFieldUINames?sidType=QUICKUPDATE&pageName=NARRATIVE&activityName='+activityName; 
        this.httpClient.get(url).subscribe( data => { 
          this.ubmFileds=data; 
          //this.reasonForm.get('NarrativeComments').setValidators(this.setRequired(this.ubmFileds['908'].isMandatory));
          //this.reasonForm.get('reasonCode').setValidators(this.setRequired(this.ubmFileds['169'].isMandatory));
          if(!this.ubmFileds['908'].isEnabled){
             this.reasonForm.controls['NarrativeComments'].disable();
          }
          if(!this.ubmFileds['169'].isEnabled){
            this.reasonForm.controls['reasonCode'].disable();
         }
        });
      }

      public markets(sidtype,sidid,screenname) {
        let url=this.apiRoot+'/restservices/helloworld/v1/service/getConfigDetails?sidType='+sidtype+'&pageName='+screenname+'&sidId='+sidid
        this.httpClient.get(url).subscribe( data => {
               this.reasonCode = JSON.parse(data["REASON CODE"]);
              for (var i = 0; i < this.reasonCode.length; i++) {
                let valueRessonCode = this.reasonCode[i];
                let multipledropdownOption = new multipledropdown();
                multipledropdownOption.item_id = valueRessonCode.name;
                multipledropdownOption.item_text = valueRessonCode.name;
                this.reasonCodeList.push(multipledropdownOption);
                this.reasonCodeList = JSON.parse(JSON.stringify(this.reasonCodeList));
              }
      });
    }
      setRequired(condition) {
        if(condition===true) {
            return [Validators.required];
        } else {
            return [];
        }   
    }

}
