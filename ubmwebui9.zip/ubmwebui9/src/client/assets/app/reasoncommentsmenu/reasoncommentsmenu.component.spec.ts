import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReasoncommentsmenuComponent } from './reasoncommentsmenu.component';

describe('ReasoncommentsmenuComponent', () => {
  let component: ReasoncommentsmenuComponent;
  let fixture: ComponentFixture<ReasoncommentsmenuComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReasoncommentsmenuComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReasoncommentsmenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
