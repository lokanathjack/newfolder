
export class multipledropdown {
    public item_id: string;
    public item_text: string;

    constructor(){};
    
}