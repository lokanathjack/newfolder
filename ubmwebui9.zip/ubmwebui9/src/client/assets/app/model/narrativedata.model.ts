import { User } from "./user.model";
import { BDContact } from "./bdcontact.model";
import { ListItem } from "ng-multiselect-dropdown/multiselect.model";
export class NarrativeModel{
    requestorName: string;
    requestor: User = new User;
    bdContactName: string;
    bdContact: BDContact = new BDContact;
    requestedDate: string;
    sidRestriction: string;
    telegenceImpacted: string;
    itProposedDate: string;
    titanEnablerProposedImplementationDate: string;
    narrativeProvidedBy: string;
    narrativeTimeAndDateProvided: string;
    markets: string[]=[];
    narrative: string;
    titanEnabledImpacted: string;
    products: string;
    productApprovers: string[]=[];
    requiredCoreApproval: string[]=[];
    friendlyName : string;
    impactWifi:string;
    marketNarOverallReq:string;
    marketNarComments:string;
    narrativeText:string;
    requestedRDDate:string;
    constructor(){};
}