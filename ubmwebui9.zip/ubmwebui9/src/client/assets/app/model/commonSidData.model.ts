import { Injectable } from "@angular/core";

@Injectable()
export class SidDescMenu {
    public sidType: string;
    public requestType: string;
    public sidRestriction: string;
    public sidid: string;
    version : string;
    versionDate : Date;
    sidDescription : string;
    originalJson : string;
    activity : string;
    ubmFormContralData : any;
    public _firstName: string;
    reasonCode:string;
    comments:string;

    public getreasonCode(): string {
        return this.reasonCode;
    }
    public setreasonCode(value: string) {
        this.reasonCode = value;
    }
    public getcomments(): string {
        return this.comments;
    }
    public setcomments(value: string) {
        this.comments = value;
    }

    public get firstName(): string {
        return this._firstName;
    }
    public set firstName(value: string) {
        this._firstName = value;
    }
    public _lastName: string;
    public get lastName(): string {
        return this._lastName;
    }
    public set lastName(value: string) {
        this._lastName = value;
    }
    public _attuid: string;
    public get attuid(): string {
        return this._attuid;
    }
    public set attuid(value: string) {
        this._attuid = value;
    }
    constructor(){};
    
    public setSidDesc(sidDescription){
        this.sidDescription=sidDescription;
    }
    public getSidDesc(){
        return this.sidDescription;
    }

    public setVersionDate(versionDate){
        this.versionDate=versionDate;
    }
    public getVersionDate(){
        return this.versionDate;
    }

    public setVersion(version){
        this.version=version;
    }
    public getVersion(){
        return this.version;
    }
    public setSidType(sidType){
        this.sidType=sidType;
    }
    public getSidType(){
        return this.sidType;
    }
    public setRequestType(requestType){
        this.requestType=requestType;
    }
    public getRequestType(){
        return this.requestType;
    }
    public setSidRestriction(sidRestriction){
        this.sidRestriction=sidRestriction;
    }
    public getSidRestriction(){
        return this.sidRestriction;
    }

    public setSidId(sidid){
        this.sidid=sidid;
    }
    public getSidId(){
        return this.sidid;
    }

     public setActivity(activity){
        this.activity=activity;
    }
    public getActivity(){
        return this.activity;
    }
  }