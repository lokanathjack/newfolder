export class User {
    title: string;
    phone: string;
    emailId: string;
    'firstName': string;
    'attuid': string;
    'lastName': string;
    'ubmKeyDescription':string;
    'toolTip':string;
    'isEnabled':string;
    'fieldVisibility':string;
    'fieldRegex':string;
    requestorPhone: string;
    requestorEmailId: string;
    constructor(){};
}