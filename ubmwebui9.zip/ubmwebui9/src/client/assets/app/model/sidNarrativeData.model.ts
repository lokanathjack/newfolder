import { NarrativeModel } from  "./narrativedata.model" ;
export class SidNarrativeData{
     sidId : string  ;
     sidDescription :string ;
     sidType :string ;
     sidReqType :string ;
     version :string ;
     versionDate :Date ;
     activity:string;
     narrative :  NarrativeModel= new NarrativeModel;
    actionTaken :string ;
    userIdTakingAction :string ;
    comments :string ;
    reasonCode :string;
    creator:string;
    taskId:string;
    
}
