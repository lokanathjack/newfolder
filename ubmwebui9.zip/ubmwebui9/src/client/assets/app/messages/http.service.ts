import { Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from "@angular/common/http";
import 'rxjs/Rx';
import { environment } from 'environments/environment';
@Injectable()

export class AuthService {
    constructor(private http: HttpClient) {}

    callAuthService(value: any) {
        const aaf = '/rest/UBMWebUI9/v1/login';
        const body = {
            username: value.username,
            password: value.password
        }
        return this.http.post(aaf,body,{observe: 'body'})
            .map((results) => {
                return results
            })

    }
  
   callEnvService() { 
        console.log("START-HTTP  COMPONENT:: callEnvService();"); 
        const url = '/rest/UBMWebUI9/v1/envRouter'; 
        return this.http.get(url,{observe: 'body'}).map((result) => { 
                console.log("from http cmpt:result==="+result); 
                return result; 
            },(error) => {
                console.log("from http cmpt:Error on getting env URL====="+error);
            })
            // let promise = new Promise((resolve, reject) => {
            //     this.http.get(url)
            //         .toPromise()
            //         .then(
            //             res => { // Success
            //                 console.log("HTTP  COMPONENT ::URL respobnse=====" + res);
            //                 environment.apiUrl=JSON.stringify(res);
            //             },
            //             msg => { // Error
            //                 reject("HTTP COMPONENT ::::URL Error=====" + msg);
            //             }
            //         );
            // });
            // console.log("START-HTTP  COMPONENT:: callEnvService();"); 
            // return promise;
        }
 
    getUser(token:string) {
        console.log('getUser function called form httpservice')
        const user = '/rest/UBMWebUI9/v1/user/mike';
        return this.http.get(user,{observe: 'body',headers: new HttpHeaders().set('Authorization',token)})
            .map((result) => {
                return result;
            })

    }


}