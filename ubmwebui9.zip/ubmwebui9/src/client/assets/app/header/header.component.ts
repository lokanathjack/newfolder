import { Component, OnInit, HostListener } from '@angular/core';
import { SidDescMenu } from '../model/commonSidData.model';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  @HostListener('window:unload', ['$event'])
unloadHandler(event) {
    console.log('unloadHandler');
}
  constructor(private sidDescMenu: SidDescMenu,private cookieService: CookieService ) { }
firstname: string;
  ngOnInit() {
    this.firstname = this.sidDescMenu._firstName;
  }

  logout(){
    this.cookieService.deleteAll();
 window.open(location.href,"_self").close(); 
 //win.close();
  //window.close();
  }
}
