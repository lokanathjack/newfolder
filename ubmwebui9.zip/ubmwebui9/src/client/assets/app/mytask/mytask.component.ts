import { Component, OnInit, ViewChild, AfterViewInit, OnDestroy, Renderer2 } from '@angular/core';
import { Http,Response } from '@angular/http';
import { Subject } from 'rxjs';
import { DataTableDirective } from 'angular-datatables';
import { environment } from 'environments/environment';
import { SidDescMenu } from '../model/commonSidData.model';
import { Router, NavigationExtras } from '@angular/router';

@Component({
  selector: 'app-mytask',
  templateUrl: './mytask.component.html',
  styleUrls: ['./mytask.component.css']
})


export class MytaskComponent implements OnInit,AfterViewInit,OnDestroy {
  @ViewChild(DataTableDirective)
  dtElement: DataTableDirective;

  dtOptions: any= {};
  dtTrigger: Subject<any> = new Subject();
  url:string=environment.apiUrl;
  apiRoot: string = '';
  attuid: string;
  constructor(private http: Http, private sidMenu:SidDescMenu, private router: Router, private renderer: Renderer2) {
   }
   //httpdata;
  ngOnInit() {
    let pageName:HTMLElement=document.getElementById('pageName') as HTMLElement;
    pageName.textContent="My Tasks";
    let taskelement:HTMLElement=document.getElementById('application') as HTMLElement;
    taskelement.className = 'nav-link title-head ml20';
    this.attuid=this.sidMenu.attuid;
     this.apiRoot=this.url+'/restservices/helloworld/v1/service/myAssignedTaskDetails?loggedUserId='+this.attuid;
     this.getMyTaskDetails(this.apiRoot,false);
   }

   ngAfterViewInit(): void {
      this.dtTrigger.next();
      this.apiRoot=this.url+'/restservices/helloworld/v1/service/myAvailableTaskDetails?loggedUserId='+this.attuid;
      this.getMyTaskDetails(this.apiRoot,true);
  }

  ngOnDestroy(): void {
    this.dtTrigger.unsubscribe();
  }

  onChangeTaskStatus(value){

    if(value=='Assigned'){ //Assigned //Available
      this.apiRoot=this.url+'/restservices/helloworld/v1/service/myAvailableTaskDetails?loggedUserId='+this.attuid;
        this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
        dtInstance.destroy();
        this.getMyTaskDetails(this.apiRoot,true);
        this.dtTrigger.next();
       });
    }else{
      this.apiRoot=this.url+'/restservices/helloworld/v1/service/myAssignedTaskDetails?loggedUserId='+this.attuid;
      this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
        dtInstance.destroy();
        this.getMyTaskDetails(this.apiRoot,false);
        this.dtTrigger.next();
       });
     }
    }

     routebytask(sidID,taskName){
     alert("SID ID="+sidID+"::taskName="+taskName);
        let navigationExtras: NavigationExtras = {
                queryParams: {
                    "sidID": sidID,
                    "taskName":taskName
                }
            };
            alert("SID ID="+sidID+"::taskName="+taskName);
        this.router.navigate(["/narrative"], navigationExtras);
      }

   public getMyTaskDetails(apiRoot,flag){
    this.dtOptions = {
      ajax: {
        "url":apiRoot,
        "type": "GET",
        "error": function (e) {
          console.log("exception in my task data table==="+e)
        },
        "dataSrc": function (data) {
          if(data.data==undefined){
            return ""
          }else{
           return data.data
          }
        }
        },
      columns: [{
        title: ' ',
        data : 'sidId',
        "render": function(data, type, full, meta){
          data = '<input type="checkbox" id=task_'+data+'>';
           return data;
        }
      },
      // {
      //   title: 'No',
      //   "render": function ( data, type, full, meta ) {
      //     return  meta.row+1;
      // }
      // },
      {
        title: 'SID ID',
        data:'sidId',
        "render": function(data, type, full, meta){
          if(full.dueFlag){
            data = '<span class="asterisk">'+ data +'</span>';
          }else{
            data = '<span>'+ data +'</span>';
          }
           return data;
        }
      },{
        title: 'Task',
        data: 'taskName',
        "render": function(data,type, full, meta){
          //data = '<a href="/narrative" [routerLink]="[/narrative]" style="position: relative;" (click)="routebytask('+full.sidId+','+data+');" routerLinkActive="active">'+data+'</a>';
          let taskname= btoa(data);
          data = '<a href=/narrative?sidId='+full.sidId+'&taskName='+taskname+'&cmId='+full.id+'&flag='+flag+'>'+data+'</a>';
          return data;
        }
      },{
        title: 'SID Description',
        data:'sidDescription',
        "render": function(data, type, full, meta){
          if(full.dueFlag){
            data = '<span class="asterisk">'+ data +'</span>';
          }else{
            data = '<span>'+ data +'</span>';
          }
           return data;
        }
      },{
        title: 'Creator',
        data: 'creator',
        "render": function(data, type, full, meta){
          if(full.dueFlag){
            data = '<span class="asterisk">'+ data +'</span>';
          }else{
            data = '<span>'+ data +'</span>';
          }
           return data;
        }
      },{
        title: 'Request Type',
        data:'requestType',
        "render": function(data, type, full, meta){
          if(full.dueFlag){
            data = '<span class="asterisk">'+ data +'</span>';
          }else{
            data = '<span>'+ data +'</span>';
          }
           return data;
        }
      },{
        title: 'Assigned Date',
        data:'assignmentDate',
        "render": function(data, type, full, meta){
          if(full.dueFlag){
            data = '<span class="asterisk">'+ data +'</span>';
          }else{
            data = '<span>'+ data +'</span>';
          }
           return data;
        }
      },{
        title: 'Due Date',
        data:'dueDate',
        "render": function(data, type, full, meta){
          if(full.dueFlag){
            data = '<span class="overdue-logo img-left"><span class="asterisk">'+ data +'</span></span>';
          }else{
            data = '<span>'+ data +'</span>';
          }
           return data;
        }
      },{
        title: 'tempDueDate',
        data:'tempDueDate'
      },{
        title:'tempAssignmentDate',
        data:'tempAssignmentDate'
      }
    ],
      columnDefs:[{ "targets": [0],"orderable": false },
                  { "targets": [8], visible: false},
                  { "targets": [9], visible: false},
                  { "targets": [7], orderData:8},
                  { "targets": [6], orderData:9},
                  { "targets": [0,8,9],className: 'noVis'}
                ],
        dom: 'Bfrtip',
        buttons: [{
          extend: 'colvis',
          columns: ':not(.noVis)'
      }],
        "order": [8, "asc" ],
    };
   }
   public getNarrativeDatabySIDId(sidID,activity) {
    let promise = new Promise((resolve, reject) => {
      this.http.get(this.apiRoot+'/restservices/helloworld/v1/service/getNarrativeDetails?sidId='+sidID)
        .toPromise()
        .then(
          res => { 
             res.json();
             console.log("reponse==="+res.json);
          },
          msg => { // Error
            reject(msg);
          }
        );
    });
    return promise;
  }
}