import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { SidDescMenu } from './model/commonSidData.model';
import { environment } from 'environments/environment';
@Injectable({
  providedIn: 'root'
})
export class CommonserviceService {

  //apiRoot: string = 'http://zltv6463.vci.att.com:30102/restservices/helloworld/v1/service/createFilenetFolder?appName=';
  apiRoot= environment.apiUrl;
  appname : string;
  sidId : string;
  folderName : string;
  constructor(private http:Http,private httpClient:HttpClient,private sidDescMenu: SidDescMenu) { }
  

  fileNetService(foldername): Observable<string> {
     this.appname = 'mobility';
     this.sidId = this.sidDescMenu.getSidId();
     this.folderName=foldername;
     var url = this.apiRoot+'/restservices/helloworld/v1/service/createFilenetFolder?appName='+this.appname+'&sidId='+this.sidId+'&folderName='+this.folderName;
     console.log('url'+url);
    return this.httpClient.get(url,{responseType:'text'});
}
getFormControlData(){
  //var url = this.apiRoot+'/restservices/helloworld/v1/service/getFieldUINames?sidType='+sidType+'&pageName='+pageName+'&activityName='+activityName;
  var url = this.apiRoot+'/restservices/helloworld/v1/service/getFieldUINames?sidType=QUICKUPDATE&pageName=NARRATIVE&activityName=Start';
  this.httpClient.get(url).subscribe( data => {
    this.sidDescMenu.ubmFormContralData=data;
   console.log(this.sidDescMenu.ubmFormContralData);
  });
 }

}
