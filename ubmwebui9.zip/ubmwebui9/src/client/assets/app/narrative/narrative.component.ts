import { Component, OnInit, ViewChild, AfterViewInit, OnDestroy } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Http } from '@angular/http';
import { HttpClient, HttpHeaders, HttpRequest } from '@angular/common/http'
import { ActivatedRoute } from "@angular/router";
import { SidDescMenu } from '../model/commonSidData.model';
import { User } from '../model/user.model';
import { multipledropdown } from '../model/multipledropdown.model';
import { CommonserviceService } from "../commonservice.service";
//import { environment } from '../../environments/environment';
import { environment } from 'environments/environment';
import { SidNarrativeData } from '../model/sidNarrativeData.model';
import { SiddescriptionmenuComponent } from '../siddescriptionmenu/siddescriptionmenu.component';
import { DatePipe } from '@angular/common';
import { AppComponent } from '../app.component';
import { ReasoncommentsmenuComponent } from '../reasoncommentsmenu/reasoncommentsmenu.component';
import { DataTableDirective } from 'angular-datatables';
import { Subject } from 'rxjs';


@Component({
  selector: 'app-narrative',
  templateUrl: './narrative.component.html',
  styleUrls: ['./narrative.component.css']
})

export class NarrativeComponent implements OnInit,AfterViewInit,OnDestroy{
  @ViewChild(DataTableDirective)
  dtElement: DataTableDirective;

  dtOptions: any= {};
  dtTrigger: Subject<any> = new Subject();
  narrativeForm: FormGroup;
  apiRoot = environment.apiUrl;
  keys: String[];
  valueStr: string;
  valueStrWebPhone = [];
  valueStrWebPhoneF = [];
  valueStrGroup: User[];
  valueFinanceApprover = [];
  bdContactList: multipledropdown[] = [];
  mouseOver = [];
  valueRequiredCoreAppover = [];
  valueRequiredCoreAppoverList: string[] = [];
  valueProductAppover = [];
  productApproverList: multipledropdown[] = [];
  valueproductApproverList: string[] = [];
  valueChannelAppover = [];
  valueAlternateAppover = [];
  reqdropdownList: multipledropdown[] = [];
  selectedItems = [];
  singledropdownSettings = {};
  multidropdownSettings = {};
  reasonCodeList: multipledropdown[] = [];
  valuMarkets = [];
  reasonCode = [];
  marketContactList: multipledropdown[] = [];
  submitted = false;
  saved = false;
  sidNarrativeData: SidNarrativeData = new SidNarrativeData;
  narrativeOriginalData: SidNarrativeData = new SidNarrativeData;
  public requesttype: string;
  public sidID: string;
  public sidRestriction: string;
  loggedRequestor: string;
  error = false;
  modelFlag: boolean = false;
  formValidFlag: boolean = false;
  requesterselectItems = [];
  bdContactSelectItems = [];
  selectedmarketContactList = [];
  //dataNarReasonCode=[];
  dataNarOptionalPrdAppr = []
  nrtveData: any;
  itTelegenceprovided: string;
  narrativeTimeAndDateProvided: string;
  saveBtnFlag: boolean = false;
  submitBtnFlag: boolean = false;
  rejectBtnFlag: boolean = false;
  emailBtnFlag: boolean = false;
  cancelBtnflag: boolean = false;
  approveBtnFlag: boolean = false;
  submitdisFlag: boolean = false
  approvedisFlag: boolean = false;
  activityName: string;
  acBtndisableNP: boolean = true;
  params: any;
  claimBtnFlag: boolean = false;
  cmTaskId: string;
  ubmFileds: any;
  serviceStatusCode: number;
  serviceStatusMsg: string;
  rejected = false;
  commentsErrorFlag = false;
  reasonCodeErrorFlag = false;
  modelSuccessFlag = true;
  todayDate: Date;
  invalidDate = false;
  originalJson: any;
  invalidITPropDate = false;
  invalidTEIDate = false;
  narrativePageTab = true;
  approvalPageTab = false;
  
  private uiFiledValidationValues: any = {
    requestorName: true,
    bdContactName: true,
    requestedDate: true,
    sidRestriction: true,
    telegenceImpacted: true,
    itProposedDate: true,
    titanEnablerProposedImplementationDate: true,
    narrativeProvidedBy: true,
    narrativeTimeAndDateProvided: true,
    titanEnabledImpacted: true,
    friendlyName: true,
    marketNarOverallReq: true,
    impactWifi: true,
    marketNarComments: true,
    NarrativeComments: true,
    narrativeText: true,
    dataNarrRDDate: true,
    productApprovers: true,
    marketFormContol: true
  };


  constructor(private http: Http, private httpClient: HttpClient, private route: ActivatedRoute, private sidDescMenu: SidDescMenu, private sidp8: CommonserviceService,
    private formBuilder: FormBuilder, private datepipe: DatePipe, private appComponent: AppComponent) {
  }

  @ViewChild(SiddescriptionmenuComponent) private siddescriptionmenuComponent: SiddescriptionmenuComponent;
  @ViewChild(ReasoncommentsmenuComponent) private reasoncommentsmenuComponent: ReasoncommentsmenuComponent;
  ngOnInit() {
    this.appComponent.spinner = true;

    let taskelement: HTMLElement = document.getElementById('application') as HTMLElement;
    taskelement.className = 'nav-link title-head active ml20';

    let brdPageName: HTMLElement = document.getElementById('pageName') as HTMLElement;
    brdPageName.textContent = 'Application';

    this.todayDate = new Date();

    this.getApprovalPageDetails(this.sidID);

    //On page load calling all services 
    //this.sidID=this.sidDescMenu.getSidId();
    //this.requesttype=this.sidDescMenu.getRequestType();
    this.searchGroup('Moo');
    this.searchGroupFinance('Moo');
    this.requiredCoreApprovers();
    this.productApprovers();

    this.route.queryParams.subscribe(params => {
      let taskName = params["taskName"];
      let clmflag = params["flag"];
      let cmId = params["cmId"];
      this.sidID = params["sidId"];
      this.requesttype = params["requestType"];
      this.sidDescMenu.setSidId(params["sidId"]);
      this.sidDescMenu.setSidType(params["sidType"]);
      this.sidDescMenu.setRequestType(params['sidReqType']);
      this.sidDescMenu.setSidRestriction(params["sidRestriction"]);
      this.sidDescMenu.setVersion(params['version']);
      this.sidDescMenu.setVersionDate(params['versionDate']);

      if (taskName != undefined) {
        this.activityName = atob(taskName);
      }
      this.sidDescMenu.setActivity(this.activityName);
      if (this.sidDescMenu.originalJson == undefined) {
        this.getOriginalJsonData();
        this.sidDescMenu.originalJson = this.originalJson;
      }
      if (clmflag != undefined) {
        if (clmflag == 'false') {
          this.acBtndisableNP = true;
        } else {
          this.acBtndisableNP = false;
        }
      }
      if (cmId != undefined) {
        this.cmTaskId = cmId;
      } else { this.cmTaskId = ""; }


      if (cmId == undefined) {
        console.log("START-CREATING NEW SID & TASK");
        let requesterItems = new multipledropdown();
        requesterItems.item_id = this.sidDescMenu._attuid;
        requesterItems.item_text = this.sidDescMenu._firstName + ',' + this.sidDescMenu._lastName + ':' + this.sidDescMenu._attuid
        this.requesterselectItems.push(requesterItems);
        this.requesterselectItems = JSON.parse(JSON.stringify(this.requesterselectItems));
        this.webphone(this.sidDescMenu._attuid);
        this.getActionButtonDetails(this.requesttype, 'Narrative', this.sidDescMenu.getActivity());
        this.getFormControlData(this.sidDescMenu.getActivity())
        this.acBtndisableNP = true;
        this.markets(this.requesttype, this.sidID, 'Narrative');
        //this.dataNarReasonCode.push('N/A');
        // this.dataNarReasonCode = JSON.parse(JSON.stringify(this.dataNarReasonCode));
        this.appComponent.spinner = false;
      } else {
        console.log("LOADING EXISITNG DATA FROM SERVICE=" + this.sidID)

        var url = this.apiRoot + '/restservices/helloworld/v1/service/getNarrativeDetails?sidId=' + this.sidID;
        this.httpClient.get(url).subscribe(data => {
          console.log("data=======" + JSON.stringify(data));
          this.sidDescMenu.originalJson = JSON.parse(JSON.stringify(data));
          this.nrtveData = data['narrative'];
          this.sidDescMenu.setSidId(data['sidId']);
          this.sidDescMenu.setSidDesc(data['sidDescription']);
          this.sidDescMenu.setSidType(data['sidType']);
          this.sidDescMenu.setRequestType(data['sidReqType']);
          this.sidDescMenu.setVersion(data['version']);
          this.sidDescMenu.setVersionDate(data['versionDate']);
          this.sidNarrativeData.userIdTakingAction = this.sidDescMenu.attuid;
          this.sidDescMenu.setActivity(this.activityName);

          //reason codes and markets service call
          this.markets(data['sidReqType'], this.sidID, 'Narrative');
          //requester
          if (this.nrtveData.requestorName != "") {
            var reqattuid = this.nrtveData.requestorName.split(":")[1];
            this.webphone(reqattuid);
            let requesterItems = new multipledropdown();
            requesterItems.item_id = reqattuid;
            requesterItems.item_text = this.nrtveData.requestorName;
            this.requesterselectItems.push(requesterItems);
            this.requesterselectItems = JSON.parse(JSON.stringify(this.requesterselectItems));
          }
          //bd contact
          if (this.nrtveData.bdContactName != "") {
            var bdattuid = this.nrtveData.bdContactName.split(":")[1];
            this.webphonef(bdattuid);
            let bdItems = new multipledropdown();
            bdItems.item_id = bdattuid;
            bdItems.item_text = this.nrtveData.bdContactName;
            this.bdContactSelectItems.push(bdItems);
            this.bdContactSelectItems = JSON.parse(JSON.stringify(this.bdContactSelectItems));
          }

          for (var i = 0; i < this.nrtveData.markets.length; i++) {
            let valueGroup = this.nrtveData.markets[i];
            this.selectedmarketContactList.push(valueGroup);
            this.selectedmarketContactList = JSON.parse(JSON.stringify(this.selectedmarketContactList));
          }

          for (var i = 0; i < this.nrtveData.productApprovers.length; i++) {
            let valueGroup = this.nrtveData.productApprovers[i];
            this.dataNarOptionalPrdAppr.push(valueGroup);
            this.dataNarOptionalPrdAppr = JSON.parse(JSON.stringify(this.dataNarOptionalPrdAppr));
          }
          //if(data['reasonCode']!=''){
          //     this.dataNarReasonCode.push(data['reasonCode']);
          //     this.dataNarReasonCode = JSON.parse(JSON.stringify(this.dataNarReasonCode));
          // }else{
          //      this.dataNarReasonCode=[];
          // }
          let reqdate;
          if (this.nrtveData.requestedDate != "" && this.nrtveData.requestedDate != undefined) {
            reqdate = this.convertDateServicetoUI(this.nrtveData.requestedDate);
          }
          let itPraDate;
          if (this.nrtveData.itProposedDate != "" && this.nrtveData.itProposedDate != undefined) {
            itPraDate = this.convertDateServicetoUI(this.nrtveData.itProposedDate);
          }
          let titanEPIdate;
          if (this.nrtveData.titanEnablerProposedImplementationDate != "" && this.nrtveData.titanEnablerProposedImplementationDate != undefined) {
            titanEPIdate = this.convertDateServicetoUI(this.nrtveData.titanEnablerProposedImplementationDate);
          }
          let reqRDDate;
          if (this.nrtveData.requestedRDDate != "" && this.nrtveData.requestedRDDate != undefined) {
            reqRDDate = this.convertDateServicetoUI(this.nrtveData.requestedRDDate);
          }
          this.narrativeForm.setControl('requestedDate', new FormControl(reqdate));
          this.narrativeForm.setControl('sidRestriction', new FormControl(this.nrtveData.sidRestriction));
          this.narrativeForm.setControl('telegenceImpacted', new FormControl(this.nrtveData.telegenceImpacted));
          this.narrativeForm.setControl('itProposedDate', new FormControl(itPraDate));
          this.narrativeForm.setControl('titanEnablerProposedImplementationDate', new FormControl(titanEPIdate));
          this.narrativeForm.setControl('narrativeProvidedBy', new FormControl(this.nrtveData.narrativeProvidedBy));
          this.narrativeForm.setControl('narrativeTimeAndDateProvided', new FormControl(this.nrtveData.narrativeTimeAndDateProvided));
          this.narrativeForm.setControl('titanEnabledImpacted', new FormControl(this.nrtveData.titanEnabledImpacted));
          this.narrativeForm.setControl('friendlyName', new FormControl(this.nrtveData.friendlyName));
          this.narrativeForm.setControl('marketNarOverallReq', new FormControl(this.nrtveData.marketNarOverallReq));
          this.narrativeForm.setControl('impactWifi', new FormControl(this.nrtveData.impactWifi));
          this.narrativeForm.setControl('marketNarComments', new FormControl(this.nrtveData.marketNarComments));
          //this.narrativeForm.setControl('NarrativeComments',new FormControl(data['comments']));
          this.narrativeForm.setControl('narrativeText', new FormControl(this.nrtveData.narrativeText));
          this.narrativeForm.setControl('dataNarrRDDate', new FormControl(reqRDDate));
          this.itTelegenceprovided = this.nrtveData.narrativeProvidedBy;
          this.narrativeTimeAndDateProvided = this.nrtveData.narrativeTimeAndDateProvided;
          this.getActionButtonDetails(data['sidType'], 'Narrative', this.activityName);
          this.getFormControlData(this.activityName);
          this.appComponent.spinner = false;
        });//end -getNarrativeDetails
      }
    });
    this.narrativeForm = this.formBuilder.group({
      //requestorName: [''],
      requestorName: ['', Validators.compose(this.setRequired(this.uiFiledValidationValues.requestorName, 'requestorName'))],
      requestorphone: [''],
      requestoremailId: [''],
      requestedDate: [''],
      // requestedDate:  ['',Validators.compose(this.setRequired(this.uiFiledValidationValues.requestedDate,'requestedDate'))],
      bdContactName: ['', this.setRequired(this.uiFiledValidationValues.bdContactName, 'bdContactName')],
      bdContactphone: [''],
      bdContactemailId: [''],
      //marketNarOverallReq:[''],
      marketNarOverallReq: ['', Validators.compose(this.setRequired(this.uiFiledValidationValues.marketNarOverallReq, 'marketNarOverallReq'))],
      friendlyName: ['No'],
      //productApprovers:[''],
      productApprovers: ['', Validators.compose(this.setRequired(this.uiFiledValidationValues.productApprovers, 'productApprovers'))],
      impactWifi: ['No'],
      telegenceImpacted: [''],
      requiredCoreApproval: [],
      titanEnabledImpacted: [''],
      sidRestriction: [this.sidDescMenu.getSidRestriction()],
      //marketFormContol:[''],
      marketFormContol: ['', Validators.compose(this.setRequired(this.uiFiledValidationValues.marketFormContol, 'marketFormContol'))],
      itProposedDate: [''],
      titanEnablerProposedImplementationDate: [''],
      dataNarrRDDate: [''],
      marketNarComments: [''],
      NarrativeComments: [''],
      reasonCode: [''],
      narrativeText: [''],
      cmTaskID: []
    });

    this.singledropdownSettings = {
      singleSelection: true,
      idField: 'item_id',
      textField: 'item_text',
      itemsShowLimit: 3,
      allowSearchFilter: true
    };

    this.multidropdownSettings = {
      singleSelection: false,
      idField: 'item_id',
      textField: 'item_text',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 3,
      allowSearchFilter: true
    };
  } //on init end


  public openDocumentumWindow(p8Foldername) {
    var foldername = p8Foldername;
    var p8url = '';
    this.sidp8.fileNetService(foldername).subscribe(data => {
      console.log(data)
      window.open(data);
    });
  }

  public onChangeR(item: any) {
    this.webphone(item.item_id);
  }
  public onChangeF(item: any) {
    console.log("items===" + item)
    this.webphonef(item.item_id);
  }

  get f() {
    return this.narrativeForm.controls;
  }

  enterForm(narrativeForm) {
    this.submitted = true;
    this.error = true;
    let flag = this.siddescriptionmenuComponent.validateChildForm();

    console.log("NARRATIVE : SIDDISCRIPTION form Flag=" + flag);
    if (flag) {
      if (!narrativeForm.valid) {
        console.log("INValid::::NARRATIVE");
        return;
      } else {
        // success code comes here.
        this.formValidFlag = true;
        this.error = false;
        console.log("Valid:::::NARRATIVE");
      }
    }
  }

  onSaveFormValidation(narrativeForm) {
    this.saved = true;
    this.error = true;
    let flag = this.siddescriptionmenuComponent.validateChildForm();
    console.log("NARRATIVE :onSaveFormValidation: SIDDISCRIPTION form Flag=" + flag);
    if (flag) {
      this.formValidFlag = true;
      if (!narrativeForm.valid) {
        console.log("onSaveFormValidation:INValid::");
        this.error = false;
      } else {
        this.error = false;
        console.log("onSaveFormValidation Valid:");
      }
    }
  }
  onRejectFormValidation(narrativeForm) {
    this.rejected = true;
    this.error = true;
    this.invalidTEIDate = false;
    this.invalidITPropDate = false;

    let flag = this.reasoncommentsmenuComponent.validateChildForm();
    console.log("reason form flag=========" + flag)
    if (!narrativeForm.valid) {
      console.log("onRejectFormValidation:INValid::");
      if (flag) {
        console.log("onRejectFormValidation Valid:");
        this.formValidFlag = true;
        this.error = false;
      }
    } else {
      if (flag) {
        console.log("onRejectFormValidation Valid:");
        this.formValidFlag = true;
        this.error = false;
      }
    }
  }
  submitForm(button) {
    this.reasoncommentsmenuComponent.getReasonCommentsData();
    this.sidNarrativeData.sidId = this.sidDescMenu.getSidId();
    this.sidNarrativeData.creator = this.sidDescMenu._attuid;
    this.sidNarrativeData.userIdTakingAction = this.sidDescMenu._attuid;
    this.sidNarrativeData.sidDescription = this.sidDescMenu.getSidDesc();
    this.sidNarrativeData.sidType = this.sidDescMenu.getSidType();
    this.sidNarrativeData.sidReqType = this.sidDescMenu.getRequestType();
    this.sidNarrativeData.version = this.sidDescMenu.getVersion();
    this.sidNarrativeData.versionDate = this.sidDescMenu.getVersionDate();
    this.sidNarrativeData.activity = this.sidDescMenu.getActivity();
    if (this.cmTaskId != "" && this.cmTaskId != undefined) {
      this.sidNarrativeData.taskId = this.cmTaskId;
    } else { this.sidNarrativeData.taskId = ""; }
    this.sidNarrativeData.narrative.requestorName = this.narrativeForm.get('requestorName').value[0].item_text;
    if (this.narrativeForm.get('bdContactName').value[0] != undefined) {
      this.sidNarrativeData.narrative.bdContactName = this.narrativeForm.get('bdContactName').value[0].item_text;
    } else { this.sidNarrativeData.narrative.bdContactName = ""; }
    console.log("this.narrativeForm.value.requestedDate===" + this.narrativeForm.get('requestedDate').value);
    if (this.narrativeForm.get('requestedDate').value != "" && this.narrativeForm.get('requestedDate').value != undefined) {
      this.sidNarrativeData.narrative.requestedDate = this.convertDateUItoService(this.narrativeForm.get('requestedDate').value)
    } else { this.sidNarrativeData.narrative.requestedDate = ""; }
    this.sidNarrativeData.narrative.sidRestriction = this.narrativeForm.value.sidRestriction;
    this.sidNarrativeData.narrative.telegenceImpacted = this.narrativeForm.value.telegenceImpacted;
    if (this.narrativeForm.get('itProposedDate').value != "" && this.narrativeForm.get('itProposedDate').value != undefined) {
      this.sidNarrativeData.narrative.itProposedDate = this.convertDateUItoService(this.narrativeForm.get('itProposedDate').value);
    } else { this.sidNarrativeData.narrative.itProposedDate = ""; }
    if (this.narrativeForm.get('titanEnablerProposedImplementationDate').value != "" && this.narrativeForm.get('titanEnablerProposedImplementationDate').value != undefined) {
      this.sidNarrativeData.narrative.titanEnablerProposedImplementationDate = this.convertDateUItoService(this.narrativeForm.get('titanEnablerProposedImplementationDate').value);
    } else { this.sidNarrativeData.narrative.titanEnablerProposedImplementationDate = ""; }
    this.sidNarrativeData.narrative.narrativeProvidedBy = this.narrativeForm.value.narrativeProvidedBy;
    this.sidNarrativeData.narrative.narrativeTimeAndDateProvided = this.narrativeForm.value.narrativeTimeAndDateProvided;
    this.sidNarrativeData.narrative.markets = this.narrativeForm.get('marketFormContol').value;
    this.sidNarrativeData.narrative.titanEnabledImpacted = this.narrativeForm.value.titanEnabledImpacted;
    this.sidNarrativeData.narrative.productApprovers = this.narrativeForm.get('productApprovers').value;
    this.sidNarrativeData.actionTaken = button;
    this.sidNarrativeData.narrative.marketNarComments = this.narrativeForm.value.marketNarComments;
    this.sidNarrativeData.narrative.narrativeText = this.narrativeForm.value.narrativeText;
    this.sidNarrativeData.comments = this.sidDescMenu.getcomments();
    this.sidNarrativeData.reasonCode = this.sidDescMenu.getreasonCode();
    this.sidNarrativeData.narrative.friendlyName = this.narrativeForm.value.friendlyName;
    this.sidNarrativeData.narrative.impactWifi = this.narrativeForm.value.impactWifi;
    this.sidNarrativeData.narrative.marketNarOverallReq = this.narrativeForm.value.marketNarOverallReq;
    if (this.narrativeForm.get('dataNarrRDDate').value != "" && this.narrativeForm.get('dataNarrRDDate').value != undefined) {
      this.sidNarrativeData.narrative.requestedRDDate = this.convertDateUItoService(this.narrativeForm.get('dataNarrRDDate').value);
    } else { this.sidNarrativeData.narrative.requestedRDDate = ""; }
    var jsonArr;
    var jsonStr = JSON.stringify(this.sidDescMenu.originalJson);
    var jsonMod = JSON.stringify(this.sidNarrativeData);
    var obj = [];
    obj.push(JSON.parse(jsonStr));
    obj.push(JSON.parse(jsonMod));
    jsonArr = JSON.stringify(obj);
    console.log("Submit Flag-formValidFlag==" + this.formValidFlag + "::InValid Date Flag=" + this.invalidDate +
      "::::InvalidITPropDate Date Flag=" + this.invalidITPropDate + "::::invalidTEIDate Date Flag=" + this.invalidTEIDate);
    console.log(jsonArr);

    //this.formValidFlag = false;
    if (this.formValidFlag && !this.invalidDate && !this.invalidITPropDate && !this.invalidTEIDate) {
      this.appComponent.spinner = true;
      this.http.post(this.apiRoot + '/restservices/helloworld/v1/service/saveQUNarrative', jsonArr).subscribe(
        (val) => {
          console.log('POST call successful value returned in body===', val);
          let body;
          let subBody;
          let errorCode;
          let errornumber: number = 200;
          this.serviceStatusCode = val.status;
          body = val['_body'];
          console.log("Body========" + body);
          subBody = body.split(",")[1];
          errorCode = body.split(",")[3];
          console.log("errorCode========" + errorCode);
          errornumber = parseInt(errorCode.split(":")[1]);
          console.log("errornumber========" + errornumber);
          if (errornumber == 400) {
            console.log("error message need to show");
            this.modelSuccessFlag = false;
          }
          this.serviceStatusMsg = subBody.split(":")[1] + subBody.split(":")[2];
          this.serviceStatusMsg = this.serviceStatusMsg.split('"')[1];
          console.log("this.serviceStatusMsg========" + this.serviceStatusMsg);
          //this.serviceStatusMsg.split(",")[1];
          //console.log("Body==="+JSON.parse(JSON.stringify(val))['_body']+"serviceStatusCode="+this.serviceStatusCode);
        },
        response => {
          console.log('POST call in error', response);
        },
        () => {
          console.log('The POST observable is now completed.');
          this.modelFlag = true;
          this.appComponent.spinner = false;
        });
    } else {
      this.error = true;
    }
  }

  onItemSelect(item: any) {
    console.log(item);
  }

  onItemSelectProducts(item: any) {
    console.log("single =item for prodcucts=" + item);
  }

  onSelectAll(items: any) {
    console.log(items);
  }
  onSelectAllProducts(items: any) {
    console.log("items for Products===" + items);
  }

  public requiredCoreApprovers() {
    let promise = new Promise((resolve, reject) => {
      this.http.get(this.apiRoot + '/restservices/helloworld/v1/service/getAllGroupMembers?groupName=CoreApprovers')
        .toPromise()
        .then(
          res => { // Success
            //console.log(res.json());
            let multipledropdownOption;
            this.valueRequiredCoreAppover = res.json();
            for (var i = 0; i < this.valueRequiredCoreAppover.length; i++) {
              let valueGroup = this.valueRequiredCoreAppover[i];

              multipledropdownOption = valueGroup.firstName + ',' + valueGroup.lastName + ':' + valueGroup.attuid;
              this.valueRequiredCoreAppoverList.push(multipledropdownOption);
              this.valueRequiredCoreAppoverList = JSON.parse(JSON.stringify(this.valueRequiredCoreAppoverList));
            }
            this.sidNarrativeData.narrative.requiredCoreApproval = this.valueRequiredCoreAppoverList;
          },
          msg => { // Error
            reject(msg);
          }
        );
    });
    return promise;
  }
  searchMouseOver(term: string) {
    let promise = new Promise((resolve, reject) => {
      this.http.get(this.apiRoot + '/restservices/helloworld/v1/service/getMouseOverText?screenName=Narrative')
        .toPromise()
        .then(
          res => { // Success
            this.mouseOver = res.json();
          },
          msg => { // Error
            reject(msg);
          }
        );
    });
    return promise;
  }

  public searchGroupFinance(term: string) {
    let promise = new Promise((resolve, reject) => {
      this.http.get(this.apiRoot + '/restservices/helloworld/v1/service/getAllGroupMembers?groupName=Finance%20Approver')
        .toPromise()
        .then(
          res => { // Success
            //console.log(res.json());
            this.valueFinanceApprover = res.json();
            for (var i = 0; i < this.valueFinanceApprover.length; i++) {
              let valueGroup = this.valueFinanceApprover[i];
              let multipledropdownOption = new multipledropdown();
              multipledropdownOption.item_id = valueGroup.attuid;
              multipledropdownOption.item_text = valueGroup.firstName + ',' + valueGroup.lastName + ':' + valueGroup.attuid;
              this.bdContactList.push(multipledropdownOption);
              this.bdContactList = JSON.parse(JSON.stringify(this.bdContactList));
            }
          },
          msg => { // Error
            reject(msg);
          }
        );
    });
    return promise;
  }

  public searchGroup(term: string) {
    let promise = new Promise((resolve, reject) => {
      this.http.get(this.apiRoot + '/restservices/helloworld/v1/service/getAllGroupMembers?groupName=Requestor')
        .toPromise()
        .then(
          res => { // Success
            //console.log(res.json());
            this.valueStrGroup = res.json();
            for (var i = 0; i < this.valueStrGroup.length; i++) {
              let valueGroup = this.valueStrGroup[i];
              let multipledropdownOption = new multipledropdown();
              multipledropdownOption.item_id = valueGroup.attuid;
              multipledropdownOption.item_text = valueGroup.firstName + ',' + valueGroup.lastName + ':' + valueGroup.attuid;
              this.reqdropdownList.push(multipledropdownOption);
              this.reqdropdownList = JSON.parse(JSON.stringify(this.reqdropdownList));
            }
          },
          msg => { // Error
            reject(msg);
          }
        );
    });
    return promise;
  }

  public webphone(term: string) {
    let promise = new Promise((resolve, reject) => {
      this.http.get(this.apiRoot + '/restservices/helloworld/v1/service/requestor?attuid=' + term)
        .toPromise()
        .then(
          res => { // Success
            this.valueStrWebPhone = res.json();
            this.sidNarrativeData.userIdTakingAction = term;
            this.sidNarrativeData.narrative.requestor.requestorPhone = this.valueStrWebPhone['requstorPhone'];
            this.sidNarrativeData.narrative.requestor.requestorEmailId = this.valueStrWebPhone['requestorEmailId'];
          },
          msg => { // Error
            reject(msg);
          }
        );
    });
    return promise;
  }

  public webphonef(term) {
    let url = this.apiRoot + '/restservices/helloworld/v1/service/requestor?attuid=' + term
    this.httpClient.get(url).subscribe(data => {
      //console.log("requestor data=======>"+JSON.parse(JSON.stringify(data))['requstorPhone']);
      this.valueStrWebPhoneF = JSON.parse(JSON.stringify(data));
      this.sidNarrativeData.narrative.bdContact.bdPhone = this.valueStrWebPhoneF['requstorPhone'];
      this.sidNarrativeData.narrative.bdContact.bdEmailId = this.valueStrWebPhoneF['requestorEmailId'];
    });
  }

  public markets(sidtype, sidid, screenname) {
    let url = this.apiRoot + '/restservices/helloworld/v1/service/getConfigDetails?sidType=' + sidtype + '&pageName=' + screenname + '&sidId=' + sidid
    this.httpClient.get(url).subscribe(data => {
      this.valuMarkets = JSON.parse(data["MARKETS"]);
      //this.reasonCode = JSON.parse(data["REASON CODE"]);
      for (var i = 0; i < this.valuMarkets.length; i++) {
        let valueGroup = this.valuMarkets[i];
        //console.log("valueGroup====="+valueGroup);
        let multipledropdownOption = new multipledropdown();
        multipledropdownOption.item_id = valueGroup.name;
        multipledropdownOption.item_text = valueGroup.name;
        this.marketContactList.push(multipledropdownOption);
        this.marketContactList = JSON.parse(JSON.stringify(this.marketContactList));
      }
    });
  }
  //product approvers list
  productApprovers() {
    let url = this.apiRoot + '/restservices/helloworld/v1/service/getApproverOptions?approverType=Quick Update'
    this.httpClient.get(url).subscribe(data => {
      // console.log("coreApproval--data=======>"+data["quickUpdate"]["product"]);
      let multipledropdownOption;
      this.valueProductAppover = data["quickUpdate"]["product"];
      for (var i = 0; i < this.valueProductAppover.length; i++) {
        let valueGroup = this.valueProductAppover[i];
        multipledropdownOption = valueGroup.name + ':' + valueGroup.firstName + ',' + valueGroup.lastName + ':' + valueGroup.userName;
        this.productApproverList.push(multipledropdownOption);
        this.productApproverList = JSON.parse(JSON.stringify(this.productApproverList));
      }
    });
  }

  public getNarrativeDatabySIDId(nrtveData) {
    //reuse purpose don't delete
  }
  public getActionButtonDetails(sidType, pageName, activityName) {
    var url = this.apiRoot + '/restservices/helloworld/v1/service/getActionButtonDetails?sidType=Quick Update&pageName=' + pageName + '&activityName=' + activityName;
    //console.log("urllll="+url);
    if (activityName != undefined) {
      this.httpClient.get(url).subscribe(data => {
        if (data['SAVE'] != undefined) {
          this.saveBtnFlag = data['SAVE']['actionEnabled'];
        }
        if (data['SUBMIT'] != undefined) {
          this.submitBtnFlag = data['SUBMIT']['actionEnabled'];
          this.submitdisFlag = data['SUBMIT']['actionVisibility'];
        }
        if (data['REJECT'] != undefined) {
          this.rejectBtnFlag = data['REJECT']['actionEnabled'];
        }
        if (data['EMAIL COMMENTS'] != undefined) {
          this.emailBtnFlag = data['REJECT']['actionEnabled'];
        }
        if (data['CANCEL'] != undefined) {
          this.cancelBtnflag = data['CANCEL']['actionEnabled'];
        }
        if (data['APPROVE'] != undefined) {
          this.approveBtnFlag = data['APPROVE']['actionEnabled'];
          this.approvedisFlag = data['APPROVE']['actionVisibility'];
        }
        console.log("saveFlag=" + this.saveBtnFlag + "::submitFlag=" + this.submitBtnFlag + "::rejectFlag=" +
          this.rejectBtnFlag + "::cancelflag=" + this.cancelBtnflag + ":approveFlag=" + this.approveBtnFlag + ":submitdisFlag=" +
          this.submitdisFlag + ":approvedisFlag=" + this.approvedisFlag);
      });
    }
  }
  public claimUnclaim(event) {
    console.log("called claim unclaim method==" + event);
    if (event == 'UnClaim') {
      var releaseTaskurl = this.apiRoot + '/restservices/helloworld/v1/service/releaseTask?taskId=' + this.cmTaskId + '&loggedUserId=' + this.sidDescMenu._attuid;
      this.http.post(releaseTaskurl, this.params).subscribe(data => {
        console.log("data===of uncalim task==" + data);
        if (data.status == 200) {
          this.acBtndisableNP = false;
        } else {
          console.log("data==else=of uncalim task==" + data);
          this.acBtndisableNP = false;
        }
      });
    } else if (event == 'Claim') {
      var claimTaskUrl = this.apiRoot + '/restservices/helloworld/v1/service/claimTask?taskId=' + this.cmTaskId + '&loggedUserId=' + this.sidDescMenu._attuid;
      this.http.post(claimTaskUrl, this.params).subscribe(data => {
        console.log("data===of calim task==" + data);
        if (data.status == 200) {
          this.acBtndisableNP = true;
          this.modelFlag == true;
        } else {
          console.log("data==else=of uncalim task==" + data);
          this.acBtndisableNP = false;
          this.modelFlag == false;
        }
      });
    }
  }
  public getFormControlData(activityName) {
    var url = this.apiRoot + '/restservices/helloworld/v1/service/getFieldUINames?sidType=QUICKUPDATE&pageName=NARRATIVE&activityName=' + activityName;
    //console.log("UI Fields URL==="+url); 
    this.httpClient.get(url).subscribe(data => {
      this.sidDescMenu.ubmFormContralData = data;
      //console.log("this.sidDescMenu.ubmFormContralData..."+this.sidDescMenu.ubmFormContralData); 
      this.ubmFileds = this.sidDescMenu.ubmFormContralData;
      this.siddescriptionmenuComponent.ubmHeaderFields = this.sidDescMenu.ubmFormContralData;

      this.narrativeForm.get('requestorName').setValidators(this.setRequired(this.ubmFileds['893'].isMandatory, 'requestorName'));
      if (!this.ubmFileds['893'].isEnabled) {
        this.narrativeForm.controls['requestorName'].disable();
      }

      this.narrativeForm.get('requestedDate').setValidators(this.setRequired(this.ubmFileds['32'].isMandatory, 'requestedDate'));
      if (!this.ubmFileds['32'].isEnabled) {
        this.narrativeForm.controls['requestedDate'].disable();
      }

      this.narrativeForm.get('bdContactName').setValidators(this.setRequired(this.ubmFileds['898'].isMandatory, 'bdContactName'));
      if (!this.ubmFileds['898'].isEnabled) {
        this.narrativeForm.controls['bdContactName'].disable();
      }
      this.narrativeForm.get('marketNarOverallReq').setValidators(this.setRequired(this.ubmFileds['15'].isMandatory, 'marketNarOverallReq'));
      if (!this.ubmFileds['15'].isEnabled) {
        this.narrativeForm.controls['marketNarOverallReq'].disable();
      }

      this.narrativeForm.get('friendlyName').setValidators(this.setRequired(this.ubmFileds['902'].isMandatory, 'friendlyName'));
      if (!this.ubmFileds['902'].isEnabled) {
        this.narrativeForm.controls['friendlyName'].disable();
      }

      this.narrativeForm.get('productApprovers').setValidators(this.setRequired(this.ubmFileds['27'].isMandatory, 'productApprovers'));
      if (!this.ubmFileds['27'].isEnabled) {
        this.narrativeForm.controls['productApprovers'].disable();
      }

      this.narrativeForm.get('impactWifi').setValidators(this.setRequired(this.ubmFileds['903'].isMandatory, 'impactWifi'));
      if (!this.ubmFileds['903'].isEnabled) {
        this.narrativeForm.controls['impactWifi'].disable();
      }

      this.narrativeForm.get('telegenceImpacted').setValidators(this.setRequired(this.ubmFileds['44'].isMandatory, 'telegenceImpacted'));
      if (!this.ubmFileds['44'].isEnabled) {
        this.narrativeForm.controls['telegenceImpacted'].disable();
      }

      this.narrativeForm.get('titanEnabledImpacted').setValidators(this.setRequired(this.ubmFileds['848'].isMandatory, 'titanEnabledImpacted'));
      if (!this.ubmFileds['848'].isEnabled) {
        this.narrativeForm.controls['titanEnabledImpacted'].disable();
      }

      this.narrativeForm.get('sidRestriction').setValidators(this.setRequired(this.ubmFileds['900'].isMandatory, 'sidRestriction'));
      if (!this.ubmFileds['900'].isEnabled) {
        this.narrativeForm.controls['sidRestriction'].disable();
      }

      this.narrativeForm.get('marketFormContol').setValidators(this.setRequired(this.ubmFileds['905'].isMandatory, 'marketFormContol'));
      if (!this.ubmFileds['905'].isEnabled) {
        this.narrativeForm.controls['marketFormContol'].disable();
      }

      this.narrativeForm.get('itProposedDate').setValidators(this.setRequired(this.ubmFileds['901'].isMandatory, 'itProposedDate'));
      if (!this.ubmFileds['901'].isEnabled) {
        this.narrativeForm.controls['itProposedDate'].disable();
      }

      this.narrativeForm.get('titanEnablerProposedImplementationDate').setValidators(this.setRequired(this.ubmFileds['899'].isMandatory, 'titanEnablerProposedImplementationDate'));
      if (!this.ubmFileds['899'].isEnabled) {
        this.narrativeForm.controls['titanEnablerProposedImplementationDate'].disable();
      }

      this.narrativeForm.get('dataNarrRDDate').setValidators(this.setRequired(this.ubmFileds['899'].isMandatory, 'dataNarrRDDate'));
      if (!this.ubmFileds['742'].isEnabled) {
        this.narrativeForm.controls['dataNarrRDDate'].disable();
      }

      this.narrativeForm.get('marketNarComments').setValidators(this.setRequired(this.ubmFileds['904'].isMandatory, 'marketNarComments'));
      if (!this.ubmFileds['904'].isEnabled) {
        this.narrativeForm.controls['marketNarComments'].disable();
      }

      // this.narrativeForm.get('reasonCode').setValidators(this.setRequired(this.ubmFileds['169'].isMandatory,'reasonCode'));
      // if(!this.ubmFileds['169'].isEnabled){
      //   this.narrativeForm.controls['reasonCode'].disable();
      // }

      // this.narrativeForm.get('NarrativeComments').setValidators(this.setRequired(this.ubmFileds['908'].isMandatory,'NarrativeComments'));
      // if(!this.ubmFileds['908'].isEnabled){
      //   this.narrativeForm.controls['NarrativeComments'].disable();
      // }

      this.narrativeForm.get('narrativeText').setValidators(this.setRequired(this.ubmFileds['17'].isMandatory, 'narrativeText'));
      if (!this.ubmFileds['17'].isEnabled) {
        this.narrativeForm.controls['narrativeText'].disable();
      }
      if(this.ubmFileds['isGroupTask']){
        //this.acBtndisableNP=false;
      }else{
        this.acBtndisableNP=true;
      }

    });
  }
  public onSelectReason(items: any) {
    //console.log("reasion coderj==="+items)
  }
  public convertDateUItoService(date): string {
    console.log("convertDateUItoService==="+date);
    //let newDate = new Date(date);
    //console.log("convertDateUItoService====newDate="+newDate);
    let servDate = this.datepipe.transform(date,'MM/dd/yyyy');
    console.log(date + "<==UI Date convertDateServicetoUI Service==>" + servDate);
    return servDate;
  }

  public convertDateServicetoUI(date): string {
    //let newDate = new Date(date);
    let uiReqdate = this.datepipe.transform(date, 'yyyy-MM-dd');
    console.log(date + "<==Service convertDateServicetoUI UI Date==>" + uiReqdate)
    return uiReqdate;
  }
  public focusOutRequestedDate() {
    let date = this.narrativeForm.get('requestedDate').value;
    console.log("START DATE Validation" + date);
    if (date != "") {
      if (date >= this.convertDateServicetoUI(this.todayDate)) {
        this.invalidDate = false;
      } else {
        this.invalidDate = true;
      }
    } else {
      this.invalidDate = false;
    }
  }
  //for IT Proposed Implementation Date when Focus Out
  public focusOutITPropDate() {
    let date = this.narrativeForm.get('itProposedDate').value;
    if (date != "" && date != null) {
      if (date != this.narrativeForm.get('requestedDate').value) {
        this.invalidITPropDate = true;
      } else {
        this.invalidITPropDate = false;
      }
    } else {
      this.invalidITPropDate = false;
    }
  }
  //for Titan Enabler Proposed Implementation when Focus Out
  public focusOutTitanEnablerDate() {
    let date = this.narrativeForm.get('titanEnablerProposedImplementationDate').value;
    if (date != "" && date != null) {
      if (date != this.narrativeForm.get('requestedDate').value) {
        this.invalidTEIDate = true;
      } else {
        this.invalidTEIDate = false;
      }
    } else {
      this.invalidTEIDate = false;
    }
  }
  setRequired(condition, parameterName) {
    if (condition === true) {
      return [Validators.required];
    } else {
      return [];
    }
  }

  getOriginalJsonData() {
    //debugger
    console.log("=====entered in to json============");
    this.narrativeOriginalData.sidId = this.sidDescMenu.getSidId();
    this.narrativeOriginalData.creator = "";//this.sidDescMenu._attuid;
    this.narrativeOriginalData.userIdTakingAction = "";//this.sidDescMenu._attuid;  
    this.narrativeOriginalData.sidDescription = "";// this.sidDescMenu.getSidDesc();
    this.narrativeOriginalData.sidType = "";// this.sidDescMenu.getSidType();
    this.narrativeOriginalData.sidReqType = "";//this.sidDescMenu.getRequestType();
    this.narrativeOriginalData.version = this.sidDescMenu.getVersion();
    this.narrativeOriginalData.versionDate = this.sidDescMenu.getVersionDate();
    this.narrativeOriginalData.activity = this.sidDescMenu.getActivity();
    this.narrativeOriginalData.taskId = "";
    this.narrativeOriginalData.narrative.requestorName = "";
    this.narrativeOriginalData.narrative.bdContactName = "";
    this.narrativeOriginalData.narrative.requestedDate = "";
    this.narrativeOriginalData.narrative.sidRestriction = "";
    this.narrativeOriginalData.narrative.telegenceImpacted = "";
    this.narrativeOriginalData.narrative.itProposedDate = "";
    this.narrativeOriginalData.narrative.titanEnablerProposedImplementationDate = "";
    this.narrativeOriginalData.narrative.narrativeProvidedBy = "";
    this.narrativeOriginalData.narrative.narrativeTimeAndDateProvided = "";
    this.narrativeOriginalData.narrative.markets = [];
    this.narrativeOriginalData.narrative.titanEnabledImpacted = "";
    this.narrativeOriginalData.narrative.productApprovers = [];
    this.narrativeOriginalData.narrative.marketNarComments = "";
    this.narrativeOriginalData.narrative.narrativeText = "";
    this.narrativeOriginalData.comments = "";
    this.narrativeOriginalData.reasonCode = "";
    this.narrativeOriginalData.narrative.friendlyName = "";
    this.narrativeOriginalData.narrative.impactWifi = "";
    this.narrativeOriginalData.narrative.marketNarOverallReq = "";
    this.narrativeOriginalData.narrative.requestedRDDate = "";
    this.originalJson = this.narrativeOriginalData;
  }
  getApprovalTabDetails(tabIndex) {
    if (tabIndex == 'narrative') {
      this.approvalPageTab = false;
      this.narrativePageTab = true;
    } else {
      this.approvalPageTab = true;
      this.narrativePageTab = false;
      this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
        dtInstance.destroy();
        this.getApprovalPageDetails(this.sidID);
        this.dtTrigger.next();
       });
    }
  }

  ngAfterViewInit(): void {
    this.dtTrigger.next();
    this.getApprovalPageDetails(this.sidID);
  }

ngOnDestroy(): void {
  this.dtTrigger.unsubscribe();
}

  public getApprovalPageDetails(sidId){
    console.log("Start--getApprovalPageDetails::SIDID="+sidId)
    console.log("url for approval task==="+ this.apiRoot+"/restservices/helloworld/v1/service/getApprovalRecords?sidId="+sidId);
    this.dtOptions = {
      ajax: {
        "url":this.apiRoot+"/restservices/helloworld/v1/service/getApprovalRecords?sidId=20190128256",
        "type": "GET",
        "error": function (e) {
          console.log("exception in Approval data table==="+e)
        },
        "dataSrc": function (data) {
          console.log("data response for approval tab==="+data);
          if(data.data==undefined){
            return ""
          }else{
            console.log("data========"+data)
           return data.data
          }
        }
        },
      columns: [{
        title: 'Date and Time ',
        data : 'startTS',
        "render": function(data, type, full, meta){
          data = '<span>'+data+'</span>';
           return data;
        }
      },{
        title: 'Version',
        data:'startTS',
        "render": function(data, type, full, meta){
            data = '<span>'+ data +'</span>';
           return data;
        }
      },{
        title: 'Activity Step',
        data: 'activityName',
        "render": function(data,type, full, meta){
          data = '<span>'+data+'</span>';
          return data;
        }
      },{
        title: 'User Name',
        data:'userId',
        "render": function(data, type, full, meta){
            data = '<span>'+ data +'</span>';
           return data;
        }
      },{
        title: 'Comments',
        data: 'startTS',
        "render": function(data, type, full, meta){
            data = '<span>'+ data +'</span>';
           return data;
        }
      },{
        title: 'Action',
        data:'activityAction',
        "render": function(data, type, full, meta){
            data = '<span>'+ data +'</span>';
           return data;
        }
      },{
        title: 'Reason Code',
        data:'assignmentDate',
        "render": function(data, type, full, meta){
            data = '<span>'+ data +'</span>';
           return data;
        }
      },{
        title: 'Email To',
        data:'startTS',
        "render": function(data, type, full, meta){
          if(full.dueFlag){
            data = '<span class="overdue-logo img-left"><span class="asterisk">'+ data +'</span></span>';
          }else{
            data = '<span>'+ data +'</span>';
          }
           return data;
        }
      }
    ],
      //columnDefs:[],
        //dom: 'Bfrtip',
    };
  }

}