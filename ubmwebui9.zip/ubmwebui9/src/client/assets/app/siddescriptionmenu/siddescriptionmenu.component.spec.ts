import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SiddescriptionmenuComponent } from './siddescriptionmenu.component';

describe('SiddescriptionmenuComponent', () => {
  let component: SiddescriptionmenuComponent;
  let fixture: ComponentFixture<SiddescriptionmenuComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SiddescriptionmenuComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SiddescriptionmenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
