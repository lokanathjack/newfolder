import { Component, OnInit, Injectable, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { Http, Response } from '@angular/http';
import { HttpClient } from '@angular/common/http'
import { Observable } from "rxjs";
import { map } from "rxjs/operators";
import {ActivatedRoute, Router} from "@angular/router";
import { SidDescMenu } from '../model/commonSidData.model';
import { SidNarrativeData } from '../model/sidNarrativeData.model';
import { environment } from 'environments/environment';
import { CommonserviceService } from '../commonservice.service';

@Component({
  selector: 'app-siddescriptionmenu',
  templateUrl: './siddescriptionmenu.component.html',
  styleUrls: ['./siddescriptionmenu.component.css']
})
export class SiddescriptionmenuComponent implements OnInit {
  
  public requesttype: string;
  public sidID : string;
  apiRoot= environment.apiUrl;
  @Input() sidtype: string;
  version:String;
  versionDate:Date;
  activity :string;
  sidComponentForm: FormGroup;
  submitted = false;
  blnSIDEmpty: boolean = false;
  cmTaskId:string;
  claimFlag:boolean=true;
  params:any;
  taskMsgpop:boolean=true;
  taskMsg:string;
  claimBtnFlag: boolean = false;
  ubmHeaderFields : any;
  
  constructor(private http:Http,private httpClient:HttpClient, private router: Router,private route: ActivatedRoute,public sidDescMenu: SidDescMenu,private formBuilder: FormBuilder) { 
  }
  @Output() calimEmitter = new EventEmitter<string>();

  ngOnInit() {
    this.sidtype=this.sidDescMenu.getSidType();
    this.requesttype=this.sidDescMenu.getRequestType();
    this.sidID=this.sidDescMenu.getSidId();
    this.version=this.sidDescMenu.getVersion();
    this.versionDate=this.sidDescMenu.getVersionDate();
    this.activity=this.sidDescMenu.getActivity();
    this.sidComponentForm = this.formBuilder.group({
      sIDDescription: ['',Validators.compose(this.setRequired(true,'requestorName'))]
      });

    this.route.queryParams.subscribe(params => {
      let sidID = params["sidId"];
      let taskName = params["taskName"];
      let cmId=params["cmId"];
      let clmflag=params["flag"];
      if(taskName!=undefined){
        taskName=atob(taskName)
      }
      if(cmId!=undefined){
        this.cmTaskId=cmId;
      }
      if(clmflag!=undefined){
        this.claimBtnFlag=true;
        if(clmflag=='false')
        this.claimFlag=false;
        else
        this.claimFlag=true;
      }
      if(sidID !=undefined && sidID !=''){
         this.getNarrativeDatabySIDId(sidID,taskName);
         this.getFormControlData(taskName)
         this.activity=taskName;
      }
      else{
        this.getFormControlData(this.activity)
      }
    });
  }

  get f() {
    return this.sidComponentForm.controls;
  }

  validateChildForm(): Boolean {
    let sidbutton:HTMLElement=document.getElementById('sidbutton') as HTMLElement;
    sidbutton.click();
    let sidDesc= this.sidComponentForm.get('sIDDescription').value;
        this.sidDescMenu.sidDescription=sidDesc;
        if (sidDesc == "") {
           return this.blnSIDEmpty = false;
        }else{
           return this.blnSIDEmpty = true;
        }
      }

sidDiscrForm(sidComponentForm){
  this.submitted=true;
  if(!sidComponentForm.valid ) {
      console.log("INValid:::::sidform");
         return false;
     } else {
        console.log("sidform:::::success");
        return true;
     }   
    }

     public getNarrativeDatabySIDId(sidId,activity) {
          //console.log("getNarrativeDataby::SIDId="+sidId+":::Task Name="+activity);
          var url = this.apiRoot+'/restservices/helloworld/v1/service/getNarrativeDetails?sidId='+sidId;
          this.httpClient.get(url).subscribe( data => {
          if(data!=null){
            let nrtveData=JSON.parse(JSON.stringify(data));
            this.sidID=nrtveData['sidId'];
            this.sidtype=nrtveData['sidType'];
            this.requesttype=nrtveData['sidReqType'];
            this.version=nrtveData['version'];
            this.versionDate=nrtveData['versionDate'];
            //this.activity=nrtveData['activity'];
            this.sidComponentForm = this.formBuilder.group({
              sIDDescription: [nrtveData['sidDescription'],Validators.required]
              });
             }
          });
      }

    public claimUnclaim(event): void {
             //console.log("claim clicked===>"+event);
                 this.calimEmitter.next(event);
                 if(event=='UnClaim')
                 this.claimFlag=true
                 else
                 this.claimFlag=false;
             }

             getFormControlData(activityName){ 
              var url = this.apiRoot+'/restservices/helloworld/v1/service/getFieldUINames?sidType=QUICKUPDATE&pageName=NARRATIVE&activityName='+activityName; 
              console.log("UI Fields URL==="+url); 
              this.httpClient.get(url).subscribe( data => { 
                this.ubmHeaderFields=data; 
                //console.log("this.sidDescMenu.ubmFormContralData..."+JSON.stringify(this.ubmHeaderFields['isGroupTask'])); 
                this.sidComponentForm.get('sIDDescription').setValidators(this.setRequired(this.ubmHeaderFields['893'].isMandatory,'requestorName'));
                if(!this.ubmHeaderFields['909'].isEnabled){
                   this.sidComponentForm.controls['sIDDescription'].disable();
                }
                if(this.ubmHeaderFields['isGroupTask']){
                  this.claimBtnFlag=true;
                }else{
                  this.claimBtnFlag=false;
                }
              });
            }
            setRequired(condition,parameterName) {
              if(condition===true) {
                  return [Validators.required];
              } else {
                  return [];
              }   
          }
}
