import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { HttpClientModule, HttpClientJsonpModule } from '@angular/common/http';
import {HttpModule} from "@angular/http";
import { Routes, RouterModule } from "@angular/router";
import { DataTablesModule } from 'angular-datatables';
import { AppComponent } from "./app.component";
import { MessageComponent } from "./messages/message.component";
import { MessageListComponent } from "./messages/message-list.component";
import { MessageInputComponent } from "./messages/message-input.component";
import { MessagesComponent } from "./messages/messages.component";
import { AuthenticationComponent } from "./auth/authentication.component";
import { HeaderComponent } from './header/header.component';
import { routing } from "./app.routing";
import { LogoutComponent } from "./auth/logout.component";
import { SignupComponent } from "./auth/signup.component";
import { SigninComponent } from "./auth/signin.component";
import {AuthService} from "./messages/http.service";

import { UbmapplicationComponent } from './ubmapplication/ubmapplication.component';
import { UbmmainuiComponent } from './ubmmainui/ubmmainui.component';
import { SidDescMenu } from './model/commonSidData.model';
import { SiddescriptionmenuComponent } from './siddescriptionmenu/siddescriptionmenu.component';
import { NarrativeComponent } from './narrative/narrative.component';
import { ApprovalComponent } from './approval/approval.component';
import { FooterComponent } from './footer/footer.component';
import { MytaskComponent } from './mytask/mytask.component';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { CookieService } from 'ngx-cookie-service';
import { CommonModule, DatePipe } from '@angular/common';
import { ReasoncommentsmenuComponent } from './reasoncommentsmenu/reasoncommentsmenu.component';


@NgModule({
    declarations: [
        AppComponent,
        MessageComponent,
        MessageListComponent,
        MessageInputComponent,
        MessagesComponent,
        AuthenticationComponent,
        HeaderComponent,
        LogoutComponent,
        SignupComponent,
        SigninComponent,
        UbmapplicationComponent,
        UbmmainuiComponent,
        SiddescriptionmenuComponent,
        NarrativeComponent,
        FooterComponent,
        MytaskComponent,
        ApprovalComponent,
        ReasoncommentsmenuComponent,
        
    ],
    imports:
     [
      BrowserModule,
      FormsModule, 
      routing, 
      CommonModule,
      ReactiveFormsModule, 
      HttpModule, 
      HttpClientModule, 
      HttpClientJsonpModule,
      NgMultiSelectDropDownModule.forRoot(),
       DataTablesModule
    ],
    
    providers: [SidDescMenu, AuthService, CookieService, DatePipe],
    bootstrap: [AppComponent]
})
export class AppModule {

}