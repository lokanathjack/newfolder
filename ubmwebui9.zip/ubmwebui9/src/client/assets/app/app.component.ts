import { Component, OnInit } from '@angular/core';
import { MessageService } from "./messages/message.service";
import { CookieService } from 'ngx-cookie-service';
import { SidDescMenu } from './model/commonSidData.model';
import { CommonserviceService } from './commonservice.service';
import { environment } from 'environments/environment';
import { AuthService } from './messages/http.service';
import { HttpClient } from '@angular/common/http';

@Component({
    selector: 'my-app',
    templateUrl: './app.component.html',
    providers: [MessageService,CommonserviceService]
})
export class AppComponent implements OnInit{
        cookieValue : string[] = [];
        spinner:boolean=false;
       
  public constructor(private sidDescMenu: SidDescMenu,private cookieService: CookieService,private auth:AuthService) { }
    ngOnInit() {
        console.log("env url form session===="+localStorage.getItem('envUrl'));
        if(localStorage.getItem('envUrl')!=null && localStorage.getItem('envUrl')!=""){
            environment.apiUrl=localStorage.getItem('envUrl');
        }
        this.auth.callEnvService().subscribe((response:any) => {
            console.log("Start calling service from app componet==" + response);
            environment.apiUrl=response;
            localStorage.setItem('envUrl', response);
        },(error) => {
            console.log("Error on app Cmnt getting env URL====="+error);
        }
    )
        console.log("this.cookieService.get('attESHr')="+this.cookieService.get('attESHr'));
        if(this.cookieService.get('attESHr') !='' && this.cookieService.get('attESHr')!=null){
            this.cookieValue = this.cookieService.get('attESHr').split("|",3);
            var firstname = this.cookieValue[0]
            var lastname = this.cookieValue[1]
            var attuid = this.cookieValue[2].split("@")[0];
            this.sidDescMenu.firstName = firstname;
            this.sidDescMenu.lastName = lastname;
            this.sidDescMenu.attuid = attuid;
            console.log("userid loogeed == " + this.cookieValue + "firstname " + this.sidDescMenu._firstName + "lastname " + this.sidDescMenu._lastName + " attuid " + this.sidDescMenu._attuid);
        } else {
            console.log("Some Exception in Application, Please Clean Browser Cache and Try Again...");
            //below code need to remove and  should be navigate to logout page...
            //this.sidDescMenu.firstName = "Vijaya Bhaksker";
            //this.sidDescMenu.lastName = "Pandiri";
            //this.sidDescMenu.attuid = 'vp5323';
            //environment.apiUrl='http://zltv6462.vci.att.com:30973';
        }
    }
  
}