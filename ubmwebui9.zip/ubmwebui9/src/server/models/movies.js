const Movie = [
    {
        title: 'spiderman',
        year : '2003',
        genre: "Action",
        rank: 9
    },
    {
        title: 'batman',
        year : '2007',
        genre: "Action",
        rank: 9
    },
    {
        title: 'superman',
        year : '2002',
        genre: "Action",
        rank: 9
    },
    {
        title: 'wonderwomen',
        year : '2017',
        genre: "Action",
        rank: 7
    }

];

module.exports = {Movie};