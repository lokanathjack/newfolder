require('nodejs-dashboard');
require('@com.att.ajsc/enfocerjs').job.start(); // Starts Cron job in  aaf package to clear userDetail cache every 30min
const express = require('express');
const path = require('path');
const favicon = require('serve-favicon');
const cookieParser = require('cookie-parser');
const bodyParser = require('body-parser');
const mung = require('express-mung');
const appRoot = require('app-root-path');
const timeout = require(appRoot.path+'/helperfunctions/req-timeout');
let isPublish = process.env.PACT;
const {runPactProviderTest} = require(appRoot.path+'/test/ContractTest/pact-provider/provider.spec.js');
const {checkForConfig} = require(path.join(process.cwd(),'/helperfunctions/checkForConfig'));
const configdb = (checkForConfig()) ? require(path.join(process.cwd(),'/config/mongo.config')).dataBaseConfig : require(path.join(process.cwd(),'/config-map/mongo.config')).dataBaseConfig
const {mongodbConnection} = require('../../db/mongodbConnection');
const index = require('./routes/index');
const user = require('./routes/users');
const superhero = require('./routes/superhero');
const metrics = require('./routes/metrics');
const example = require('./routes/example');
const elkLoggingTestRoute = require('./routes/elkLoggingTestRoute');
const tssErrorDemoRoutes = require('./routes/tssErrorDemoRoutes');
const helloworld = require('./routes/helloworld.js');
const envRouter = require('./routes/envRouter.js');

const login = require('./routes/login.js');
const healthcheck = require('../../helperfunctions/healthcheck');
const logger= require('@com.att.ajsc/1t-logging').logger;
const maskit = require(appRoot.path+'/helperfunctions/maskit');

const app = express();
const cors = require('cors');
const profilerMiddleware = require('./middlewares/profilerMiddleware.js');
const onResponseLogger = require('./middlewares/onResponseLogger.js');
const ilib = require('@com.att.ajsc/ilib-nodejs');
const installedPackages = require(appRoot.path+'/package.json').dependencies;
function logPhoneinStatusEvent() {
    logger.phonein("phoneInStatus", installedPackages, ["technology:Nodejs", "anscVersion:"+require(appRoot.path+'/package.json').version,"Installed Packages and Versions"]);
    setInterval(function () {
        logger.phonein("phoneInStatus", installedPackages, ["technology:Nodejs", "anscVersion:"+require(appRoot.path+'/package.json').version,"Installed Packages and Versions"]);
    }, 86400000);
}
logPhoneinStatusEvent();

if (isPublish === 'yes') {
    runPactProviderTest(app);
}else {
    logger.info('JENKINS ENV TO PUBLISH PACT IS SET TO NO');
}

const config = require(appRoot.path+'/config');


const tools = require('../../helperfunctions/tools');
//const anscLogger = require('@com.att.ajsc/ansc-logging');


const {validate} = require('@com.att.ajsc/aaf');
//const {prop} = require('../../project.config');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(profilerMiddleware());
app.use(cors());

mongodbConnection.init(configdb);

// view engine setup
//app.set('views', path.join(__dirname, 'views'));
//app.use("/", express.static(path.join(__dirname, "/public/js/angular"))); 
 
//app.use((req, res, next) => { 
//  res.sendFile(path.join(__dirname, "/public/js/angular", "index.html")); 
//});
//app.set('view engine', 'ejs');

// uncomment after placing your favicon in /public
//app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));

app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use(mung.json(
    function transform(body, req, res) {
        if(req.baseUrl && req.route) {
            req.resourcePath = req.baseUrl.toString() + req.route.path.toString();
        }
        req.responseHeaders = res._headers;
        let responseBody = JSON.stringify(body,maskit());
        onResponseLogger(req, responseBody);
        return body;
    }
));
    console.log("Test 1" + __dirname);
app.use('/documentation', express.static(path.join(__dirname, 'swagger')));
    console.log("Test2" + __dirname);
     console.log("URL PRefix" + tools.getUrlPrefix());
//app.use(tools.getUrlPrefix()+'/v1/', index);
app.use('/index', index);
app.use(tools.getUrlPrefix()+'/v1/user', user);
app.use(tools.getUrlPrefix()+'/v1/superhero', superhero);
app.use(tools.getUrlPrefix()+'/v1/metrics', metrics);
app.use(tools.getUrlPrefix()+'/v1/example',timeout(3000), example);
app.use(tools.getUrlPrefix()+'/v1/elkLoggingTestRoute',timeout(4000), elkLoggingTestRoute);
app.use(tools.getUrlPrefix()+'/v1/tssexceptiondemo', tssErrorDemoRoutes);
app.use(tools.getUrlPrefix()+'/v1/login', login);
app.use(tools.getUrlPrefix()+'/v1/healthcheck', healthcheck());
// app.use(enforce);
app.use(tools.getUrlPrefix()+'/v1/helloworld', helloworld);
app.use(tools.getUrlPrefix()+'/v1/envRouter', envRouter);

// catch 404 and forward to error handler
app.use( express.static(path.join(__dirname, "/public/js/angular"))); 
console.log(__dirname);
app.use((req, res, next) => { 
       console.log("Test" + __dirname);
  res.sendFile(path.join(__dirname, "/public/js/angular", "index.html")); 
});
//app.use(function (req, res, next) {
 //   return res.render('index');
//});

module.exports = app;
