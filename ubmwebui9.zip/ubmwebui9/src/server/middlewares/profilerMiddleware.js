/**
 * Created by rx226f on 10/11/2017.
 */
const appRoot = require('app-root-path');
//const configuration = require(appRoot.path+'/config/override-configs.json');
const updateReqObjWithLogInfo = require('@com.att.ajsc/1t-logging').updateReqObjWithLogInfo;
const logger= require('@com.att.ajsc/1t-logging').logger;
const dashboardLogger = require('@com.att.ajsc/dashboard-logging');
//------------
const path = require('path');
const fs = require('fs');
const rimraf = require('rimraf');
var configuration;
const dirExist = fs.existsSync(path.resolve(process.cwd(),'config-map'));
const configDirExist = fs.existsSync(path.resolve(process.cwd(),'config'));
const tools = require(appRoot.path+'/helperfunctions/tools.js');

if (dirExist) {
    if (configDirExist) {
        rimraf(path.resolve(process.cwd(),'config'),function (err) {
            if (err) {
                logger.info('config folder is not found, it may removed already');
            }else {
                logger.info('config folder removed');
            }
        });
    }
    configuration = require(path.resolve(process.cwd(),'./config-map/override-configs.json'));
}else {
    (function (dir) {
        try {
            fs.statSync(dir);
            logger.info('config-map dir is not exist, config dir exists');
            logger.info('getting configurations from config folder...');
            configuration = require(path.resolve(process.cwd(),'./config/override-configs.json'));
        } catch (e) {
            logger.error('could not get config from config folder');
        }
    })('config');
}
//---------

module.exports = () => {
    return (req, res, next) => {
        if(req.originalUrl.includes(tools.getUrlPrefix())) {
            onRequestLogger(req);
            // The 'finish' event will emit once the response is done sending
            // res.once('finish', () => {
            //     // Emit an object that contains the original request and the elapsed time in MS
            //     if(req.baseUrl && req.route) {
            //         req.resourcePath = req.baseUrl.toString() + req.route.path.toString();
            //     }
            //     onResponseLogger(req);
            // });
        }
        next()
    }
}

var onRequestLogger = (req) => {
    // Implement the middleware function based on the options object
    //here filter b/w elk and dashboard
    if( configuration.logging  === '1t-logging') {
        updateReqObjWithLogInfo.onRequest(req);
    }
    if( configuration.logging  === 'dashboard-logging') {
        dashboardLogger.onRequestHandler(req);
    }
}
