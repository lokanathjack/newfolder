var express = require('express');
var router = express.Router();
const {findSuperHero} = require('../controllers/movie');



router.get('/', function(req, res, next) {
    findSuperHero(req,res);
});

module.exports = router;
