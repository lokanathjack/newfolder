
const promClient = require('prom-client');
const helloworldRouteCount = new promClient.Counter({
    name: 'helloworld_route_served_count',
    help: 'used to count requests served by helloworld route',
    labelNames: ['method','code'],
    type:['type']
});

var express = require('express');
var router = express.Router();
const {aafRunner} = require('@com.att.ajsc/aaf')
const {enforce} = require('@com.att.ajsc/enfocerjs');
const {callLimiter} = require('@com.att.ajsc/requestlimiterjs');


const register = express.Router();
const angularEnv = process.env.APP_ENV;            
// GET method route
// GET method route
router.get('/', function (req, res, next) {
        helloworldRouteCount.inc();
        console.log("Test in Helloworld" );
        console.log("Test in Helloworld"  + angularEnv);
        res.send('helloworld Route GET method');
})
// POST method route
router.post('/', function (req, res,next) {
        res(req.auth);
})

module.exports = router;
