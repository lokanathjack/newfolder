var express = require('express');
var router = express.Router();

const register = express.Router();
const angularEnv = process.env.APP_ENV;
const serviceUrl = process.env.SERVICE_NAME;
//const angularEnv = "dev"; 
// GET method route

router.get('/', function (req, res, next) {
       
        console.log("Test in EnvRouter"  + angularEnv);
        console.log("Test in EnvRouter"  + serviceUrl);
        
 
        res.send(JSON.stringify(serviceUrl));
})
 
module.exports = router;
