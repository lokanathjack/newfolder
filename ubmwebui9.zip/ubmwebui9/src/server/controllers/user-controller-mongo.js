const User = require('../models/user-model-mongo');

const addNewUserMongo = (req,res) => {
    const user = new User({
        firstName: req.query.firstName,
        lastName: req.query.lastName
    });

    user.save((error, user) => {
        if (error) {
            console.log('Could not save user...');
            return res.send(error);
        }
        res.json({user});
    });
};

const getAllUsersMongo = (req, res) => {
    User.find().then((result) => {
        if (result.length <= 0) {
            const message = 'No collections in database';
            return res.send(message);
        }
        res.send(result);
    }).catch((error) => {
        console.log(error);
        const message = 'Error getting all users form mongo collection';
        res.send(message);
    });
};

module.exports = {addNewUserMongo,getAllUsersMongo};
